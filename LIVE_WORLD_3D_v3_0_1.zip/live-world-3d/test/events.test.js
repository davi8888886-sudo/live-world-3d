import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { cleanUsername, normalizeBasic, GiftTracker, Roster } from "../lib/events.js";
import { resolveGift } from "../public/stage/gifts.js";

test("cleanUsername aceita @, sem @ e links; rejeita inválidos", () => {
  assert.equal(cleanUsername("@Fulano.Tal"), "fulano.tal");
  assert.equal(cleanUsername("fulano_1"), "fulano_1");
  assert.equal(cleanUsername("https://www.tiktok.com/@fulano/live"), "fulano");
  assert.equal(cleanUsername("  @fulano?x=1 "), "fulano");
  for (const bad of ["", "a", "@", "com espaço x", "ab$", "x".repeat(30), "fim.", null, undefined]) assert.equal(cleanUsername(bad), null, String(bad));
});
test("normalizeBasic: formatos v2 (user aninhado) e planos; remove < >", () => {
  assert.equal(normalizeBasic("chat", { user: { uniqueId: "a1", nickname: "Ana<b>" }, comment: " oi " }).text, "oi");
  assert.equal(normalizeBasic("chat", { user: { uniqueId: "a1", nickname: "Ana<b>" }, comment: "x" }).user.name, "Anab");
  assert.equal(normalizeBasic("member", { uniqueId: "plano", nickname: "P" }).user.id, "plano");
  assert.equal(normalizeBasic("chat", { user: { uniqueId: "a" }, comment: "   " }), null);
  assert.equal(normalizeBasic("like", { user: { uniqueId: "a" }, likeCount: 5000 }).count, 1000);
  assert.equal(normalizeBasic("member", {}), null);
});
const g = (o) => ({ user: { uniqueId: "u1", nickname: "U" }, giftId: 5655, giftType: 1, repeatCount: 1, repeatEnd: false, giftDetails: { giftName: "Rose", diamondCount: 1 }, ...o });
test("presente em sequência conta UMA vez, só no fim", () => {
  const t = new GiftTracker();
  const evs = [t.process(g({ repeatCount: 1 })), t.process(g({ repeatCount: 2 })), t.process(g({ repeatCount: 3 }))];
  assert.ok(evs.every((e) => e.type === "gift-progress"));
  const fin = t.process(g({ repeatCount: 3, repeatEnd: true }));
  assert.equal(fin.type, "gift"); assert.equal(fin.count, 3); assert.equal(fin.total, 3);
  assert.equal(t.flush().length, 0);
});
test("fim que nunca chega: fecha por tempo; fim tardio igual é ignorado", () => {
  let now = 0; const t = new GiftTracker({ now: () => now });
  t.process(g({ repeatCount: 4 }));
  now = 7000;
  const f = t.flush(); assert.equal(f.length, 1); assert.equal(f[0].count, 4);
  now = 8000;
  assert.equal(t.process(g({ repeatCount: 4, repeatEnd: true })), null);
  t.process(g({ repeatCount: 6 }));
  assert.equal(t.process(g({ repeatCount: 6, repeatEnd: true })).count, 6);
});
test("fim tardio maior que o fechado gera só a diferença", () => {
  let now = 0; const t = new GiftTracker({ now: () => now });
  t.process(g({ repeatCount: 4 })); now = 7000; t.flush(); now = 8000;
  assert.equal(t.process(g({ repeatCount: 7, repeatEnd: true })).count, 3);
});
test("presente sem sequência: msgId repetido é ignorado", () => {
  const t = new GiftTracker();
  assert.equal(t.process(g({ giftType: 2, msgId: "m1", repeatCount: 1 })).type, "gift");
  assert.equal(t.process(g({ giftType: 2, msgId: "m1" })), null);
  assert.equal(t.process(g({ giftType: 2, msgId: "m2" })).type, "gift");
});
test("Roster não duplica espectadores e soma estatísticas", () => {
  const r = new Roster({ max: 3 });
  const ev = (type, id, extra = {}) => ({ type, user: { id, name: id }, ...extra });
  assert.equal(r.apply(ev("member", "a")).isNew, true);
  assert.equal(r.apply(ev("chat", "a")).isNew, false);
  r.apply(ev("like", "b", { count: 7 })); r.apply(ev("gift", "b", { count: 2, total: 20 }));
  const s = r.snapshot();
  assert.equal(s.viewers.length, 2);
  assert.deepEqual(s.stats, { viewers: 2, comments: 1, likes: 7, gifts: 2, diamonds: 20 });
  r.apply(ev("member", "c")); r.apply(ev("member", "d"));
  assert.equal(r.snapshot().viewers.length, 3);
});
test("resolveGift: nome > faixa de diamantes > padrão (config real)", () => {
  const cfg = JSON.parse(fs.readFileSync(new URL("../config/gifts.json", import.meta.url)));
  assert.equal(resolveGift(cfg, { giftName: "rose", total: 5000 }).effect, "petals");
  assert.equal(resolveGift(cfg, { giftName: "Galaxy", total: 1500 }).dance, "spin");
  assert.equal(resolveGift(cfg, { giftName: "Galaxy", total: 150 }).effect, "lasers");
  assert.equal(resolveGift(cfg, { giftName: "Galaxy", total: 0 }).effect, "confetti");
});
