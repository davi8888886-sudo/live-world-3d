// Pose do DJ: de frente para a pista, cabeça no ritmo, uma mão no disco e a outra levantando no refrão.
const s = Math.sin, c = Math.cos, pos = (x) => Math.max(0, x);
export function djPose(p, e = 0.5) {
  const a = 0.7 + 0.3 * e, up = pos(s(p / 4));
  return { hy: -0.03 + 0.02 * c(2 * p), tlx: 0.12, trx: 0.12, slx: 0.2, srx: 0.2, sx: 0.12 + 0.03 * c(2 * p), hdx: 0.12 + 0.1 * c(2 * p) * a, hdz: 0.1 * s(p / 2),
    hrz: 0.04 * s(p), alx: 0.7 + 0.15 * s(2 * p), alz: 0.18, flx: 0.9, arx: 0.5 + 0.9 * up, arz: 0.3 + 1.4 * up * a, frx: 0.8 - 0.4 * up };
}
