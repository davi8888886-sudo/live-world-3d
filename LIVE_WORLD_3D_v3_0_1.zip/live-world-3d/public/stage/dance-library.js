// Biblioteca de danças do TikTok / Brasil (animação procedural de esqueleto — sem vídeos, sem arquivos de terceiros).
// Para adicionar uma dança: registerDance({id, name, category, source, verified, desc, group?}, (p, e) => pose). Nada mais precisa mudar
// (lembre de incluir o id na lista DANCES do server.js se quiser escolhê-la no painel).
//
// PESQUISA (nov/2026): o que as fontes confirmam e o que é interpretação nossa:
//  • Passinho do Jamal — criado em 2020 no Recife (Santo Amaro) por Romero Júnior "Jamal" e Pedro Henrique "Eo Chapa"; virou hit em 2026 com
//    "Toma Botada" (Eo Chapa e MC Rogê). Passos descritos pelo criador: "pé pro lado e pro outro", contagem "um, dois, um, dois, três",
//    mãos acompanhando os pés, balanço pequeno do quadril. Origem: passo do brega funk. → movimento VERIFICADO em texto (não em vídeo).
//  • Bombaye — trend de 2026 sobre "Copines" (Aya Nakamura), muito usada em templates do CapCut. As fontes achadas NÃO descrevem os passos:
//    a coreografia aqui é INTERPRETAÇÃO própria (verified:false). Troque pelos passos oficiais quando você tiver a referência.
//  • Passinho do Vini Jr / da Copa e "Desce quicando" — aparecem como trends brasileiras em templates do CapCut; passos também NÃO
//    descritos nas fontes → interpretações próprias (verified:false).
import { registerDance } from "./dances.js";
const s = Math.sin, c = Math.cos, PI = Math.PI, pos = (x) => Math.max(0, x), sm = (x) => x * x * (3 - 2 * x);
const bend = (b) => ({ hy: -0.07 * b, tlx: 0.28 * b, trx: 0.28 * b, slx: 0.55 * b, srx: 0.55 * b });

export const CATEGORIES = [
  { id: "passinhos", name: "Passinhos brasileiros" }, { id: "funk", name: "Funk brasileiro" }, { id: "trends", name: "Trends do TikTok" },
  { id: "individuais", name: "Danças individuais" }, { id: "grupo", name: "Danças em grupo" }, { id: "especiais", name: "Movimentos especiais" },
];

// Passinho do Jamal: ciclo de 5 tempos: 1-2 · 1-2-3. O corpo desliza de um lado para o outro, o pé de fora levanta a cada troca
// e no "três" há uma pisada dupla no mesmo lado. As mãos (cotovelos dobrados) acompanham os pés.
const JAMAL = [1, -1, 1, -1, 1];
function jamal(p, e = 0.5) {
  const a = 0.75 + 0.25 * e, cyc = (((p / PI) % 5) + 5) % 5, i = Math.floor(cyc), f = cyc - i;
  const from = JAMAL[i], to = JAMAL[(i + 1) % 5], side = from + (to - from) * sm(Math.min(1, f * 1.6)), vel = to - from, lift = s(PI * f) * a;
  const triple = vel === 0 ? s(PI * f) : 0;                                   // "três": pisada no lugar
  const lL = vel > 0 ? lift : 0, lR = vel < 0 ? lift : 0;                    // o pé que sai do chão é o do lado de onde o corpo vem
  return {
    hx: 0.13 * side * a, hy: -0.05 - 0.02 * lift + 0.03 * triple, hrz: 0.07 * side * a, hry: 0.1 * side * a, sz: -0.1 * side * a, sx: 0.06,
    hdz: 0.08 * side, hdx: 0.04 * triple,
    tlx: 0.15 + 0.35 * lL, trx: 0.15 + 0.35 * lR, tlz: 0.22 * lL + 0.06, trz: 0.22 * lR + 0.06, slx: 0.35 + 0.7 * lL + 0.4 * triple, srx: 0.35 + 0.7 * lR + 0.4 * triple,
    alx: 0.45 + 0.35 * lL, arx: 0.45 + 0.35 * lR, alz: 0.4 + 0.3 * side + 0.25 * lL, arz: 0.4 - 0.3 * side + 0.25 * lR, flx: 1.25 - 0.3 * lL, frx: 1.25 - 0.3 * lR,
  };
}
registerDance({ id: "jamal", name: "Passinho do Jamal", category: "passinhos", source: "Recife, 2020 — Jamal e Eo Chapa; hit 2026 com 'Toma Botada'", verified: true, desc: "Pé pro lado e pro outro, 1-2 · 1-2-3, mãos acompanhando os pés, quadril discreto." }, jamal);

// Bombaye (trend 2026, "Copines"): INTERPRETAÇÃO — quadril marcando cada tempo, braços alternando em "bom bom" para o alto, cabeça no ritmo.
registerDance({ id: "bombaye", name: "Bombaye", category: "trends", source: "Trend 2026 (Aya Nakamura — Copines); passos não descritos nas fontes", verified: false, desc: "Interpretação própria: quadril em 8, braços alternados para o alto no 'bom bom'." },
  (p, e = 0.5) => { const a = 0.7 + 0.3 * e, hit = pos(s(2 * p)), L = sm(0.5 + 0.5 * s(p)), R = 1 - L;
    return { ...bend(0.7 + 0.4 * hit), hrz: 0.16 * s(p) * a, hry: 0.3 * s(p + 0.5) * a, sz: -0.1 * s(p) * a, sx: 0.08 + 0.05 * hit, hdx: 0.1 * c(2 * p), hdz: 0.08 * s(p),
      alz: 0.3 + 1.9 * L * a, arz: 0.3 + 1.9 * R * a, alx: 0.2 * hit, arx: 0.2 * hit, flx: 0.9 - 0.6 * L, frx: 0.9 - 0.6 * R, tlz: 0.14, trz: 0.14 }; });

// Passinho do Vini (trend BR de comemoração): INTERPRETAÇÃO — passo lateral largo, punhos junto ao peito bombeando, ombros alternando.
registerDance({ id: "vini", name: "Passinho do Vini", category: "trends", source: "Trend brasileira (templates CapCut); passos não descritos nas fontes", verified: false, desc: "Interpretação própria: passo lateral largo, punhos no peito, ombros alternando." },
  (p, e = 0.5) => { const a = 0.7 + 0.3 * e, k = s(p), up = pos(s(2 * p));
    return { hx: 0.16 * k * a, hy: -0.06 + 0.04 * up, ...bend(0.5 + 0.5 * up), tlz: 0.2 + 0.1 * pos(k), trz: 0.2 + 0.1 * pos(-k), hrz: 0.1 * k, hry: -0.25 * k * a, sz: -0.12 * k * a, sx: 0.1,
      hdz: 0.1 * k, hdx: 0.08 * c(2 * p), alx: 0.5 + 0.5 * pos(s(2 * p)), arx: 0.5 + 0.5 * pos(-s(2 * p)), alz: 0.45, arz: 0.45, flx: 1.8 - 0.5 * pos(s(2 * p)), frx: 1.8 - 0.5 * pos(-s(2 * p)) }; });

// Desce quicando (funk): INTERPRETAÇÃO — agacha fundo e "quica" duas vezes por tempo, mãos nos joelhos alternando, quadril solto.
registerDance({ id: "quicando", name: "Desce quicando", category: "funk", source: "Trend brasileira de funk (templates CapCut); passos não descritos nas fontes", verified: false, desc: "Interpretação própria: agachada funda com quicadas, mãos nos joelhos, quadril solto." },
  (p, e = 0.5) => { const a = 0.7 + 0.3 * e, q = 0.5 + 0.5 * c(4 * p), deep = 0.65 + 0.35 * s(p / 2);
    return { hy: -0.22 * deep - 0.05 * q, tlx: 0.95 * deep, trx: 0.95 * deep, slx: 1.5 * deep + 0.15 * q, srx: 1.5 * deep + 0.15 * q, tlz: 0.28, trz: 0.28, sx: 0.32 * deep, hdx: -0.25,
      hrz: 0.12 * s(2 * p) * a, hry: 0.4 * s(p) * a, sz: -0.08 * s(p), alx: 0.7 + 0.3 * s(p), arx: 0.7 - 0.3 * s(p), alz: 0.3, arz: 0.3, flx: 0.3, frx: 0.3, hdz: 0.08 * s(p) }; });

// Em grupo: todos sincronizados (mesma fase) no Passinho do Jamal, e uma "ola" que atravessa a pista (fase depende da posição x).
registerDance({ id: "grupo_jamal", name: "Jamal em grupo (sincronizado)", category: "grupo", source: "Passinho do Jamal com fase compartilhada", verified: true, desc: "Todos os avatares fazem o Jamal juntos, no mesmo tempo.", group: "sync" }, jamal);
registerDance({ id: "ola", name: "Ola da pista", category: "grupo", source: "própria", verified: false, desc: "Onda de braços que atravessa a pista da esquerda para a direita.", group: "wave" },
  (p, e = 0.5) => { const w = sm(pos(s(p / 2))), a = 0.8 + 0.2 * e; return { ...bend(0.4 + 0.3 * w), hy: -0.04 + 0.08 * w, alz: 0.3 + 2.3 * w * a, arz: 0.3 + 2.3 * w * a, alx: 0.1, arx: 0.1, flx: 0.2, frx: 0.2, hdx: -0.2 * w, sx: -0.06 * w }; });
