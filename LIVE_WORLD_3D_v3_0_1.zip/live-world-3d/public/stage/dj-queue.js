// Fila de DJ (regras puras, sem THREE). Só usuários REAIS da LIVE entram: quem comenta "!dj" entra na fila; o dono escolhe/troca pelo painel.
// Nada é inventado: sem pedidos, a cabine fica vazia.
export class DjQueue {
  constructor() { this.queue = []; this.active = null; }
  /** Pede para entrar na fila. Retorna true se entrou agora. */
  join(user) {
    if (!user?.id || this.active?.id === user.id || this.queue.some((u) => u.id === user.id)) return false;
    this.queue.push({ id: user.id, name: user.name }); return true;
  }
  leave(id) { this.queue = this.queue.filter((u) => u.id !== id); if (this.active?.id === id) { this.active = null; return true; } return false; }
  /** Dono escolhe alguém (da fila) ou o próximo; o DJ anterior sai da cabine. Retorna {active, previous} ou null. */
  select(id) {
    const i = id ? this.queue.findIndex((u) => u.id === id) : 0; if (i < 0 || !this.queue.length) return null;
    const previous = this.active; [this.active] = this.queue.splice(i, 1); return { active: this.active, previous };
  }
  release() { const previous = this.active; this.active = null; return previous; }
  /** Se o DJ ativo saiu da arena (inatividade), a cabine é liberada. */
  drop(id) { return this.leave(id); }
  snapshot() { return { active: this.active, queue: this.queue.map((u) => ({ ...u })) }; }
}
export const isDjCommand = (text) => /^\s*!dj\b/i.test(String(text || ""));
