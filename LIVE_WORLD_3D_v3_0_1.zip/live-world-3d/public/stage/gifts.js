// Resolve qual dança/efeito um presente dispara (config/gifts.json). Função pura, usada no navegador e nos testes.
export function resolveGift(cfg, ev) {
  const d = cfg?.default || { dance: "celebrate", effect: "confetti", focusSeconds: 5 };
  const byName = cfg?.byName || {}, byId = cfg?.byId || {};
  if (ev.giftId != null && byId[String(ev.giftId)]) return { ...d, ...byId[String(ev.giftId)] };   // ID real do presente tem prioridade
  const key = Object.keys(byName).find((k) => k.toLowerCase() === String(ev.giftName || "").toLowerCase());
  if (key) return { ...d, ...byName[key] };
  const tiers = [...(cfg?.tiers || [])].sort((a, b) => b.minDiamonds - a.minDiamonds);
  const total = Number(ev.total) || 0;
  const tier = total > 0 ? tiers.find((t) => total >= t.minDiamonds) : null;
  return { ...d, ...(tier || {}) };
}
