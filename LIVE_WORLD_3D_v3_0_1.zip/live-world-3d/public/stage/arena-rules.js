// Regras puras da arena (sem THREE): vagas dos avatares, ranking de apoiadores e atividade real.
// Tudo aqui parte SOMENTE de eventos reais recebidos da LIVE; nada é inventado nem simulado.

/** Arena v3: pista de LED gigante (40 x 28) ao nível do chão, dentro de um galpão fechado. z negativo = fundo (telão + DJ).
 *  O centro e o tamanho são usados pelo cenário, pela câmera e pelas vagas. */
export const FLOOR = { w: 40, d: 28, cz: -3 };
/** Cabine de DJ: palco integrado ao fundo da arena. O DJ ativo (usuário real) fica em DJ_SPOT. */
export const DJ_SPOT = { x: 0, y: 1.25, z: -18.9 };

/** Vagas: 10 fileiras que alargam para o fundo, ordenadas do centro para fora. Poucas pessoas ficam juntas na frente do DJ;
 *  mais pessoas ocupam toda a largura da pista. Retorna [x, z]. */
export function makeSlots(n = 96) {
  const out = [], dx = 2.3, dz = 2.0, z0 = 8.2;
  for (let k = 0; k < 11; k++) {
    const count = Math.min(15, 6 + k);
    for (let i = 0; i < count; i++) out.push([(i - (count - 1) / 2) * dx, z0 - k * dz]);
  }
  out.sort((a, b) => Math.hypot(a[0] * 0.7, a[1] + 3) - Math.hypot(b[0] * 0.7, b[1] + 3));
  return out.slice(0, n);
}

/** Ranking de presentes: soma de diamantes reais por usuário. total <= 0 não conta. */
export function addGift(rank, user, total) {
  if (!user?.id || !(total > 0)) return;
  const r = rank.get(user.id) || { id: user.id, name: user.name, total: 0 };
  r.name = user.name || r.name; r.total += total; rank.set(user.id, r);
}
export function topSupporters(rank, n = 5) {
  return [...rank.values()].filter((r) => r.total > 0).sort((a, b) => b.total - a.total || String(a.name).localeCompare(String(b.name))).slice(0, n).map((r) => ({ id: r.id, name: r.name, total: r.total }));
}

/** A conexão do TikTok não avisa quando alguém sai. Quem fica sem nenhuma atividade real além do limite sai da arena. */
export const isActive = (lastActive, now, idleMs) => now - lastActive <= idleMs;
export const IDLE_DEFAULT_S = 300;
export function parseIdle(v) { const n = Number(v); return Number.isFinite(n) && n >= 15 && n <= 7200 ? n : IDLE_DEFAULT_S; }
export const fmtNum = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1).replace(/\.0$/, "") + "K" : String(n));
