// MEGA ARENA (v3.0): galpão fechado com pista de LED 40x28 no nível do chão, telão 30x12,5 embutido na parede, palco de DJ elevado,
// camarotes, colunas de neon, vigas, treliças, moving heads, lasers, fumaça e partículas. Neon azul/roxo/rosa.
// IMPORTANTE: o cenário NÃO contém nenhuma pessoa/silhueta/multidão. Só avatares de usuários reais da LIVE (engine.js) aparecem aqui.
// Itens decorativos novos ficam em safe(): se um falhar, a arena continua funcionando sem ele.
import * as THREE from "three";
import { FLOOR, DJ_SPOT, fmtNum } from "./arena-rules.js";
export const STAGE_Y = 0.03;                        // pista ao nível do chão (sem plataforma suspensa)
export const STAGE = { w: FLOOR.w, d: FLOOR.d };    // usado por characters.js (entrada/saída pela frente)
// Galpão: x de -26 a 26, z de -21 (fundo, com telão) a 36 (atrás da câmera), teto a 19 m.
const HALL_W = 26, HALL_Z0 = -21, HALL_Z1 = 36, CEIL = 19, RIG_Y = 15.2, SCR_W = 30, SCR_H = 12.5, SCR_Y = 12.1;

const safe = (name, fn) => { try { return fn(); } catch (e) { console.warn("cenário (item ignorado):", name, e); return null; } };
function canvasTex(w, h) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d"); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return { c, x, t, w, h };
}
const rng = (seed) => () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const hsl = (h, s, l, a = 1) => `hsla(${(((h % 360) + 360) % 360).toFixed(0)},${s}%,${l}%,${a})`;
const rrect = (x, px, py, w, h, r) => { x.beginPath(); if (x.roundRect) x.roundRect(px, py, w, h, r); else x.rect(px, py, w, h); };
// paleta do tema: azul 200–225, roxo 265–285, rosa 315–335
const THEME = [212, 275, 325];
const themeHue = (t, i = 0) => THEME[((Math.floor(t / 7 + i) % 3) + 3) % 3] + 10 * Math.sin(t * 0.7 + i);

// ---------- telão: programas de fundo (formato largo) ----------
const MODES = ["waves", "tunnel", "synth", "bars"];
function paintMode(mode, x, w, h, t, s) {
  const hue = themeHue(t), p = s.pulse || 0, e = s.energy || 0.4;
  if (mode === "waves") {
    for (let k = 0; k < 6; k++) {
      x.beginPath(); x.moveTo(0, h);
      for (let i = 0; i <= w; i += 16) x.lineTo(i, h * (0.4 + 0.08 * k) + Math.sin(i * 0.007 + t * (0.7 + k * 0.25) + k * 1.3) * h * (0.06 + 0.04 * e + 0.04 * p));
      x.lineTo(w, h); x.closePath(); x.fillStyle = hsl(THEME[k % 3] + 8 * k, 90, 52, 0.17 + 0.04 * k); x.fill();
    }
    x.globalCompositeOperation = "lighter";
    for (let k = 0; k < 4; k++) { const r = h * (0.4 + 0.15 * k) * (1 + 0.1 * p), cx = w * (0.12 + 0.25 * k); const g = x.createRadialGradient(cx, h * 0.35, 0, cx, h * 0.35, r); g.addColorStop(0, hsl(THEME[k % 3], 100, 60, 0.35)); g.addColorStop(1, hsl(THEME[k % 3], 100, 60, 0)); x.fillStyle = g; x.fillRect(0, 0, w, h); }
    x.globalCompositeOperation = "source-over";
  } else if (mode === "tunnel") {
    const cx = w / 2, cy = h * 0.5; x.lineJoin = "round";
    for (let i = 0; i < 18; i++) {
      const z = ((i + t * 0.9) % 18) / 18, k = z * z * 1.3 + 0.012, rw = w * k, rh = h * k;
      x.lineWidth = 2 + 10 * z; x.strokeStyle = hsl(THEME[i % 3] + 6 * Math.sin(i), 100, 58, Math.min(1, z * 1.6) * (0.55 + 0.4 * p)); x.strokeRect(cx - rw / 2, cy - rh / 2, rw, rh);
    }
  } else if (mode === "synth") {
    const hz = h * 0.58, g = x.createLinearGradient(0, hz - h * 0.5, 0, hz); g.addColorStop(0, hsl(300, 100, 60, 0.95)); g.addColorStop(1, hsl(335, 100, 58, 0.95));
    x.fillStyle = g; x.beginPath(); x.arc(w / 2, hz, h * (0.46 + 0.02 * p), Math.PI, 0); x.fill();
    x.fillStyle = "rgba(6,4,28,.93)"; x.fillRect(0, hz, w, h - hz);
    x.strokeStyle = hsl(212, 100, 62, 0.8); x.lineWidth = 2;
    for (let i = -20; i <= 20; i++) { x.beginPath(); x.moveTo(w / 2 + i * 18, hz); x.lineTo(w / 2 + i * 150, h); x.stroke(); }
    for (let i = 0; i < 9; i++) { const z = ((i + t * 0.6) % 9) / 9, y = hz + (h - hz) * z * z; x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); }
  } else {
    const n = s.spectrum.length, bw = w / n;
    for (let i = 0; i < n; i++) {
      const v = s.hasAudio ? Math.max(0.05, s.spectrum[i]) : 0.16 + 0.1 * Math.sin(t * 2.4 + i * 0.55) + 0.1 * p, bh = v * h * 0.8;
      const g = x.createLinearGradient(0, h - bh, 0, h); g.addColorStop(0, hsl(THEME[i % 3], 100, 64)); g.addColorStop(1, hsl(THEME[(i + 1) % 3], 100, 40));
      x.fillStyle = g; rrect(x, i * bw + 5, h - bh, bw - 10, bh, 8); x.fill(); x.fillStyle = "rgba(255,255,255,.85)"; x.fillRect(i * bw + 5, h - bh - 8, bw - 10, 4);
    }
  }
}

/** Desenha o telão. s = {spectrum, hasAudio, username, status, viewers, gifts, likes, ticker, alert, join, rank, now, pulse, energy, flash}.
 *  O ranking (s.rank) vem só de presentes reais; sem presentes, mostra "Aguardando presentes…". */
export function drawLed(L, s, t) {
  const { x, w, h } = L, k = w / 1280, hue = themeHue(t);
  if (L.mode === undefined) { L.mode = 0; L.prev = 0; L.mix = 1; L.at = t; L.last = t; }
  const dt = Math.min(0.5, Math.max(0, t - L.last)); L.last = t;
  if (t - L.at > 16) { L.prev = L.mode; L.mode = (L.mode + 1) % MODES.length; L.mix = 0; L.at = t; }
  L.mix = Math.min(1, L.mix + dt / 1.3);
  const bg = x.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, hsl(250, 70, 9)); bg.addColorStop(1, hsl(290, 75, 5)); x.fillStyle = bg; x.fillRect(0, 0, w, h);
  if (L.mix < 1) { paintMode(MODES[L.prev], x, w, h, t, s); x.globalAlpha = L.mix; }
  paintMode(MODES[L.mode], x, w, h, t, s); x.globalAlpha = 1;

  // cabeçalho
  const hb = x.createLinearGradient(0, 0, 0, 120 * k); hb.addColorStop(0, "rgba(0,0,14,.72)"); hb.addColorStop(1, "rgba(0,0,14,0)"); x.fillStyle = hb; x.fillRect(0, 0, w, 120 * k);
  x.textBaseline = "alphabetic"; x.textAlign = "left";
  const tg = x.createLinearGradient(30 * k, 0, 560 * k, 0); tg.addColorStop(0, "#35d6ff"); tg.addColorStop(0.55, "#ffffff"); tg.addColorStop(1, "#ff2d95");
  x.shadowColor = hsl(300, 100, 60, 0.9); x.shadowBlur = 18 * k; x.fillStyle = tg; x.font = `900 ${68 * k}px system-ui, sans-serif`; x.fillText("LIVE WORLD 3D", 34 * k, 72 * k);
  x.shadowBlur = 0; x.font = `700 ${26 * k}px system-ui, sans-serif`; x.fillStyle = s.status === "CONECTADO" ? "#7dffb2" : "#9ff5e6";
  x.fillText(s.username ? `● @${s.username} · ${s.status}` : `● ${s.status}`, 36 * k, 106 * k);
  x.font = `800 ${28 * k}px system-ui, sans-serif`; let cx = w - 28 * k;
  for (const [ic, v] of [["❤", s.likes], ["🎁", s.gifts], ["👥", s.viewers]]) {
    const txt = `${ic} ${fmtNum(v)}`, tw = x.measureText(txt).width + 28 * k; cx -= tw;
    rrect(x, cx, 26 * k, tw, 48 * k, 24 * k); x.fillStyle = "rgba(0,0,20,.55)"; x.fill(); x.strokeStyle = hsl(hue + 20, 100, 65, 0.8); x.lineWidth = 2; x.stroke();
    x.fillStyle = "#fff"; x.fillText(txt, cx + 14 * k, 60 * k); cx -= 10 * k;
  }
  // últimas mensagens (esquerda)
  const lines = s.ticker.slice(-4);
  x.font = `600 ${25 * k}px system-ui, sans-serif`;
  lines.forEach((line, i) => {
    const txt = line.length > 40 ? line.slice(0, 39) + "…" : line, tw = Math.min(w * 0.42, x.measureText(txt).width + 30 * k), y = 190 * k + i * 46 * k, last = i === lines.length - 1;
    rrect(x, 30 * k, y - 30 * k, tw, 40 * k, 20 * k); x.fillStyle = last ? "rgba(0,0,20,.64)" : "rgba(0,0,20,.4)"; x.fill();
    x.fillStyle = last ? "#fff" : "#b8c2e0"; x.fillText(txt, 44 * k, y);
  });
  // ranking: TOP 5 apoiadores (direita), somente dados reais de presentes
  const px = w - 392 * k, py = 124 * k, pw = 364 * k, ph = 352 * k;
  rrect(x, px, py, pw, ph, 22 * k); x.fillStyle = "rgba(6,6,28,.72)"; x.fill(); x.strokeStyle = hsl(hue + 40, 100, 66, 0.85); x.lineWidth = 3; x.stroke();
  x.textAlign = "center"; x.fillStyle = "#ffd76a"; x.font = `900 ${27 * k}px system-ui, sans-serif`; x.fillText("👑 TOP 5 APOIADORES", px + pw / 2, py + 40 * k); x.textAlign = "left";
  if (s.rank && s.rank[0]) { x.fillStyle = "#ffd76a"; x.font = `800 ${17 * k}px system-ui, sans-serif`; x.textAlign = "center"; x.fillText("MAIOR APOIADOR: " + s.rank[0].name.slice(0, 16), px + pw / 2, py + 66 * k); x.textAlign = "left"; }
  const rank = s.rank || [];
  if (!rank.length) { x.fillStyle = "#8f98bd"; x.font = `600 ${24 * k}px system-ui, sans-serif`; x.textAlign = "center"; x.fillText("Aguardando presentes…", px + pw / 2, py + ph / 2 + 12 * k); x.textAlign = "left"; }
  rank.slice(0, 5).forEach((r, i) => {
    const y = py + 104 * k + i * 54 * k, medal = ["#ffd76a", "#cfd6e6", "#d99058", "#6f7cff", "#6f7cff"][i];
    x.beginPath(); x.arc(px + 36 * k, y - 8 * k, 20 * k, 0, Math.PI * 2); x.fillStyle = medal; x.fill();
    x.fillStyle = "#10122a"; x.font = `900 ${24 * k}px system-ui, sans-serif`; x.textAlign = "center"; x.fillText(String(i + 1), px + 36 * k, y); x.textAlign = "left";
    x.fillStyle = i === 0 ? "#ffe9a8" : "#fff"; x.font = `700 ${25 * k}px system-ui, sans-serif`; const nm = r.name.length > 12 ? r.name.slice(0, 11) + "…" : r.name; x.fillText(nm, px + 70 * k, y);
    x.textAlign = "right"; x.fillStyle = "#ffd76a"; x.fillText(`💎 ${fmtNum(r.total)}`, px + pw - 20 * k, y); x.textAlign = "left";
  });
  // DJ ativo (usuário real) e fila
  if (s.dj && s.dj.name) {
    const txt = `🎧 DJ: ${s.dj.name.slice(0, 20)}` + (s.dj.queue ? `  ·  fila ${s.dj.queue}` : ""); x.font = `900 ${34 * k}px system-ui, sans-serif`;
    const tw = x.measureText(txt).width + 56 * k, bx = w / 2 - tw / 2;
    rrect(x, bx, 118 * k, tw, 56 * k, 28 * k); x.fillStyle = "rgba(20,4,40,.82)"; x.fill(); x.strokeStyle = hsl(325, 100, 66, 0.95); x.lineWidth = 3; x.stroke();
    x.fillStyle = "#fff"; x.textAlign = "center"; x.fillText(txt, w / 2, 157 * k); x.textAlign = "left";
  } else if (s.dj && s.dj.queue) {
    x.font = `700 ${24 * k}px system-ui, sans-serif`; x.fillStyle = "#cfd6ff"; x.textAlign = "center"; x.fillText(`Fila para DJ: ${s.dj.queue} (comente !dj)`, w / 2, 150 * k); x.textAlign = "left";
  }
  // quem acabou de entrar (real)
  if (s.join && s.now < s.join.until) {
    const age = Math.min(1, (s.join.until - s.now) / 3200), slide = Math.min(1, (1 - age) * 6) * (age < 0.15 ? age / 0.15 : 1);
    const txt = `👋 ${s.join.text.slice(0, 22)} entrou!`; x.font = `800 ${30 * k}px system-ui, sans-serif`;
    const tw = x.measureText(txt).width + 44 * k, bx = 30 * k - (1 - slide) * (tw + 40 * k);
    rrect(x, bx, h - 90 * k, tw, 52 * k, 26 * k); x.fillStyle = hsl(hue + 120, 90, 42, 0.92); x.fill(); x.fillStyle = "#fff"; x.fillText(txt, bx + 22 * k, h - 54 * k);
  }
  // alerta de presente (real)
  if (s.alert && s.now < s.alert.until) {
    const age = Math.min(1, Math.max(0, 1 - (s.alert.until - s.now) / 4500)), pop = 1 + 0.05 * Math.sin(t * 14) + (age < 0.1 ? (0.1 - age) * 3 : 0), ay = h * 0.7;
    x.globalCompositeOperation = "lighter"; x.lineWidth = 10 * k * (1 - age); x.strokeStyle = hsl(hue + 40, 100, 65, 0.9 * (1 - age));
    x.beginPath(); x.arc(w * 0.42, ay, age * w * 0.5, 0, Math.PI * 2); x.stroke(); x.globalCompositeOperation = "source-over";
    x.save(); x.translate(w * 0.42, ay); x.scale(pop, pop);
    const bgr = x.createLinearGradient(-w * 0.34, 0, w * 0.34, 0); bgr.addColorStop(0, "rgba(255,45,149,.88)"); bgr.addColorStop(1, "rgba(53,214,255,.88)");
    rrect(x, -w * 0.34, -62 * k, w * 0.68, 124 * k, 30 * k); x.fillStyle = bgr; x.fill(); x.strokeStyle = "#fff"; x.lineWidth = 4; x.stroke();
    x.textAlign = "center"; x.fillStyle = "#fff"; x.shadowColor = "#000"; x.shadowBlur = 8; x.font = `900 ${50 * k}px system-ui, sans-serif`; x.fillText("🎁 " + s.alert.text.slice(0, 34), 0, 8 * k);
    x.font = `700 ${28 * k}px system-ui, sans-serif`; x.fillText(s.alert.sub || "", 0, 46 * k); x.shadowBlur = 0; x.restore();
  }
  x.strokeStyle = hsl(hue + 20, 100, 65, 0.9); x.lineWidth = 5; const m = 14, c = 50 * k;
  for (const [qx, qy, dx, dy] of [[m, m, 1, 1], [w - m, m, -1, 1], [m, h - m, 1, -1], [w - m, h - m, -1, -1]]) { x.beginPath(); x.moveTo(qx, qy + dy * c); x.lineTo(qx, qy); x.lineTo(qx + dx * c, qy); x.stroke(); }
  if (s.flash > 0.02) { x.fillStyle = `rgba(255,255,255,${(0.4 * s.flash).toFixed(3)})`; x.fillRect(0, 0, w, h); }
  L.t.needsUpdate = true;
}

export function buildWorld(scene, q) {
  scene.background = new THREE.Color(0x03031a);
  scene.fog = new THREE.FogExp2(0x070722, 0.0075);
  scene.add(new THREE.HemisphereLight(0x8fa0ff, 0x2a1647, 1.2));
  const key = new THREE.DirectionalLight(0xffffff, 1.15); key.position.set(4, 18, 20); key.target.position.set(0, 0, -4); scene.add(key, key.target);
  if (q >= 2) {
    key.castShadow = true; key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -22, right: 22, top: 20, bottom: -20, near: 1, far: 60 }); key.shadow.bias = -0.0005;
  }
  const rimA = new THREE.DirectionalLight(0xff3da0, 1.0), rimB = new THREE.DirectionalLight(0x35a6ff, 1.0);
  rimA.position.set(-14, 10, -20); rimB.position.set(14, 10, -20); scene.add(rimA, rimB);
  const washes = [0xff2d95, 0x35a6ff, 0xa66bff, 0x35a6ff, 0xff2d95].map((c, i) => { const l = new THREE.PointLight(c, q ? 90 : 50, 46, 2); l.position.set((i - 2) * 9, 9, -6 + (i % 2) * 6); scene.add(l); return l; });
  const H = { flash: 0, hue: 0 }, A = { energy: 0.4, pulse: 0 }, DJ = { name: "" };
  const statics = [], add = (m, x = 0, y = 0, z = 0, isStatic = true) => { m.position.set(x, y, z); scene.add(m); if (isStatic) statics.push(m); return m; };
  const GC = new Map(), box = (w, h, d) => { const k = `${w}|${h}|${d}`; let g = GC.get(k); if (!g) { g = new THREE.BoxGeometry(w, h, d); GC.set(k, g); } return g; };
  const dark = new THREE.MeshStandardMaterial({ color: 0x0c0d22, roughness: 0.55, metalness: 0.6 }), metal = new THREE.MeshStandardMaterial({ color: 0x1a1d34, metalness: 0.8, roughness: 0.35 });
  const wallM = new THREE.MeshStandardMaterial({ color: 0x0a0b1e, roughness: 0.8, metalness: 0.3, side: THREE.DoubleSide });
  const mkNeon = (hue) => new THREE.MeshBasicMaterial({ color: new THREE.Color().setHSL(hue / 360, 1, 0.6) });
  const neonB = mkNeon(212), neonV = mkNeon(275), neonP = mkNeon(325);
  const glow = canvasTex(128, 128), gg = glow.x.createRadialGradient(64, 64, 0, 64, 64, 64);
  gg.addColorStop(0, "rgba(255,255,255,.9)"); gg.addColorStop(0.45, "rgba(255,255,255,.35)"); gg.addColorStop(1, "rgba(255,255,255,0)"); glow.x.fillStyle = gg; glow.x.fillRect(0, 0, 128, 128); glow.t.needsUpdate = true;

  // ---------- galpão fechado: piso contínuo, paredes, teto ----------
  const FZ0 = FLOOR.cz - FLOOR.d / 2, FZ1 = FLOOR.cz + FLOOR.d / 2;          // limites da pista (z)
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(HALL_W * 2, HALL_Z1 - HALL_Z0), new THREE.MeshStandardMaterial({ color: 0x090a1c, roughness: 0.22, metalness: 0.7 }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; add(ground, 0, 0, (HALL_Z0 + HALL_Z1) / 2);
  add(new THREE.Mesh(box(HALL_W * 2 + 1, CEIL + 1, 0.6), wallM), 0, CEIL / 2, HALL_Z0 - 0.3);        // fundo
  add(new THREE.Mesh(box(HALL_W * 2 + 1, CEIL + 1, 0.6), wallM), 0, CEIL / 2, HALL_Z1 + 0.3);        // frente (atrás da câmera)
  for (const sx of [-1, 1]) add(new THREE.Mesh(box(0.6, CEIL + 1, HALL_Z1 - HALL_Z0), wallM), sx * (HALL_W + 0.3), CEIL / 2, (HALL_Z0 + HALL_Z1) / 2);
  add(new THREE.Mesh(new THREE.PlaneGeometry(HALL_W * 2, HALL_Z1 - HALL_Z0), new THREE.MeshBasicMaterial({ color: 0x04041a, side: THREE.DoubleSide })), 0, CEIL, (HALL_Z0 + HALL_Z1) / 2).rotation.x = Math.PI / 2;
  // faixas de LED nas paredes (profundidade e escala)
  for (const sx of [-1, 1]) for (const [y, m] of [[2.6, neonB], [9.0, neonV], [15.5, neonP]]) add(new THREE.Mesh(box(0.1, 0.14, HALL_Z1 - HALL_Z0 - 2), m), sx * (HALL_W - 0.1), y, (HALL_Z0 + HALL_Z1) / 2);
  for (const [y, m] of [[2.6, neonB], [15.5, neonP]]) add(new THREE.Mesh(box(HALL_W * 2 - 2, 0.14, 0.1), m), 0, y, HALL_Z0 + 0.1);

  // ---------- pista de LED gigante (ao nível do chão) ----------
  const FC = q === 0 ? 6 : 12, fl = canvasTex(FLOOR.w * FC, FLOOR.d * FC);
  const topMat = new THREE.MeshStandardMaterial({ color: 0x0b0d1a, map: fl.t, emissive: 0xffffff, emissiveMap: fl.t, emissiveIntensity: 0.95, roughness: 0.15, metalness: 0.55 });
  const dance = new THREE.Mesh(new THREE.PlaneGeometry(FLOOR.w, FLOOR.d), topMat); dance.rotation.x = -Math.PI / 2; dance.receiveShadow = true; add(dance, 0, STAGE_Y, FLOOR.cz);
  const CX = FLOOR.w / 2, CY = FLOOR.d / 2;
  const drawFloor = (t) => {
    const x = fl.x, cw = fl.w / FLOOR.w, ch = fl.h / FLOOR.d; x.fillStyle = "#05060e"; x.fillRect(0, 0, fl.w, fl.h);
    for (let cy = 0; cy < FLOOR.d; cy++) for (let cx = 0; cx < FLOOR.w; cx++) {
      const d0 = Math.hypot(cx - CX, (cy - CY) * 1.3);
      const v = Math.sin(cx * 0.4 + t * 1.1) + Math.sin(cy * 0.55 - t * 0.8) + Math.sin((cx + cy) * 0.28 + t * 0.6) + Math.sin(d0 * 0.45 - t * 1.4);
      const hue = 285 + 55 * Math.sin(v * 0.9 + H.hue * 3 * H.flash), ring = Math.max(0, Math.sin(d0 * 0.8 - t * 3));
      const l = (12 + 18 * (0.5 + 0.5 * Math.sin(v * 1.7 + t)) + 24 * ring * (A.pulse + 0.25 * A.energy) + 12 * H.flash) * ((cx + cy) % 2 ? 0.74 : 1);
      x.fillStyle = hsl(hue, 90, Math.min(66, l)); x.fillRect(cx * cw + 1, cy * ch + 1, cw - 2, ch - 2);
    }
    fl.t.needsUpdate = true;
  };
  drawFloor(0);
  for (const [w, d, px, pz, m] of [[FLOOR.w + 0.3, 0.16, 0, FZ1 + 0.08, neonP], [FLOOR.w + 0.3, 0.16, 0, FZ0 - 0.08, neonB], [0.16, FLOOR.d, -CX - 0.08, FLOOR.cz, neonV], [0.16, FLOOR.d, CX + 0.08, FLOOR.cz, neonV]]) add(new THREE.Mesh(box(w, 0.06, d), m), px, STAGE_Y + 0.01, pz);
  const disc = canvasTex(512, 512), dx = disc.x, rg = dx.createRadialGradient(256, 256, 0, 256, 256, 256);
  rg.addColorStop(0, "rgba(255,255,255,.3)"); rg.addColorStop(0.6, "rgba(120,140,255,.12)"); rg.addColorStop(1, "rgba(0,0,0,0)"); dx.fillStyle = rg; dx.fillRect(0, 0, 512, 512);
  dx.lineWidth = 6; for (const [r, c] of [[236, "#ff2d95"], [200, "#35d6ff"], [120, "#a66bff"], [60, "#ffffff"]]) { dx.strokeStyle = c; dx.beginPath(); dx.arc(256, 256, r, 0, Math.PI * 2); dx.stroke(); }
  dx.lineWidth = 3; dx.strokeStyle = "rgba(160,190,255,.7)"; for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; dx.beginPath(); dx.moveTo(256 + Math.cos(a) * 66, 256 + Math.sin(a) * 66); dx.lineTo(256 + Math.cos(a) * 196, 256 + Math.sin(a) * 196); dx.stroke(); }
  disc.t.needsUpdate = true;
  const discMat = new THREE.MeshBasicMaterial({ map: disc.t, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  const discMesh = new THREE.Mesh(new THREE.CircleGeometry(11, 64), discMat); discMesh.rotation.x = -Math.PI / 2; add(discMesh, 0, STAGE_Y + 0.012, FLOOR.cz + 1, false);

  // ---------- telão gigante embutido na parede do fundo ----------
  const LQ = [[768, 320], [1024, 427], [1536, 640]][q] || [1024, 427];
  const led = canvasTex(LQ[0], LQ[1]);
  const wallMat = new THREE.MeshBasicMaterial({ map: led.t, toneMapped: false, fog: false });
  add(new THREE.Mesh(new THREE.PlaneGeometry(SCR_W, SCR_H), wallMat), 0, SCR_Y, HALL_Z0 + 0.45);
  add(new THREE.Mesh(box(SCR_W + 1, SCR_H + 1, 0.3), metal), 0, SCR_Y, HALL_Z0 + 0.15);   // moldura ATRÁS da tela (evita z-fighting)
  safe("pixels do telão", () => {
    const mk = canvasTex(16, 16); mk.x.fillStyle = "rgba(0,0,0,.6)"; mk.x.fillRect(0, 0, 16, 2.4); mk.x.fillRect(0, 0, 2.4, 16); mk.t.wrapS = mk.t.wrapT = THREE.RepeatWrapping; mk.t.repeat.set(SCR_W / 0.09, SCR_H / 0.09); mk.t.needsUpdate = true;
    add(new THREE.Mesh(new THREE.PlaneGeometry(SCR_W, SCR_H), new THREE.MeshBasicMaterial({ map: mk.t, transparent: true, depthWrite: false, toneMapped: false })), 0, SCR_Y, HALL_Z0 + 0.47);
  });
  for (const [w, h, px, py, m] of [[SCR_W + 1.4, 0.2, 0, SCR_H / 2 + 0.6, neonP], [SCR_W + 1.4, 0.2, 0, -SCR_H / 2 - 0.6, neonB], [0.2, SCR_H + 1.4, -SCR_W / 2 - 0.75, 0, neonV], [0.2, SCR_H + 1.4, SCR_W / 2 + 0.75, 0, neonV]]) add(new THREE.Mesh(box(w, h, 0.15), m), px, SCR_Y + py, HALL_Z0 + 0.5);

  // ---------- cabine de DJ: palco elevado integrado ao fundo ----------
  const djf = canvasTex(512, 128), djMat = new THREE.MeshBasicMaterial({ map: djf.t, toneMapped: false, fog: false });
  const drawDj = (t) => {
    const x = djf.x; x.fillStyle = "#06061a"; x.fillRect(0, 0, 512, 128);
    for (let i = 0; i < 32; i++) { const v = 0.15 + 0.5 * Math.max(0, Math.sin(i * 0.5 - t * 6)) + 0.4 * A.pulse; x.fillStyle = hsl(THEME[i % 3], 100, 55); x.fillRect(i * 16 + 2, 124 - 70 * v, 12, 70 * v); }
    x.textAlign = "center"; x.font = "900 44px system-ui, sans-serif"; x.fillStyle = "#fff"; x.shadowColor = hsl(300, 100, 60); x.shadowBlur = 14;
    x.fillText(DJ.name ? "DJ " + DJ.name.slice(0, 14) : "LIVE WORLD 3D", 256, 54); x.shadowBlur = 0; djf.t.needsUpdate = true;
  };
  drawDj(0);
  const turntables = [], woofers = [], PZ = HALL_Z0 + 2.6, DY = DJ_SPOT.y;
  safe("cabine de DJ", () => {
    add(new THREE.Mesh(box(15, DY, 5), dark), 0, DY / 2, PZ);                                                          // palco elevado
    add(new THREE.Mesh(box(15.2, 0.08, 0.1), neonB), 0, DY + 0.02, PZ + 2.55); add(new THREE.Mesh(box(15.2, 0.08, 0.1), neonP), 0, 0.15, PZ + 2.55);
    for (const sx of [-1, 1]) for (let i = 0; i < 4; i++) { const h = (i + 1) * (DY / 4); add(new THREE.Mesh(box(2.2, h, 0.7), dark), sx * 8.7, h / 2, PZ + 2.9 - i * 0.7); add(new THREE.Mesh(box(2.2, 0.04, 0.06), i % 2 ? neonP : neonB), sx * 8.7, h, PZ + 2.9 - i * 0.7 + 0.35); } // escadas laterais
    add(new THREE.Mesh(box(7, 1.1, 1.5), metal), 0, DY + 0.55, PZ + 1.1);                                              // mesa do DJ
    add(new THREE.Mesh(new THREE.PlaneGeometry(6.7, 0.95), djMat), 0, DY + 0.58, PZ + 1.86);
    add(new THREE.Mesh(box(7.2, 0.08, 1.7), neonP), 0, DY + 1.12, PZ + 1.1);
    for (const sx of [-1, 1]) {
      const tt = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.05, 28), new THREE.MeshStandardMaterial({ color: 0x15162c, metalness: 0.8, roughness: 0.3, emissive: 0x2233aa, emissiveIntensity: 0.6 })); add(tt, sx * 2.0, DY + 1.17, PZ + 1.1, false); turntables.push(tt);
      add(new THREE.Mesh(box(2.2, 5.2, 1.8), metal), sx * 6.0, DY + 2.6, PZ - 0.2);                                    // caixas de som
      for (const [wy, wr] of [[DY + 1.7, 0.8], [DY + 4.0, 0.42]]) {
        const wf = new THREE.Mesh(new THREE.CircleGeometry(wr, 28), new THREE.MeshBasicMaterial({ color: 0x35a6ff })); add(wf, sx * 6.0, wy, PZ + 0.71, false); woofers.push(wf);
        add(new THREE.Mesh(new THREE.TorusGeometry(wr + 0.05, 0.05, 6, 28), neonP), sx * 6.0, wy, PZ + 0.72);
      }
      add(new THREE.Mesh(box(0.3, 4.2, 0.3), metal), sx * 4.2, DY + 2.1, PZ + 2.0);                                     // portal de treliça
    }
    add(new THREE.Mesh(box(8.8, 0.3, 0.3), metal), 0, DY + 4.2, PZ + 2.0); add(new THREE.Mesh(box(8.6, 0.08, 0.08), neonV), 0, DY + 4.0, PZ + 2.15);
  });

  // ---------- colunas de neon, camarotes elevados, escadas ----------
  const side = canvasTex(512, 192), sideMatL = new THREE.MeshBasicMaterial({ map: side.t, toneMapped: false, fog: false });
  const drawSide = (t) => {
    const x = side.x; x.fillStyle = "#05050f"; x.fillRect(0, 0, 512, 192);
    x.textAlign = "center"; x.font = "italic 900 58px system-ui, sans-serif"; x.shadowBlur = 18; x.shadowColor = hsl(325, 100, 60); x.fillStyle = hsl(325, 100, 72); x.fillText("DANCE", 256, 70);
    x.shadowColor = hsl(212, 100, 60); x.fillStyle = hsl(212, 100, 75); x.fillText("FOREVER", 256, 135); x.shadowBlur = 0;
    for (let i = 0; i < 24; i++) { const v = 0.1 + 0.9 * Math.max(0, Math.sin(i * 0.6 - t * 5)) * (0.4 + A.pulse); x.fillStyle = hsl(THEME[i % 3], 100, 58); x.fillRect(i * 21 + 4, 188 - 22 * v, 14, 22 * v); }
    side.t.needsUpdate = true;
  };
  drawSide(0);
  const rings = [], MZ0 = -16, MZ1 = 9, MY = 4.4, MX0 = 20.5;                                                       // camarote: x 20.5..26, y 4.4
  safe("laterais", () => {
    for (const sx of [-1, 1]) {
      for (const pz of [-6, 3.5]) { const pn = new THREE.Mesh(new THREE.PlaneGeometry(13, 4.9), sideMatL); pn.rotation.y = -sx * Math.PI / 2; add(pn, sx * (HALL_W - 0.25), 10.6, pz); }
      add(new THREE.Mesh(box(HALL_W - MX0, 0.4, MZ1 - MZ0), metal), sx * (MX0 + HALL_W) / 2, MY, (MZ0 + MZ1) / 2);   // laje do camarote
      add(new THREE.Mesh(box(0.12, 0.12, MZ1 - MZ0), neonV), sx * MX0, MY + 1.15, (MZ0 + MZ1) / 2); add(new THREE.Mesh(box(0.12, 0.12, MZ1 - MZ0), neonB), sx * MX0, MY + 0.05, (MZ0 + MZ1) / 2);
      add(new THREE.Mesh(box(0.05, 1.1, MZ1 - MZ0), new THREE.MeshBasicMaterial({ color: 0x35a6ff, transparent: true, opacity: 0.16, depthWrite: false })), sx * MX0, MY + 0.6, (MZ0 + MZ1) / 2); // guarda-corpo de vidro
      for (let i = 0; i < 5; i++) { const z = MZ0 + 2 + i * 5.2; add(new THREE.Mesh(box(2.6, 0.5, 1.4), dark), sx * 24, MY + 0.45, z); add(new THREE.Mesh(box(2.6, 0.9, 0.3), dark), sx * 24.7, MY + 0.9, z); add(new THREE.Mesh(box(1.4, 0.06, 0.6), neonP), sx * 22.3, MY + 0.4, z); } // sofás e mesas
      for (let i = 0; i < 12; i++) {                                                                                    // escada até o camarote
        const hgt = (i + 1) * (MY / 12); add(new THREE.Mesh(box(2.6, hgt, 0.5), dark), sx * 23.2, hgt / 2, MZ1 + 5.7 - i * 0.5);
        add(new THREE.Mesh(box(2.6, 0.04, 0.05), i % 2 ? neonP : neonB), sx * 23.2, hgt + 0.02, MZ1 + 5.7 - i * 0.5 + 0.25);
      }
      const cols = [-14, -7, 0, 7];                                                                                      // colunas com anéis de neon
      for (const pz of cols) {
        add(new THREE.Mesh(box(1.1, CEIL - 1, 1.1), metal), sx * 18, (CEIL - 1) / 2, pz);
        for (let i = 0; i < 5; i++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.08, 6, 24), i % 2 ? neonB : neonV); r.rotation.x = Math.PI / 2; add(r, sx * 18, 1 + i * 0.7, pz); }
        add(new THREE.Mesh(box(1.1, 0.1, 1.1), neonP), sx * 18, 6.2, pz);
        const gl = new THREE.Mesh(new THREE.CircleGeometry(2.2, 20), new THREE.MeshBasicMaterial({ map: glow.t, color: 0x7a6bff, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false })); gl.rotation.x = -Math.PI / 2; add(gl, sx * 17, 0.03, pz, false); rings.push(gl);
      }
    }
  });

  // ---------- teto: vigas, anéis de LED, globo, treliças de iluminação ----------
  const ringMeshes = safe("anéis do teto", () => [[8, 0.25, neonP], [10, 0.1, neonB]].map(([r, tube, m]) => { const g = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 8, 90), m); g.rotation.x = Math.PI / 2; add(g, 0, CEIL - 1.6, FLOOR.cz, false); return g; })) || [];
  const ball = safe("globo", () => {
    const g = new THREE.Mesh(new THREE.IcosahedronGeometry(1.5, 2), new THREE.MeshStandardMaterial({ color: 0xdfe4ff, metalness: 0.95, roughness: 0.18, flatShading: true, emissive: 0x2a2a66, emissiveIntensity: 0.7 }));
    add(g, 0, RIG_Y - 1.8, FLOOR.cz, false); add(new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 4, 6), metal), 0, CEIL - 1.5, FLOOR.cz); return g;
  });
  safe("vigas e treliças", () => {
    for (const z of [-15, -9, -3, 3, 9]) { add(new THREE.Mesh(box(HALL_W * 2, 0.6, 0.6), metal), 0, CEIL - 0.5, z); add(new THREE.Mesh(box(HALL_W * 2 - 4, 0.08, 0.08), z % 2 ? neonB : neonV), 0, CEIL - 0.95, z); }
    for (const z of [-12, -6, 0, 6]) { add(new THREE.Mesh(box(36, 0.35, 0.35), metal), 0, RIG_Y, z); for (const x of [-16, 16]) add(new THREE.Mesh(box(0.15, CEIL - RIG_Y, 0.15), metal), x, (CEIL + RIG_Y) / 2, z); }
    const R = rng(11), n = q ? 380 : 180, a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { a[i * 3] = (R() - 0.5) * HALL_W * 2; a[i * 3 + 1] = CEIL - 0.1; a[i * 3 + 2] = HALL_Z0 + R() * (HALL_Z1 - HALL_Z0); }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(a, 3));
    scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffb070, size: 0.18, transparent: true, opacity: 0.9, fog: false, depthWrite: false })));
  });

  // ---------- moving heads, lasers, fumaça e partículas ----------
  const heads = [], HP = [];
  for (const z of [-12, -6, 0, 6]) for (const x of [-14, -7, 0, 7, 14]) HP.push([x, z]);
  const nHeads = [8, 14, 20][q] || 14, BEAM = RIG_Y - STAGE_Y - 0.3, headY = RIG_Y - 0.3;
  const beamGeo = new THREE.ConeGeometry(1.7, BEAM, 18, 1, true); beamGeo.translate(0, -BEAM / 2, 0);
  for (let i = 0; i < nHeads; i++) {
    const pivot = new THREE.Group(); pivot.position.set(HP[i][0], headY, HP[i][1]);
    pivot.add(new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.15, 0.5, 10), metal));
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    pivot.add(new THREE.Mesh(beamGeo, mat)); scene.add(pivot);
    const pm = new THREE.MeshBasicMaterial({ map: glow.t, color: 0xffffff, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
    const pool = safe("poça de luz", () => { const m = new THREE.Mesh(new THREE.CircleGeometry(2.1, 24), pm); m.rotation.x = -Math.PI / 2; m.visible = false; scene.add(m); return m; });
    heads.push({ pivot, mat, pm, pool, i });
  }
  const lasers = [], LN = q >= 2 ? 16 : q === 1 ? 10 : 0;
  for (let i = 0; i < LN; i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.025, 40, 0.025).translate(0, -20, 0), new THREE.MeshBasicMaterial({ color: i % 2 ? 0xff2d95 : 0x35d6ff, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false }));
    m.position.set(-12 + i * (24 / Math.max(1, LN - 1)), CEIL - 3, HALL_Z0 + 2); scene.add(m); lasers.push(m);
  }
  const jets = [], JN = q ? 46 : 24;
  safe("jatos de fumaça", () => {
    for (const sx of [-1, 1]) {
      const pos = new Float32Array(JN * 3), life = new Float32Array(JN), vel = new Float32Array(JN * 3), R = rng(31 + sx);
      for (let i = 0; i < JN; i++) { life[i] = R(); pos[i * 3 + 1] = -50; }
      const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      const m = new THREE.PointsMaterial({ map: glow.t, color: 0xb9a6ff, size: 4, transparent: true, opacity: 0.2, depthWrite: false, blending: THREE.AdditiveBlending });
      const pts = new THREE.Points(g, m); pts.frustumCulled = false; scene.add(pts); jets.push({ pos, life, vel, g, m, sx, R });
    }
  });
  const R0 = rng(21), SP = q ? 260 : 120, spArr = new Float32Array(SP * 3);
  for (let i = 0; i < SP; i++) { spArr[i * 3] = (R0() - 0.5) * FLOOR.w; spArr[i * 3 + 1] = 1 + R0() * 12; spArr[i * 3 + 2] = FZ0 + R0() * FLOOR.d; }
  const spG = new THREE.BufferGeometry(); spG.setAttribute("position", new THREE.BufferAttribute(spArr, 3));
  const sparkMat = new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.11, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const sparkles = new THREE.Points(spG, sparkMat); scene.add(sparkles);
  let haze = null;
  if (q >= 1) {
    const R = rng(3), hp = new Float32Array(200 * 3); for (let i = 0; i < 200; i++) { hp[i * 3] = (R() - 0.5) * FLOOR.w; hp[i * 3 + 1] = 0.6 + R() * 9; hp[i * 3 + 2] = FZ0 + R() * FLOOR.d; }
    const hg = new THREE.BufferGeometry(); hg.setAttribute("position", new THREE.BufferAttribute(hp, 3));
    haze = new THREE.Points(hg, new THREE.PointsMaterial({ map: glow.t, color: 0x6677ff, size: 6, transparent: true, opacity: 0.06, depthWrite: false, blending: THREE.AdditiveBlending })); scene.add(haze);
  }
  statics.forEach((m) => { m.updateMatrix(); m.matrixAutoUpdate = false; });
  let slowT = 0;

  function hype(kind, hue) { H.flash = Math.max(H.flash, kind === "gift" ? 1 : kind === "join" ? 0.5 : kind === "epic" ? 1.4 : 0.22); H.hue = typeof hue === "number" ? hue : Math.random(); if (kind === "gift" || kind === "epic") jets.forEach((j) => { j.boost = kind === "epic" ? 3 : 1.2; }); }

  function update(t, dt, a) {
    A.energy = a.energy; A.pulse = a.pulse; H.flash = Math.max(0, H.flash - dt * 1.4); const fl_ = Math.min(1.4, H.flash);
    neonB.color.setHSL((212 + 8 * Math.sin(t * 0.6)) / 360, 1, 0.6); neonV.color.setHSL((275 + 8 * Math.sin(t * 0.5 + 1)) / 360, 1, 0.62); neonP.color.setHSL((325 + 8 * Math.sin(t * 0.7 + 2)) / 360, 1, 0.62);
    discMesh.rotation.z = t * 0.12; discMat.opacity = 0.5 + 0.45 * (0.4 * a.energy + a.pulse);
    sparkMat.opacity = 0.45 + 0.25 * Math.sin(t * 3); sparkles.rotation.y = t * 0.012;
    rimA.intensity = 1.0 + 0.7 * a.pulse + 1.6 * fl_; rimB.intensity = 1.0 + 0.7 * a.pulse + 1.6 * fl_;
    washes.forEach((l, i) => { l.intensity = (q ? 90 : 50) * (0.75 + 0.7 * a.pulse + 0.15 * Math.sin(t * 2 + i) + 1.1 * fl_); });
    wallMat.color.setScalar(1 + 0.06 * a.pulse + 0.4 * fl_);
    ringMeshes.forEach((m, i) => { m.rotation.z = t * (0.1 + 0.05 * i); });
    if (ball) { ball.rotation.y = t * 0.35; ball.rotation.x = 0.2 * Math.sin(t * 0.2); }
    turntables.forEach((m, i) => { m.rotation.y = t * (i ? -1.6 : 1.6); });
    woofers.forEach((m, i) => { m.scale.setScalar(1 + 0.12 * a.pulse + 0.04 * Math.sin(t * 8 + i)); });
    rings.forEach((m, i) => { m.material.opacity = 0.25 + 0.3 * a.pulse + 0.2 * Math.sin(t * 2 + i); });
    for (const h of heads) {
      const rx = Math.sin(t * 0.7 + h.i * 0.8) * 0.5 + a.pulse * 0.06, rz = Math.cos(t * 0.5 + h.i * 1.3) * 0.62;
      h.pivot.rotation.x = rx; h.pivot.rotation.z = rz;
      h.mat.color.setHSL(THEME[(h.i + Math.floor(t / 6)) % 3] / 360, 1, 0.6); h.mat.opacity = 0.05 + 0.08 * (0.4 + a.energy) + 0.1 * a.pulse + 0.16 * fl_;
      if (h.pool) {
        const cz = Math.cos(rz), cx = Math.cos(rx), dist = (headY - STAGE_Y) / Math.max(0.3, cz * cx);
        const px = h.pivot.position.x + dist * Math.sin(rz), pz = h.pivot.position.z - dist * cz * Math.sin(rx), onFloor = Math.abs(px) < FLOOR.w / 2 && Math.abs(pz - FLOOR.cz) < FLOOR.d / 2;
        h.pool.position.set(px, onFloor ? STAGE_Y + 0.025 : 0.03, pz); h.pool.visible = Number.isFinite(px + pz);
        h.pm.color.copy(h.mat.color); h.pm.opacity = 0.28 + 0.3 * a.pulse + 0.3 * fl_;
      }
    }
    lasers.forEach((m, i) => { m.rotation.z = Math.sin(t * 0.9 + i) * 1.0; m.rotation.x = -(0.35 + Math.cos(t * 0.6 + i * 1.7) * 0.35); m.material.opacity = 0.2 + 0.5 * a.pulse + 0.35 * fl_; });
    for (const j of jets) {
      j.boost = Math.max(0, (j.boost || 0) - dt); const sp = 1 + 1.4 * (j.boost > 0 ? 1 : 0) + a.pulse;
      for (let i = 0; i < JN; i++) {
        j.life[i] += dt * 0.3 * sp;
        if (j.life[i] >= 1) { j.life[i] = 0; j.pos[i * 3] = j.sx * 11 + (j.R() - 0.5) * 1.0; j.pos[i * 3 + 1] = 0.4; j.pos[i * 3 + 2] = FZ0 + 0.8 + (j.R() - 0.5) * 0.8; j.vel[i * 3] = (j.R() - 0.5) * 0.5; j.vel[i * 3 + 1] = 2.6 + j.R() * 1.6; j.vel[i * 3 + 2] = j.R() * 0.9; }
        j.pos[i * 3] += j.vel[i * 3] * dt * sp; j.pos[i * 3 + 1] += j.vel[i * 3 + 1] * dt * sp; j.pos[i * 3 + 2] += j.vel[i * 3 + 2] * dt * sp;
      }
      j.g.attributes.position.needsUpdate = true; j.m.opacity = 0.14 + 0.08 * a.energy;
    }
    if (haze) haze.rotation.y = t * 0.008;
    if ((slowT += dt) > (q ? 0.1 : 0.15)) { slowT = 0; drawFloor(t); drawDj(t); drawSide(t); }
  }
  return { update, hype, led, setDj: (n) => { DJ.name = n || ""; }, drawLed: (s, t) => drawLed(led, { ...s, pulse: A.pulse, energy: A.energy, flash: H.flash }, t) };
}
