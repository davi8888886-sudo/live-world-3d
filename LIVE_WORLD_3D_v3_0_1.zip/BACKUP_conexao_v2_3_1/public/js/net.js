// WebSocket com reconexão automática (backoff 0,5s → 10s). Usado pelo painel e pelo palco.
export function connectSocket({ onMessage, onOpen, onClose }) {
  let ws, retry = 0, timer, closed = false;
  const url = () => `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`;
  function open() {
    clearTimeout(timer);
    ws = new WebSocket(url());
    ws.onopen = () => { retry = 0; onOpen?.(); };
    ws.onmessage = (e) => { try { onMessage(JSON.parse(e.data)); } catch { /* ignora */ } };
    ws.onclose = () => {
      onClose?.();
      if (closed) return;
      timer = setTimeout(open, Math.min(10000, 500 * 2 ** retry++));
    };
    ws.onerror = () => ws.close();
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && ws && ws.readyState > 1 && !closed) { retry = 0; open(); }
  });
  open();
  return {
    send: (o) => { if (ws?.readyState === 1) ws.send(JSON.stringify(o)); },
    close() { closed = true; clearTimeout(timer); ws?.close(); },
    get open() { return ws?.readyState === 1; },
  };
}
