// ARENA FUTURISTA (v2.4): casa noturna/festival gigante — pista de LED 26x18, telão central enorme, cabine de DJ,
// pilares de neon, mezaninos, anel de LED + globo, moving heads, lasers, fumaça e partículas. Neon azul/roxo/rosa.
// IMPORTANTE: o cenário NÃO contém nenhuma pessoa/silhueta/multidão. Só avatares de usuários reais da LIVE (engine.js) aparecem aqui.
// Itens decorativos novos ficam em safe(): se um falhar, a arena continua funcionando sem ele.
import * as THREE from "three";
import { FLOOR, fmtNum } from "./arena-rules.js";
export const STAGE_Y = 0.4;                         // altura da pista de dança
export const STAGE = { w: FLOOR.w, d: FLOOR.d };    // usado por characters.js (entrada/saída pelas laterais)
const WALL_W = 18, WALL_H = 7.5, WALL_Y = 7.0, WALL_Z = -13.8, CEIL = 15, RIG_Y = 12.2, BACK_Z = -11.4;

const safe = (name, fn) => { try { return fn(); } catch (e) { console.warn("cenário (item ignorado):", name, e); return null; } };
function canvasTex(w, h) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d"); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return { c, x, t, w, h };
}
const rng = (seed) => () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const hsl = (h, s, l, a = 1) => `hsla(${(((h % 360) + 360) % 360).toFixed(0)},${s}%,${l}%,${a})`;
const rrect = (x, px, py, w, h, r) => { x.beginPath(); if (x.roundRect) x.roundRect(px, py, w, h, r); else x.rect(px, py, w, h); };
// paleta do tema: azul 200–225, roxo 265–285, rosa 315–335
const THEME = [212, 275, 325];
const themeHue = (t, i = 0) => THEME[((Math.floor(t / 7 + i) % 3) + 3) % 3] + 10 * Math.sin(t * 0.7 + i);

// ---------- telão: programas de fundo (formato largo) ----------
const MODES = ["waves", "tunnel", "synth", "bars"];
function paintMode(mode, x, w, h, t, s) {
  const hue = themeHue(t), p = s.pulse || 0, e = s.energy || 0.4;
  if (mode === "waves") {
    for (let k = 0; k < 6; k++) {
      x.beginPath(); x.moveTo(0, h);
      for (let i = 0; i <= w; i += 16) x.lineTo(i, h * (0.4 + 0.08 * k) + Math.sin(i * 0.007 + t * (0.7 + k * 0.25) + k * 1.3) * h * (0.06 + 0.04 * e + 0.04 * p));
      x.lineTo(w, h); x.closePath(); x.fillStyle = hsl(THEME[k % 3] + 8 * k, 90, 52, 0.17 + 0.04 * k); x.fill();
    }
    x.globalCompositeOperation = "lighter";
    for (let k = 0; k < 4; k++) { const r = h * (0.4 + 0.15 * k) * (1 + 0.1 * p), cx = w * (0.12 + 0.25 * k); const g = x.createRadialGradient(cx, h * 0.35, 0, cx, h * 0.35, r); g.addColorStop(0, hsl(THEME[k % 3], 100, 60, 0.35)); g.addColorStop(1, hsl(THEME[k % 3], 100, 60, 0)); x.fillStyle = g; x.fillRect(0, 0, w, h); }
    x.globalCompositeOperation = "source-over";
  } else if (mode === "tunnel") {
    const cx = w / 2, cy = h * 0.5; x.lineJoin = "round";
    for (let i = 0; i < 18; i++) {
      const z = ((i + t * 0.9) % 18) / 18, k = z * z * 1.3 + 0.012, rw = w * k, rh = h * k;
      x.lineWidth = 2 + 10 * z; x.strokeStyle = hsl(THEME[i % 3] + 6 * Math.sin(i), 100, 58, Math.min(1, z * 1.6) * (0.55 + 0.4 * p)); x.strokeRect(cx - rw / 2, cy - rh / 2, rw, rh);
    }
  } else if (mode === "synth") {
    const hz = h * 0.58, g = x.createLinearGradient(0, hz - h * 0.5, 0, hz); g.addColorStop(0, hsl(300, 100, 60, 0.95)); g.addColorStop(1, hsl(335, 100, 58, 0.95));
    x.fillStyle = g; x.beginPath(); x.arc(w / 2, hz, h * (0.46 + 0.02 * p), Math.PI, 0); x.fill();
    x.fillStyle = "rgba(6,4,28,.93)"; x.fillRect(0, hz, w, h - hz);
    x.strokeStyle = hsl(212, 100, 62, 0.8); x.lineWidth = 2;
    for (let i = -20; i <= 20; i++) { x.beginPath(); x.moveTo(w / 2 + i * 18, hz); x.lineTo(w / 2 + i * 150, h); x.stroke(); }
    for (let i = 0; i < 9; i++) { const z = ((i + t * 0.6) % 9) / 9, y = hz + (h - hz) * z * z; x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); }
  } else {
    const n = s.spectrum.length, bw = w / n;
    for (let i = 0; i < n; i++) {
      const v = s.hasAudio ? Math.max(0.05, s.spectrum[i]) : 0.16 + 0.1 * Math.sin(t * 2.4 + i * 0.55) + 0.1 * p, bh = v * h * 0.8;
      const g = x.createLinearGradient(0, h - bh, 0, h); g.addColorStop(0, hsl(THEME[i % 3], 100, 64)); g.addColorStop(1, hsl(THEME[(i + 1) % 3], 100, 40));
      x.fillStyle = g; rrect(x, i * bw + 5, h - bh, bw - 10, bh, 8); x.fill(); x.fillStyle = "rgba(255,255,255,.85)"; x.fillRect(i * bw + 5, h - bh - 8, bw - 10, 4);
    }
  }
}

/** Desenha o telão. s = {spectrum, hasAudio, username, status, viewers, gifts, likes, ticker, alert, join, rank, now, pulse, energy, flash}.
 *  O ranking (s.rank) vem só de presentes reais; sem presentes, mostra "Aguardando presentes…". */
export function drawLed(L, s, t) {
  const { x, w, h } = L, k = w / 1280, hue = themeHue(t);
  if (L.mode === undefined) { L.mode = 0; L.prev = 0; L.mix = 1; L.at = t; L.last = t; }
  const dt = Math.min(0.5, Math.max(0, t - L.last)); L.last = t;
  if (t - L.at > 16) { L.prev = L.mode; L.mode = (L.mode + 1) % MODES.length; L.mix = 0; L.at = t; }
  L.mix = Math.min(1, L.mix + dt / 1.3);
  const bg = x.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, hsl(250, 70, 9)); bg.addColorStop(1, hsl(290, 75, 5)); x.fillStyle = bg; x.fillRect(0, 0, w, h);
  if (L.mix < 1) { paintMode(MODES[L.prev], x, w, h, t, s); x.globalAlpha = L.mix; }
  paintMode(MODES[L.mode], x, w, h, t, s); x.globalAlpha = 1;

  // cabeçalho
  const hb = x.createLinearGradient(0, 0, 0, 120 * k); hb.addColorStop(0, "rgba(0,0,14,.72)"); hb.addColorStop(1, "rgba(0,0,14,0)"); x.fillStyle = hb; x.fillRect(0, 0, w, 120 * k);
  x.textBaseline = "alphabetic"; x.textAlign = "left";
  const tg = x.createLinearGradient(30 * k, 0, 560 * k, 0); tg.addColorStop(0, "#35d6ff"); tg.addColorStop(0.55, "#ffffff"); tg.addColorStop(1, "#ff2d95");
  x.shadowColor = hsl(300, 100, 60, 0.9); x.shadowBlur = 18 * k; x.fillStyle = tg; x.font = `900 ${68 * k}px system-ui, sans-serif`; x.fillText("LIVE WORLD 3D", 34 * k, 72 * k);
  x.shadowBlur = 0; x.font = `700 ${26 * k}px system-ui, sans-serif`; x.fillStyle = s.status === "CONECTADO" ? "#7dffb2" : "#9ff5e6";
  x.fillText(s.username ? `● @${s.username} · ${s.status}` : `● ${s.status}`, 36 * k, 106 * k);
  x.font = `800 ${28 * k}px system-ui, sans-serif`; let cx = w - 28 * k;
  for (const [ic, v] of [["❤", s.likes], ["🎁", s.gifts], ["👥", s.viewers]]) {
    const txt = `${ic} ${fmtNum(v)}`, tw = x.measureText(txt).width + 28 * k; cx -= tw;
    rrect(x, cx, 26 * k, tw, 48 * k, 24 * k); x.fillStyle = "rgba(0,0,20,.55)"; x.fill(); x.strokeStyle = hsl(hue + 20, 100, 65, 0.8); x.lineWidth = 2; x.stroke();
    x.fillStyle = "#fff"; x.fillText(txt, cx + 14 * k, 60 * k); cx -= 10 * k;
  }
  // últimas mensagens (esquerda)
  const lines = s.ticker.slice(-4);
  x.font = `600 ${25 * k}px system-ui, sans-serif`;
  lines.forEach((line, i) => {
    const txt = line.length > 40 ? line.slice(0, 39) + "…" : line, tw = Math.min(w * 0.42, x.measureText(txt).width + 30 * k), y = 190 * k + i * 46 * k, last = i === lines.length - 1;
    rrect(x, 30 * k, y - 30 * k, tw, 40 * k, 20 * k); x.fillStyle = last ? "rgba(0,0,20,.64)" : "rgba(0,0,20,.4)"; x.fill();
    x.fillStyle = last ? "#fff" : "#b8c2e0"; x.fillText(txt, 44 * k, y);
  });
  // ranking: TOP 5 apoiadores (direita), somente dados reais de presentes
  const px = w - 392 * k, py = 124 * k, pw = 364 * k, ph = 352 * k;
  rrect(x, px, py, pw, ph, 22 * k); x.fillStyle = "rgba(6,6,28,.72)"; x.fill(); x.strokeStyle = hsl(hue + 40, 100, 66, 0.85); x.lineWidth = 3; x.stroke();
  x.textAlign = "center"; x.fillStyle = "#ffd76a"; x.font = `900 ${27 * k}px system-ui, sans-serif`; x.fillText("👑 TOP 5 APOIADORES", px + pw / 2, py + 40 * k); x.textAlign = "left";
  const rank = s.rank || [];
  if (!rank.length) { x.fillStyle = "#8f98bd"; x.font = `600 ${24 * k}px system-ui, sans-serif`; x.textAlign = "center"; x.fillText("Aguardando presentes…", px + pw / 2, py + ph / 2 + 12 * k); x.textAlign = "left"; }
  rank.slice(0, 5).forEach((r, i) => {
    const y = py + 96 * k + i * 56 * k, medal = ["#ffd76a", "#cfd6e6", "#d99058", "#6f7cff", "#6f7cff"][i];
    x.beginPath(); x.arc(px + 36 * k, y - 8 * k, 20 * k, 0, Math.PI * 2); x.fillStyle = medal; x.fill();
    x.fillStyle = "#10122a"; x.font = `900 ${24 * k}px system-ui, sans-serif`; x.textAlign = "center"; x.fillText(String(i + 1), px + 36 * k, y); x.textAlign = "left";
    x.fillStyle = i === 0 ? "#ffe9a8" : "#fff"; x.font = `700 ${25 * k}px system-ui, sans-serif`; const nm = r.name.length > 12 ? r.name.slice(0, 11) + "…" : r.name; x.fillText(nm, px + 70 * k, y);
    x.textAlign = "right"; x.fillStyle = "#ffd76a"; x.fillText(`💎 ${fmtNum(r.total)}`, px + pw - 20 * k, y); x.textAlign = "left";
  });
  // quem acabou de entrar (real)
  if (s.join && s.now < s.join.until) {
    const age = Math.min(1, (s.join.until - s.now) / 3200), slide = Math.min(1, (1 - age) * 6) * (age < 0.15 ? age / 0.15 : 1);
    const txt = `👋 ${s.join.text.slice(0, 22)} entrou!`; x.font = `800 ${30 * k}px system-ui, sans-serif`;
    const tw = x.measureText(txt).width + 44 * k, bx = 30 * k - (1 - slide) * (tw + 40 * k);
    rrect(x, bx, h - 90 * k, tw, 52 * k, 26 * k); x.fillStyle = hsl(hue + 120, 90, 42, 0.92); x.fill(); x.fillStyle = "#fff"; x.fillText(txt, bx + 22 * k, h - 54 * k);
  }
  // alerta de presente (real)
  if (s.alert && s.now < s.alert.until) {
    const age = Math.min(1, Math.max(0, 1 - (s.alert.until - s.now) / 4500)), pop = 1 + 0.05 * Math.sin(t * 14) + (age < 0.1 ? (0.1 - age) * 3 : 0), ay = h * 0.7;
    x.globalCompositeOperation = "lighter"; x.lineWidth = 10 * k * (1 - age); x.strokeStyle = hsl(hue + 40, 100, 65, 0.9 * (1 - age));
    x.beginPath(); x.arc(w * 0.42, ay, age * w * 0.5, 0, Math.PI * 2); x.stroke(); x.globalCompositeOperation = "source-over";
    x.save(); x.translate(w * 0.42, ay); x.scale(pop, pop);
    const bgr = x.createLinearGradient(-w * 0.34, 0, w * 0.34, 0); bgr.addColorStop(0, "rgba(255,45,149,.88)"); bgr.addColorStop(1, "rgba(53,214,255,.88)");
    rrect(x, -w * 0.34, -62 * k, w * 0.68, 124 * k, 30 * k); x.fillStyle = bgr; x.fill(); x.strokeStyle = "#fff"; x.lineWidth = 4; x.stroke();
    x.textAlign = "center"; x.fillStyle = "#fff"; x.shadowColor = "#000"; x.shadowBlur = 8; x.font = `900 ${50 * k}px system-ui, sans-serif`; x.fillText("🎁 " + s.alert.text.slice(0, 34), 0, 8 * k);
    x.font = `700 ${28 * k}px system-ui, sans-serif`; x.fillText(s.alert.sub || "", 0, 46 * k); x.shadowBlur = 0; x.restore();
  }
  x.strokeStyle = hsl(hue + 20, 100, 65, 0.9); x.lineWidth = 5; const m = 14, c = 50 * k;
  for (const [qx, qy, dx, dy] of [[m, m, 1, 1], [w - m, m, -1, 1], [m, h - m, 1, -1], [w - m, h - m, -1, -1]]) { x.beginPath(); x.moveTo(qx, qy + dy * c); x.lineTo(qx, qy); x.lineTo(qx + dx * c, qy); x.stroke(); }
  if (s.flash > 0.02) { x.fillStyle = `rgba(255,255,255,${(0.4 * s.flash).toFixed(3)})`; x.fillRect(0, 0, w, h); }
  L.t.needsUpdate = true;
}

export function buildWorld(scene, q) {
  scene.background = new THREE.Color(0x04041a);
  scene.fog = new THREE.FogExp2(0x070722, 0.011);
  scene.add(new THREE.HemisphereLight(0x8fa0ff, 0x2a1647, 1.15));
  const key = new THREE.DirectionalLight(0xffffff, 1.2); key.position.set(3, 16, 14); key.target.position.set(0, 0, -2); scene.add(key, key.target);
  if (q >= 2) {
    key.castShadow = true; key.shadow.mapSize.set(2048, 2048);
    Object.assign(key.shadow.camera, { left: -14, right: 14, top: 12, bottom: -12, near: 1, far: 45 }); key.shadow.bias = -0.0005;
  }
  const rimA = new THREE.DirectionalLight(0xff3da0, 1.1), rimB = new THREE.DirectionalLight(0x35a6ff, 1.1);
  rimA.position.set(-10, 8, -14); rimB.position.set(10, 8, -14); scene.add(rimA, rimB);
  const washes = [0xff2d95, 0x35a6ff, 0xa66bff].map((c, i) => { const l = new THREE.PointLight(c, q ? 70 : 40, 30, 2); l.position.set((i - 1) * 7, 6.5, -4); scene.add(l); return l; });
  const H = { flash: 0, hue: 0 }, A = { energy: 0.4, pulse: 0 };
  const statics = [], add = (m, x = 0, y = 0, z = 0, isStatic = true) => { m.position.set(x, y, z); scene.add(m); if (isStatic) statics.push(m); return m; };
  const GC = new Map(), box = (w, h, d) => { const k = `${w}|${h}|${d}`; let g = GC.get(k); if (!g) { g = new THREE.BoxGeometry(w, h, d); GC.set(k, g); } return g; };
  const dark = new THREE.MeshStandardMaterial({ color: 0x0c0d22, roughness: 0.55, metalness: 0.6 }), metal = new THREE.MeshStandardMaterial({ color: 0x1a1d34, metalness: 0.8, roughness: 0.35 });
  const mkNeon = (hue) => new THREE.MeshBasicMaterial({ color: new THREE.Color().setHSL(hue / 360, 1, 0.6) });
  const neonB = mkNeon(212), neonV = mkNeon(275), neonP = mkNeon(325);

  const glow = canvasTex(128, 128), gg = glow.x.createRadialGradient(64, 64, 0, 64, 64, 64);
  gg.addColorStop(0, "rgba(255,255,255,.9)"); gg.addColorStop(0.45, "rgba(255,255,255,.35)"); gg.addColorStop(1, "rgba(255,255,255,0)"); glow.x.fillStyle = gg; glow.x.fillRect(0, 0, 128, 128); glow.t.needsUpdate = true;

  // ---------- chão, pista de LED e estrutura ----------
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(140, 140), new THREE.MeshStandardMaterial({ color: 0x07081a, roughness: 0.4, metalness: 0.5 }));
  ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; add(ground);
  const FC = q === 0 ? 8 : 16, fl = canvasTex(FLOOR.w * FC, FLOOR.d * FC);
  const topMat = new THREE.MeshStandardMaterial({ color: 0x0b0d1a, map: fl.t, emissive: 0xffffff, emissiveMap: fl.t, emissiveIntensity: 0.9, roughness: 0.2, metalness: 0.6 });
  const sideMat = new THREE.MeshStandardMaterial({ color: 0x0b0d1a, roughness: 0.4, metalness: 0.7 });
  const dance = new THREE.Mesh(new THREE.BoxGeometry(FLOOR.w, STAGE_Y, FLOOR.d), [sideMat, sideMat, topMat, sideMat, sideMat, sideMat]);
  add(dance, 0, STAGE_Y / 2, FLOOR.cz); dance.receiveShadow = true;
  // piso: plasma de LED azul/roxo/rosa (células de 1 unidade) com xadrez e pulso na batida
  const drawFloor = (t) => {
    const x = fl.x, cw = fl.w / FLOOR.w, ch = fl.h / FLOOR.d; x.fillStyle = "#05060e"; x.fillRect(0, 0, fl.w, fl.h);
    for (let cy = 0; cy < FLOOR.d; cy++) for (let cx = 0; cx < FLOOR.w; cx++) {
      const v = Math.sin(cx * 0.45 + t * 1.1) + Math.sin(cy * 0.6 - t * 0.8) + Math.sin((cx + cy) * 0.3 + t * 0.6) + Math.sin(Math.hypot(cx - 13, cy - 9) * 0.5 - t * 1.4);
      const hue = 285 + 55 * Math.sin(v * 0.9 + H.hue * 3 * H.flash), ring = Math.max(0, Math.sin(Math.hypot(cx - 13, cy - 9) * 0.9 - t * 3));
      const l = (14 + 20 * (0.5 + 0.5 * Math.sin(v * 1.7 + t)) + 26 * ring * (A.pulse + 0.25 * A.energy) + 12 * H.flash) * ((cx + cy) % 2 ? 0.72 : 1);
      x.fillStyle = hsl(hue, 90, Math.min(68, l)); x.fillRect(cx * cw + 1, cy * ch + 1, cw - 2, ch - 2);
    }
    fl.t.needsUpdate = true;
  };
  drawFloor(0);
  for (const [w, d, px, pz, m] of [[FLOOR.w + 0.2, 0.1, 0, FLOOR.cz + FLOOR.d / 2 + 0.05, neonP], [FLOOR.w + 0.2, 0.1, 0, FLOOR.cz - FLOOR.d / 2 - 0.05, neonB], [0.1, FLOOR.d, -FLOOR.w / 2 - 0.05, FLOOR.cz, neonV], [0.1, FLOOR.d, FLOOR.w / 2 + 0.05, FLOOR.cz, neonV]]) add(new THREE.Mesh(box(w, 0.12, d), m), px, STAGE_Y - 0.02, pz);
  // emblema luminoso no centro da pista
  const disc = canvasTex(512, 512), dx = disc.x, rg = dx.createRadialGradient(256, 256, 0, 256, 256, 256);
  rg.addColorStop(0, "rgba(255,255,255,.3)"); rg.addColorStop(0.6, "rgba(120,140,255,.12)"); rg.addColorStop(1, "rgba(0,0,0,0)"); dx.fillStyle = rg; dx.fillRect(0, 0, 512, 512);
  dx.lineWidth = 6; for (const [r, c] of [[236, "#ff2d95"], [200, "#35d6ff"], [120, "#a66bff"], [60, "#ffffff"]]) { dx.strokeStyle = c; dx.beginPath(); dx.arc(256, 256, r, 0, Math.PI * 2); dx.stroke(); }
  dx.lineWidth = 3; dx.strokeStyle = "rgba(160,190,255,.7)"; for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; dx.beginPath(); dx.moveTo(256 + Math.cos(a) * 66, 256 + Math.sin(a) * 66); dx.lineTo(256 + Math.cos(a) * 196, 256 + Math.sin(a) * 196); dx.stroke(); }
  disc.t.needsUpdate = true;
  const discMat = new THREE.MeshBasicMaterial({ map: disc.t, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  const discMesh = new THREE.Mesh(new THREE.CircleGeometry(7.5, 64), discMat); discMesh.rotation.x = -Math.PI / 2; add(discMesh, 0, STAGE_Y + 0.012, 0.6, false);

  // ---------- telão central enorme ----------
  const LQ = [[768, 320], [1024, 427], [1536, 640]][q] || [1024, 427];
  const led = canvasTex(LQ[0], LQ[1]);
  const wallMat = new THREE.MeshBasicMaterial({ map: led.t, toneMapped: false, fog: false });
  add(new THREE.Mesh(new THREE.PlaneGeometry(WALL_W, WALL_H), wallMat), 0, WALL_Y, WALL_Z);
  add(new THREE.Mesh(box(WALL_W + 0.8, WALL_H + 0.8, 0.3), metal), 0, WALL_Y, WALL_Z - 0.2);
  add(new THREE.Mesh(box(46, 18, 0.6), dark), 0, 8, WALL_Z - 0.6);               // parede do fundo
  safe("pixels do telão", () => {
    const mk = canvasTex(16, 16); mk.x.fillStyle = "rgba(0,0,0,.6)"; mk.x.fillRect(0, 0, 16, 2.4); mk.x.fillRect(0, 0, 2.4, 16); mk.t.wrapS = mk.t.wrapT = THREE.RepeatWrapping; mk.t.repeat.set(WALL_W / 0.07, WALL_H / 0.07); mk.t.needsUpdate = true;
    add(new THREE.Mesh(new THREE.PlaneGeometry(WALL_W, WALL_H), new THREE.MeshBasicMaterial({ map: mk.t, transparent: true, depthWrite: false, toneMapped: false })), 0, WALL_Y, WALL_Z + 0.012);
  });
  for (const [w, h, px, py, m] of [[WALL_W + 1, 0.14, 0, WALL_H / 2 + 0.55, neonP], [WALL_W + 1, 0.14, 0, -WALL_H / 2 - 0.55, neonB], [0.14, WALL_H + 1, -WALL_W / 2 - 0.55, 0, neonV], [0.14, WALL_H + 1, WALL_W / 2 + 0.55, 0, neonV]]) add(new THREE.Mesh(box(w, h, 0.12), m), px, WALL_Y + py, WALL_Z + 0.12);
  const arcs = safe("arcos do telão", () => [[10.2, 0.1, neonB], [11, 0.06, neonP]].map(([r, tube, mat]) => { const a = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 8, 80, Math.PI), mat); a.position.set(0, WALL_Y - 3.8, WALL_Z + 0.3); scene.add(a); return a; })) || [];

  // ---------- cabine de DJ (sem DJ: nenhuma pessoa fictícia) ----------
  const djf = canvasTex(512, 128), djMat = new THREE.MeshBasicMaterial({ map: djf.t, toneMapped: false, fog: false });
  const drawDj = (t) => {
    const x = djf.x; x.fillStyle = "#06061a"; x.fillRect(0, 0, 512, 128);
    for (let i = 0; i < 32; i++) { const v = 0.15 + 0.5 * Math.max(0, Math.sin(i * 0.5 - t * 6)) + 0.4 * A.pulse; x.fillStyle = hsl(THEME[i % 3], 100, 55); x.fillRect(i * 16 + 2, 124 - 70 * v, 12, 70 * v); }
    x.textAlign = "center"; x.font = "900 44px system-ui, sans-serif"; x.fillStyle = "#fff"; x.shadowColor = hsl(300, 100, 60); x.shadowBlur = 14; x.fillText("LIVE WORLD 3D", 256, 50); x.shadowBlur = 0; djf.t.needsUpdate = true;
  };
  drawDj(0);
  const turntables = [], woofers = [];
  safe("cabine de DJ", () => {
    add(new THREE.Mesh(box(11, 0.9, 3.4), sideMat), 0, 0.45, -11.7);
    add(new THREE.Mesh(box(11.1, 0.06, 0.08), neonB), 0, 0.92, -10.02);
    add(new THREE.Mesh(box(5.4, 1.05, 1.2), metal), 0, 0.9 + 0.52, -11.0);
    const front = new THREE.Mesh(new THREE.PlaneGeometry(5.1, 0.95), djMat); add(front, 0, 1.42, -10.39);
    add(new THREE.Mesh(box(5.6, 0.08, 1.4), neonP), 0, 2.0, -11.0);
    for (const sx of [-1, 1]) {
      const tt = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.05, 28), new THREE.MeshStandardMaterial({ color: 0x15162c, metalness: 0.8, roughness: 0.3, emissive: 0x2233aa, emissiveIntensity: 0.6 })); add(tt, sx * 1.5, 2.06, -11.0, false); turntables.push(tt);
      const sp = new THREE.Mesh(box(1.7, 3.4, 1.5), metal); add(sp, sx * 4.4, 0.9 + 1.7, -11.5);
      for (const [wy, wr] of [[1.9, 0.62], [3.3, 0.34]]) {
        const wf = new THREE.Mesh(new THREE.CircleGeometry(wr, 28), new THREE.MeshBasicMaterial({ color: 0x35a6ff })); add(wf, sx * 4.4, wy - 0.1, -10.74, false); woofers.push(wf);
        const rim = new THREE.Mesh(new THREE.TorusGeometry(wr + 0.04, 0.045, 6, 28), neonP); add(rim, sx * 4.4, wy - 0.1, -10.73);
      }
    }
    for (const sx of [-1, 1]) add(new THREE.Mesh(box(0.28, 6.4, 0.28), metal), sx * 6.0, 0.9 + 3.2, -11.0);
    add(new THREE.Mesh(box(12.4, 0.28, 0.28), metal), 0, 7.2, -11.0); add(new THREE.Mesh(box(12.2, 0.07, 0.07), neonV), 0, 7.0, -10.8);
  });

  // ---------- paredes laterais, pilares de neon, mezaninos e escadas ----------
  const side = canvasTex(512, 192), sideMatL = new THREE.MeshBasicMaterial({ map: side.t, toneMapped: false, fog: false });
  const drawSide = (t) => {
    const x = side.x; x.fillStyle = "#05050f"; x.fillRect(0, 0, 512, 192);
    x.textAlign = "center"; x.font = "italic 900 58px system-ui, sans-serif"; x.shadowBlur = 18; x.shadowColor = hsl(325, 100, 60); x.fillStyle = hsl(325, 100, 72); x.fillText("DANCE", 256, 70);
    x.shadowColor = hsl(212, 100, 60); x.fillStyle = hsl(212, 100, 75); x.fillText("FOREVER", 256, 135); x.shadowBlur = 0;
    for (let i = 0; i < 24; i++) { const v = 0.1 + 0.9 * Math.max(0, Math.sin(i * 0.6 - t * 5)) * (0.4 + A.pulse); x.fillStyle = hsl(THEME[i % 3], 100, 58); x.fillRect(i * 21 + 4, 188 - 22 * v, 14, 22 * v); }
    side.t.needsUpdate = true;
  };
  drawSide(0);
  const rings = [];
  safe("laterais", () => {
    for (const sx of [-1, 1]) {
      add(new THREE.Mesh(box(0.6, 15, 34), dark), sx * 14.6, 7.5, -3);
      const pn = new THREE.Mesh(new THREE.PlaneGeometry(11, 4.1), sideMatL); pn.rotation.y = -sx * Math.PI / 2; add(pn, sx * 14.25, 8.2, -3.2);
      add(new THREE.Mesh(box(0.25, 4.7, 11.6), metal), sx * 14.3, 8.2, -3.2);
      add(new THREE.Mesh(box(2.8, 0.4, 11.8), metal), sx * 12.6, 4.0, -3.7);                        // mezanino
      add(new THREE.Mesh(box(0.1, 0.1, 11.8), neonV), sx * 11.25, 4.75, -3.7); add(new THREE.Mesh(box(0.1, 0.1, 11.8), neonB), sx * 11.25, 4.15, -3.7);
      add(new THREE.Mesh(box(0.05, 0.75, 11.8), new THREE.MeshBasicMaterial({ color: 0x35a6ff, transparent: true, opacity: 0.18, depthWrite: false })), sx * 11.25, 4.5, -3.7);
      for (const pz of [-9, -5.5, -2, 1.5]) {                                                       // pilares com anéis de neon
        add(new THREE.Mesh(box(0.9, 4.0, 0.9), metal), sx * 11.6, 2.0, pz);
        for (let i = 0; i < 4; i++) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.68, 0.075, 6, 24), i % 2 ? neonB : neonV); r.rotation.x = Math.PI / 2; add(r, sx * 11.6, 0.9 + i * 0.62, pz); }
        const sp = new THREE.Mesh(new THREE.CircleGeometry(0.3, 20), neonP); sp.rotation.y = -sx * Math.PI / 2; add(sp, sx * 11.6 - sx * 0.46, 3.4, pz);
        const gl = new THREE.Mesh(new THREE.CircleGeometry(1.6, 20), new THREE.MeshBasicMaterial({ map: glow.t, color: 0x7a6bff, transparent: true, opacity: 0.35, blending: THREE.AdditiveBlending, depthWrite: false })); gl.rotation.x = -Math.PI / 2; add(gl, sx * 11.0, 0.03, pz, false); rings.push(gl);
      }
      for (let i = 0; i < 10; i++) {                                                                  // escada até o mezanino
        const hgt = (i + 1) * 0.4; add(new THREE.Mesh(box(2.0, hgt, 0.55), sideMat), sx * 12.7, hgt / 2, 7.4 - i * 0.55);
        add(new THREE.Mesh(box(2.0, 0.04, 0.05), i % 2 ? neonP : neonB), sx * 12.7, hgt, 7.4 - i * 0.55 + 0.27);
      }
    }
  });

  // ---------- teto: anéis de LED, globo de espelhos, moldura neon e estrelas de fibra ótica ----------
  add(new THREE.Mesh(new THREE.PlaneGeometry(70, 60), new THREE.MeshBasicMaterial({ color: 0x05051a, side: THREE.DoubleSide })), 0, CEIL, -2).rotation.x = Math.PI / 2;
  const ringMeshes = safe("anéis do teto", () => [[6, 0.2, neonP], [7.6, 0.08, neonB]].map(([r, tube, m]) => { const g = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 8, 90), m); g.rotation.x = Math.PI / 2; add(g, 0, 12.7, FLOOR.cz, false); return g; })) || [];
  const ball = safe("globo", () => {
    const g = new THREE.Mesh(new THREE.IcosahedronGeometry(1.25, 2), new THREE.MeshStandardMaterial({ color: 0xdfe4ff, metalness: 0.95, roughness: 0.18, flatShading: true, emissive: 0x2a2a66, emissiveIntensity: 0.7 }));
    add(g, 0, 10.4, FLOOR.cz, false); add(new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 4.6, 6), metal), 0, 12.9, FLOOR.cz); return g;
  });
  safe("moldura do teto", () => {
    for (const [w, d, px, pz, m] of [[34, 0.14, 0, -16, neonB], [34, 0.14, 0, 12, neonB], [0.14, 28, -17, -2, neonV], [0.14, 28, 17, -2, neonV], [24, 0.1, 0, -9, neonP], [24, 0.1, 0, 4.2, neonP]]) add(new THREE.Mesh(box(w, 0.14, d), m), px, CEIL - 0.4, pz);
    const R = rng(11), n = q ? 420 : 200, a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { a[i * 3] = (R() - 0.5) * 60; a[i * 3 + 1] = CEIL - 0.6 - R() * 0.4; a[i * 3 + 2] = -2 + (R() - 0.5) * 50; }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(a, 3));
    scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffb070, size: 0.16, transparent: true, opacity: 0.9, fog: false, depthWrite: false })));
  });

  // ---------- treliça + moving heads (poças de luz na pista) ----------
  safe("treliça", () => {
    for (const z of [-10, 5]) add(new THREE.Mesh(box(20.4, 0.24, 0.24), metal), 0, RIG_Y, z);
    for (const x of [-10, 10]) add(new THREE.Mesh(box(0.24, 0.24, 15), metal), x, RIG_Y, -2.5);
    for (const [x, z] of [[-10, -10], [10, -10], [-10, 5], [10, 5]]) add(new THREE.Mesh(box(0.2, CEIL - RIG_Y, 0.2), metal), x, (CEIL + RIG_Y) / 2, z);
  });
  const heads = [], HP = [[-4.5, -10], [4.5, -10], [-4.5, 5], [4.5, 5], [-9, -10], [9, -10], [-9, 5], [9, 5], [-10, -2.5], [10, -2.5]], nHeads = [4, 7, 10][q] || 7, BEAM = 14, headY = RIG_Y - 0.2;
  const beamGeo = new THREE.ConeGeometry(1.5, BEAM, 18, 1, true); beamGeo.translate(0, -BEAM / 2, 0);
  for (let i = 0; i < nHeads; i++) {
    const pivot = new THREE.Group(); pivot.position.set(HP[i][0], headY, HP[i][1]);
    pivot.add(new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.13, 0.46, 10), metal));
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    pivot.add(new THREE.Mesh(beamGeo, mat)); scene.add(pivot);
    const pm = new THREE.MeshBasicMaterial({ map: glow.t, color: 0xffffff, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
    const pool = safe("poça de luz", () => { const m = new THREE.Mesh(new THREE.CircleGeometry(1.9, 24), pm); m.rotation.x = -Math.PI / 2; m.visible = false; scene.add(m); return m; });
    heads.push({ pivot, mat, pm, pool, i });
  }
  const lasers = [];
  if (q >= 1) for (let i = 0; i < (q >= 2 ? 12 : 6); i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.02, 28, 0.02).translate(0, -14, 0), new THREE.MeshBasicMaterial({ color: i % 2 ? 0xff2d95 : 0x35d6ff, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending, depthWrite: false }));
    m.position.set(-7 + i * (14 / 11), 9.5, BACK_Z); scene.add(m); lasers.push(m);
  }

  // ---------- fumaça e partículas (decorativas) ----------
  const jets = [], JN = q ? 46 : 24;
  safe("jatos de fumaça", () => {
    for (const sx of [-1, 1]) {
      const pos = new Float32Array(JN * 3), life = new Float32Array(JN), vel = new Float32Array(JN * 3), R = rng(31 + sx);
      for (let i = 0; i < JN; i++) { life[i] = R(); pos[i * 3 + 1] = -50; }
      const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      const m = new THREE.PointsMaterial({ map: glow.t, color: 0xb9a6ff, size: 3.2, transparent: true, opacity: 0.2, depthWrite: false, blending: THREE.AdditiveBlending });
      const pts = new THREE.Points(g, m); pts.frustumCulled = false; scene.add(pts); jets.push({ pos, life, vel, g, m, sx, R });
    }
  });
  const R0 = rng(21), SP = q ? 220 : 110, spArr = new Float32Array(SP * 3);
  for (let i = 0; i < SP; i++) { spArr[i * 3] = (R0() - 0.5) * 28; spArr[i * 3 + 1] = 1 + R0() * 10; spArr[i * 3 + 2] = -11 + R0() * 18; }
  const spG = new THREE.BufferGeometry(); spG.setAttribute("position", new THREE.BufferAttribute(spArr, 3));
  const sparkMat = new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.1, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const sparkles = new THREE.Points(spG, sparkMat); scene.add(sparkles);
  let haze = null;
  if (q >= 1) {
    const R = rng(3), hp = new Float32Array(160 * 3); for (let i = 0; i < 160; i++) { hp[i * 3] = (R() - 0.5) * 30; hp[i * 3 + 1] = 0.6 + R() * 7; hp[i * 3 + 2] = -12 + R() * 22; }
    const hg = new THREE.BufferGeometry(); hg.setAttribute("position", new THREE.BufferAttribute(hp, 3));
    haze = new THREE.Points(hg, new THREE.PointsMaterial({ map: glow.t, color: 0x6677ff, size: 4.5, transparent: true, opacity: 0.06, depthWrite: false, blending: THREE.AdditiveBlending })); scene.add(haze);
  }
  statics.forEach((m) => { m.updateMatrix(); m.matrixAutoUpdate = false; });   // objetos parados não recalculam matriz a cada frame
  let slowT = 0;

  function hype(kind, hue) { H.flash = Math.max(H.flash, kind === "gift" ? 1 : kind === "join" ? 0.5 : 0.22); H.hue = typeof hue === "number" ? hue : Math.random(); if (kind === "gift") jets.forEach((j) => { j.boost = 1.2; }); }

  function update(t, dt, a) {
    A.energy = a.energy; A.pulse = a.pulse; H.flash = Math.max(0, H.flash - dt * 1.4); const fl_ = H.flash;
    neonB.color.setHSL((212 + 8 * Math.sin(t * 0.6)) / 360, 1, 0.6); neonV.color.setHSL((275 + 8 * Math.sin(t * 0.5 + 1)) / 360, 1, 0.62); neonP.color.setHSL((325 + 8 * Math.sin(t * 0.7 + 2)) / 360, 1, 0.62);
    discMesh.rotation.z = t * 0.12; discMat.opacity = 0.5 + 0.45 * (0.4 * a.energy + a.pulse);
    sparkMat.opacity = 0.45 + 0.25 * Math.sin(t * 3); sparkles.rotation.y = t * 0.012;
    rimA.intensity = 1.0 + 0.7 * a.pulse + 1.6 * fl_; rimB.intensity = 1.0 + 0.7 * a.pulse + 1.6 * fl_;
    washes.forEach((l, i) => { l.intensity = (q ? 70 : 40) * (0.75 + 0.7 * a.pulse + 0.15 * Math.sin(t * 2 + i) + 1.1 * fl_); });
    wallMat.color.setScalar(1 + 0.06 * a.pulse + 0.4 * fl_);
    ringMeshes.forEach((m, i) => { m.rotation.z = t * (0.1 + 0.05 * i); }); arcs.forEach((m, i) => { m.rotation.z = Math.sin(t * 0.3 + i) * 0.01; });
    if (ball) { ball.rotation.y = t * 0.35; ball.rotation.x = 0.2 * Math.sin(t * 0.2); }
    turntables.forEach((m, i) => { m.rotation.y = t * (i ? -1.6 : 1.6); });
    woofers.forEach((m, i) => { m.scale.setScalar(1 + 0.12 * a.pulse + 0.04 * Math.sin(t * 8 + i)); });
    rings.forEach((m, i) => { m.material.opacity = 0.25 + 0.3 * a.pulse + 0.2 * Math.sin(t * 2 + i); });
    for (const h of heads) {
      const rx = Math.sin(t * 0.7 + h.i * 0.8) * 0.5 + a.pulse * 0.06, rz = Math.cos(t * 0.5 + h.i * 1.3) * 0.62;
      h.pivot.rotation.x = rx; h.pivot.rotation.z = rz;
      h.mat.color.setHSL(THEME[(h.i + Math.floor(t / 6)) % 3] / 360, 1, 0.6); h.mat.opacity = 0.05 + 0.09 * (0.4 + a.energy) + 0.1 * a.pulse + 0.16 * fl_;
      if (h.pool) {
        const cz = Math.cos(rz), cx = Math.cos(rx), dist = (headY - STAGE_Y) / Math.max(0.3, cz * cx);
        const px = h.pivot.position.x + dist * Math.sin(rz), pz = h.pivot.position.z - dist * cz * Math.sin(rx), onFloor = Math.abs(px) < FLOOR.w / 2 && Math.abs(pz - FLOOR.cz) < FLOOR.d / 2;
        h.pool.position.set(px, onFloor ? STAGE_Y + 0.025 : 0.03, pz); h.pool.visible = Number.isFinite(px + pz);
        h.pm.color.copy(h.mat.color); h.pm.opacity = 0.28 + 0.3 * a.pulse + 0.3 * fl_;
      }
    }
    lasers.forEach((m, i) => { m.rotation.z = Math.sin(t * 0.9 + i) * 1.0; m.rotation.x = -(0.35 + Math.cos(t * 0.6 + i * 1.7) * 0.35); m.material.opacity = 0.2 + 0.5 * a.pulse + 0.3 * fl_; });
    for (const j of jets) {                       // fumaça sobe e se dissipa; reaproveita as partículas
      j.boost = Math.max(0, (j.boost || 0) - dt); const sp = 1 + 1.4 * (j.boost > 0 ? 1 : 0) + a.pulse;
      for (let i = 0; i < JN; i++) {
        j.life[i] += dt * 0.35 * sp;
        if (j.life[i] >= 1) { j.life[i] = 0; j.pos[i * 3] = j.sx * 6.8 + (j.R() - 0.5) * 0.8; j.pos[i * 3 + 1] = 1; j.pos[i * 3 + 2] = -9.6 + (j.R() - 0.5) * 0.6; j.vel[i * 3] = (j.R() - 0.5) * 0.5; j.vel[i * 3 + 1] = 2.2 + j.R() * 1.4; j.vel[i * 3 + 2] = j.R() * 0.8; }
        j.pos[i * 3] += j.vel[i * 3] * dt * sp; j.pos[i * 3 + 1] += j.vel[i * 3 + 1] * dt * sp; j.pos[i * 3 + 2] += j.vel[i * 3 + 2] * dt * sp;
      }
      j.g.attributes.position.needsUpdate = true; j.m.opacity = 0.14 + 0.08 * a.energy;
    }
    if (haze) haze.rotation.y = t * 0.008;
    if ((slowT += dt) > (q ? 0.08 : 0.12)) { slowT = 0; drawFloor(t); drawDj(t); drawSide(t); }
  }
  return { update, hype, led, drawLed: (s, t) => drawLed(led, { ...s, pulse: A.pulse, energy: A.energy, flash: H.flash }, t) };
}
