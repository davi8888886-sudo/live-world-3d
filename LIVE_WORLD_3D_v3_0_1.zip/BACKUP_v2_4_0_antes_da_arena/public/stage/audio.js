// Áudio do palco: toca a playlist do servidor (sincronizada), mede graves para sincronizar as danças.
export class BeatDetector {
  constructor({ sensitivity = 1.35, minGap = 0.22 } = {}) { Object.assign(this, { sensitivity, minGap }); this.avg = 0; this.energy = 0; this.pulse = 0; this.last = -10; this.beats = 0; }
  update(level, t, dt) {
    const k = Math.min(1, dt * 12);
    this.energy += (level - this.energy) * k;
    this.avg += (level - this.avg) * Math.min(1, dt * 1.5);
    if (level > this.avg * this.sensitivity + 0.04 && t - this.last > this.minGap) { this.pulse = 1; this.last = t; this.beats++; }
    this.pulse *= Math.pow(0.02, dt);
    return { energy: this.energy, pulse: this.pulse };
  }
}

export class StageAudio {
  constructor({ enabled = true, onEnded, onBlocked } = {}) {
    this.enabled = enabled; this.onEnded = onEnded; this.onBlocked = onBlocked;
    this.el = new Audio(); this.el.preload = "auto"; this.el.playsInline = true;
    this.ctx = null; this.analyser = null; this.gain = null; this.data = null;
    this.music = null; this.skew = 0; this.curId = null; this.pendingSeek = 0; this.blocked = false;
    this.el.addEventListener("ended", () => this.onEnded?.(this.curId));
    this.el.addEventListener("loadedmetadata", () => { if (this.pendingSeek > 1 && isFinite(this.el.duration)) { try { this.el.currentTime = this.pendingSeek % this.el.duration; } catch { /* ignora */ } } });
  }
  get playing() { return !!this.music?.playing && !this.el.paused && !this.blocked; }
  #ensureCtx() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    const src = this.ctx.createMediaElementSource(this.el);
    this.analyser = this.ctx.createAnalyser(); this.analyser.fftSize = 1024; this.analyser.smoothingTimeConstant = 0.6;
    this.gain = this.ctx.createGain();
    src.connect(this.analyser); this.analyser.connect(this.gain); this.gain.connect(this.ctx.destination);
    this.data = new Uint8Array(this.analyser.frequencyBinCount);
  }
  /** Chamado por um toque do usuário (política de autoplay dos navegadores). */
  async unlock() {
    this.#ensureCtx();
    try { await this.ctx?.resume(); } catch { /* ignora */ }
    this.blocked = false;
    if (this.music) this.apply(this.music, this.skew);
  }
  apply(music, skew = this.skew) {
    this.music = music; this.skew = skew;
    const track = music.tracks.find((t) => t.id === music.currentId);
    if (!this.enabled || !track) { this.el.pause(); return; }
    if (this.curId !== track.id) { this.curId = track.id; this.el.src = `/api/music/file/${track.id}`; }
    if (this.gain) this.gain.gain.value = music.volume; else this.el.volume = music.volume;
    const serverNow = Date.now() + skew;
    const target = music.position + (music.playing ? (serverNow - music.updatedAt) / 1000 : 0);
    if (music.playing) {
      if (this.el.readyState > 0 && Math.abs(this.el.currentTime - target) > 1.5) { try { this.el.currentTime = target % (this.el.duration || target + 1); } catch { /* ignora */ } }
      else if (this.el.readyState === 0) this.pendingSeek = target;
      this.#ensureCtx();
      const ok = () => { this.blocked = this.ctx ? this.ctx.state !== "running" : false; if (this.blocked) this.onBlocked?.(); };
      this.el.play().then(() => { this.ctx?.resume?.().finally(ok); }).catch(() => { this.blocked = true; this.onBlocked?.(); });
    } else this.el.pause();
  }
  /** Energia de graves 0..1 (0 se nada toca). */
  bass() {
    if (!this.analyser || !this.playing) return 0;
    this.analyser.getByteFrequencyData(this.data);
    let sum = 0; for (let i = 1; i <= 5; i++) sum += this.data[i];
    return sum / 5 / 255;
  }
  /** n bandas para o equalizador do telão. */
  spectrum(n = 24) {
    const out = new Array(n).fill(0);
    if (!this.analyser || !this.playing) return out;
    const len = Math.min(this.data.length, 300);
    for (let i = 0; i < n; i++) {
      const a = Math.floor(Math.pow(i / n, 1.7) * len) + 1, b = Math.max(a + 1, Math.floor(Math.pow((i + 1) / n, 1.7) * len) + 1);
      let sum = 0; for (let j = a; j < b; j++) sum += this.data[j]; out[i] = sum / (b - a) / 255;
    }
    return out;
  }
}
