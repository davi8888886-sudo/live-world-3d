// Personagem "bloco" (v2.3) inspirado na foto de referência: corpo de peças arredondadas, cabelo cacheado volumoso,
// óculos escuros, sorriso com dentes, correntes/relógio/brincos prateados, camiseta, calça cargo e tênis preto e branco.
// Mesma interface do humanoide antigo (joints hips/spine/head/arm*/fore*/thigh*/shin*), então as danças continuam iguais.
// Geometrias são compartilhadas entre personagens (userData.shared) para poupar memória e carregamento.
import * as THREE from "three";

const TAU = Math.PI * 2;
const GEO = new Map(), TEX = new Map();

/** Caixa com cantos arredondados (normais suaves). Cache por tamanho. */
function rbox(w, h, d, r = 0.03) {
  r = Math.min(r, Math.min(w, h, d) / 4.2);
  const key = [w, h, d, r].map((n) => n.toFixed(3)).join("|");
  let g = GEO.get(key); if (g) return g;
  g = new THREE.BoxGeometry(w, h, d, 4, 4, 4);
  const p = g.attributes.position, n = g.attributes.normal;
  const ix = w / 2 - r, iy = h / 2 - r, iz = d / 2 - r, cl = (v, m) => Math.max(-m, Math.min(m, v));
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const cx = cl(x, ix), cy = cl(y, iy), cz = cl(z, iz), dx = x - cx, dy = y - cy, dz = z - cz, len = Math.hypot(dx, dy, dz);
    if (len > 1e-6) { const s = r / len; p.setXYZ(i, cx + dx * s, cy + dy * s, cz + dz * s); n.setXYZ(i, dx / len, dy / len, dz / len); }
  }
  g.userData.shared = true; GEO.set(key, g); return g;
}
function shared(key, make) { let g = GEO.get(key); if (!g) { g = make(); g.userData.shared = true; GEO.set(key, g); } return g; }
const sphere = () => shared("sph", () => new THREE.SphereGeometry(1, 10, 8));
const plane = (w, h) => shared(`pl${w}|${h}`, () => new THREE.PlaneGeometry(w, h));

function tex(key, w, h, draw) {
  let t = TEX.get(key); if (t) return t;
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d"); x.lineJoin = "round"; x.lineCap = "round"; draw(x, w, h);
  t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; TEX.set(key, t); return t;
}
/** Bocas: grin (sorriso com dentes, como na referência), smile (sorriso fechado), hype (boca aberta, para presentes). */
function mouthTex(kind) {
  return tex("mouth-" + kind, 256, 128, (x) => {
    if (kind === "smile") {
      x.beginPath(); x.moveTo(60, 50); x.quadraticCurveTo(128, 100, 196, 50); x.lineWidth = 12; x.strokeStyle = "#3a1d17"; x.stroke(); return;
    }
    if (kind === "hype") {
      x.beginPath(); x.moveTo(52, 30); x.quadraticCurveTo(128, 20, 204, 30); x.quadraticCurveTo(200, 118, 128, 118); x.quadraticCurveTo(56, 118, 52, 30); x.closePath();
      x.fillStyle = "#4a1620"; x.fill();
      x.beginPath(); x.ellipse(128, 100, 38, 16, 0, 0, TAU); x.fillStyle = "#e8657a"; x.fill();
      x.beginPath(); x.moveTo(60, 28); x.quadraticCurveTo(128, 18, 196, 28); x.lineTo(192, 52); x.quadraticCurveTo(128, 60, 64, 52); x.closePath(); x.fillStyle = "#fff"; x.fill();
      x.lineWidth = 8; x.strokeStyle = "#3a1d17"; x.beginPath(); x.moveTo(52, 30); x.quadraticCurveTo(128, 20, 204, 30); x.quadraticCurveTo(200, 118, 128, 118); x.quadraticCurveTo(56, 118, 52, 30); x.stroke(); return;
    }
    x.beginPath(); x.moveTo(36, 38); x.quadraticCurveTo(128, 28, 220, 38); x.quadraticCurveTo(206, 106, 128, 112); x.quadraticCurveTo(50, 106, 36, 38); x.closePath();
    x.fillStyle = "#fff"; x.fill(); x.lineWidth = 10; x.strokeStyle = "#3a1d17"; x.stroke();
    x.lineWidth = 4; x.strokeStyle = "rgba(58,29,23,.55)"; x.beginPath(); x.moveTo(56, 66); x.quadraticCurveTo(128, 76, 200, 66); x.stroke();
  });
}
/** Marca branca/preta genérica (um "check" curvo desenhado aqui; não é logotipo de marca real). */
function swooshTex(color) {
  return tex("swoosh-" + color, 256, 110, (x) => {
    x.fillStyle = color; x.beginPath(); x.moveTo(8, 36); x.bezierCurveTo(50, 96, 130, 88, 246, 10); x.bezierCurveTo(150, 60, 70, 66, 8, 36); x.closePath(); x.fill();
  });
}

/** Curls: posições numa cúpula (espiral áurea), sem cobrir o rosto. */
function curlPositions(n, cy, rx, ry, rz, rand) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const t = (i + 0.5) / n, ny = 1 - 1.55 * t, rr = Math.sqrt(Math.max(0, 1 - ny * ny)), ph = i * 2.399963 + rand() * 0.3;
    const nx = Math.cos(ph) * rr, nz = Math.sin(ph) * rr;
    if (nz > 0.3 && ny < 0.58) continue;          // testa e laterais do rosto livres
    if (ny < 0.05 && nz > -0.35) continue;        // não cobre orelhas
    out.push([nx * rx, cy + ny * ry, nz * rz]);
  }
  return out;
}

export function buildBlocky(look) {
  const M = (c, rough = 0.6, extra = {}) => new THREE.MeshStandardMaterial({ color: c, roughness: rough, ...extra });
  const skin = M(look.skin, 0.5), top = M(look.top, 0.75), bottom = M(look.bottom, 0.8), bottomDk = M(look.bottomDark ?? look.bottom, 0.85);
  const shoeUp = M(look.shoe, 0.45), sole = M(0xf4f4f4, 0.5), toe = M(look.shoe === 0xf4f4f4 ? 0x151515 : 0xf4f4f4, 0.5);
  const hair = M(look.hair, 0.6), dark = M(0x050507, 0.18, { metalness: 0.25 });
  const silver = M(0xdfe6ef, 0.28, { metalness: 0.55, emissive: 0x6c7684, emissiveIntensity: 0.55 });
  const rand = (() => { let s = (look.seed || 12345) >>> 0 || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); })();
  const bw = [0.92, 1, 1.1][look.build];
  const shorts = look.legwear !== "pants";
  const mesh = (g, m, parent, x = 0, y = 0, z = 0) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); parent.add(o); return o; };

  const root = new THREE.Group(), hips = new THREE.Group(); hips.position.y = 0.93; root.add(hips);
  mesh(rbox(0.54, 0.15, 0.3, 0.05), bottom, hips, 0, -0.02, 0);

  // tronco: camiseta + marca no peito + correntes
  const spine = new THREE.Group(); spine.position.y = 0.05; hips.add(spine);
  mesh(rbox(0.54 * bw, 0.57, 0.3, 0.05), top, spine, 0, 0.285, 0);
  mesh(rbox(0.12, 0.1, 0.12, 0.03), skin, spine, 0, 0.6, 0);                       // pescoço
  const logo = mesh(plane(0.12, 0.052), new THREE.MeshBasicMaterial({ map: swooshTex(look.darkTop ? "#ffffff" : "#111111"), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }), spine, 0.13 * bw, 0.43, 0.1515);
  if (look.chain) {
    const ring = mesh(shared("chainU", () => new THREE.TorusGeometry(0.115, 0.013, 6, 22, Math.PI)), silver, spine, 0, 0.56, 0.158); ring.rotation.z = Math.PI; ring.scale.set(1, 1.45, 0.6);
    const neck = mesh(shared("chainN", () => new THREE.TorusGeometry(0.066, 0.011, 6, 16)), silver, spine, 0, 0.575, 0); neck.rotation.x = Math.PI / 2;
  }

  // cabeça
  const head = new THREE.Group(); head.position.y = 0.58; spine.add(head);
  mesh(rbox(0.32, 0.3, 0.3, 0.07), skin, head, 0, 0.15, 0);
  mesh(rbox(0.04, 0.04, 0.03, 0.01), skin, head, 0, 0.12, 0.155);                   // nariz
  const mouthMat = new THREE.MeshBasicMaterial({ map: mouthTex("grin"), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  mesh(plane(0.17, 0.085), mouthMat, head, 0, 0.06, 0.1515);
  for (const sx of [-1, 1]) {
    mesh(rbox(0.03, 0.08, 0.06, 0.012), skin, head, sx * 0.173, 0.14, 0);          // orelhas
    if (look.earring) mesh(sphere(), silver, head, sx * 0.19, 0.1, 0.01).scale.setScalar(0.014);
    const brow = mesh(rbox(0.09, 0.02, 0.02, 0.008), hair, head, sx * 0.075, 0.255, 0.152); brow.rotation.z = -sx * 0.12;
  }
  const eyes = [];
  if (look.glasses) {                                                                // óculos escuros largos (como na foto)
    for (const sx of [-1, 1]) {
      mesh(rbox(0.14, 0.088, 0.035, 0.014), dark, head, sx * 0.08, 0.195, 0.166);
      mesh(rbox(0.012, 0.022, 0.16, 0.005), dark, head, sx * 0.165, 0.205, 0.08);
    }
    mesh(rbox(0.05, 0.022, 0.03, 0.008), dark, head, 0, 0.215, 0.166);
    mesh(rbox(0.31, 0.022, 0.034, 0.008), dark, head, 0, 0.246, 0.166);
  } else {
    for (const sx of [-1, 1]) {
      const eye = new THREE.Group(); eye.position.set(sx * 0.075, 0.195, 0.152); head.add(eye); eyes.push(eye);
      mesh(rbox(0.07, 0.06, 0.012, 0.005), M(0xffffff, 0.3), eye);
      mesh(rbox(0.036, 0.044, 0.014, 0.005), M(look.eye, 0.3), eye, 0, 0, 0.004);
      mesh(rbox(0.016, 0.022, 0.016, 0.003), M(0x050505, 0.3), eye, 0, 0, 0.008);
    }
  }

  // cabelo
  const st = look.cap && (look.style === "curly" || look.style === "afro") ? "short" : look.style;
  const scalp = (w = 0.335, h = 0.075, d = 0.315, y = 0.31) => mesh(rbox(w, h, d, 0.04), hair, head, 0, y, -0.005);
  if (st === "curly" || st === "afro") {
    const big = st === "afro", rx = big ? 0.235 : 0.185, ry = big ? 0.21 : 0.15, cr = big ? 0.082 : 0.062, n = big ? 100 : 74;
    scalp(0.335, 0.08, 0.32, 0.3); mesh(rbox(0.33, 0.2, 0.08, 0.04), hair, head, 0, 0.2, -0.14);
    for (const sx of [-1, 1]) mesh(rbox(0.03, 0.1, 0.2, 0.012), hair, head, sx * 0.165, 0.245, 0.02);
    const pts = curlPositions(n, 0.2, rx, ry, rx * 1.02, rand);
    const im = new THREE.InstancedMesh(sphere(), hair, pts.length), dm = new THREE.Object3D();
    pts.forEach((p, i) => { const s = cr * (0.85 + rand() * 0.35); dm.position.set(p[0], p[1], p[2] - 0.01); dm.scale.set(s, s * 0.95, s); dm.rotation.set(rand() * 3, rand() * 3, 0); dm.updateMatrix(); im.setMatrixAt(i, dm.matrix); });
    im.instanceMatrix.needsUpdate = true; head.add(im);
  } else if (st === "buzz") { scalp(0.33, 0.04, 0.31, 0.325); mesh(rbox(0.325, 0.14, 0.04, 0.02), hair, head, 0, 0.23, -0.15); }
  else {
    scalp(); mesh(rbox(0.33, 0.2, 0.07, 0.04), hair, head, 0, 0.2, -0.14);
    mesh(rbox(0.3, 0.035, 0.05, 0.015), hair, head, 0, 0.283, 0.15);                // franja
    if (st === "long") { mesh(rbox(0.34, 0.42, 0.07, 0.03), hair, head, 0, 0.02, -0.17); for (const sx of [-1, 1]) mesh(rbox(0.04, 0.3, 0.16, 0.015), hair, head, sx * 0.17, 0.12, -0.04); }
    if (st === "bun") mesh(sphere(), hair, head, 0, 0.42, -0.08).scale.setScalar(0.085);
    if (st === "ponytail") { const pt = mesh(rbox(0.08, 0.3, 0.08, 0.03), hair, head, 0, 0.13, -0.22); pt.rotation.x = 0.35; }
  }
  if (look.cap) {
    const cm = M(look.capColor, 0.6);
    mesh(rbox(0.35, 0.11, 0.34, 0.05), cm, head, 0, 0.335, -0.005); mesh(rbox(0.3, 0.025, 0.16, 0.01), cm, head, 0, 0.29, 0.2).rotation.x = 0.1;
  }
  if (look.headphones) {
    const hm = M(look.top === 0x16161a ? 0xff2d95 : look.top, 0.4);
    const band = mesh(shared("hpBand", () => new THREE.TorusGeometry(0.19, 0.014, 6, 18, Math.PI)), hm, head, 0, 0.15, 0); band.scale.set(1, 1.05, 1);
    for (const sx of [-1, 1]) mesh(rbox(0.05, 0.12, 0.12, 0.02), hm, head, sx * 0.195, 0.15, 0);
  }

  // braços: manga de camiseta + braço + antebraço + mão fechada (relógio/pulseira prateados)
  const j = { hips, spine, head };
  for (const [side, sx] of [["L", 1], ["R", -1]]) {
    const arm = new THREE.Group(); arm.position.set(sx * (0.27 * bw + 0.115), 0.5, 0); spine.add(arm);
    mesh(rbox(0.22, 0.21, 0.24, 0.05), top, arm, 0, -0.07, 0);
    mesh(rbox(0.16, 0.33, 0.18, 0.04), skin, arm, 0, -0.17, 0);
    const fore = new THREE.Group(); fore.position.y = -0.3; arm.add(fore);
    mesh(rbox(0.155, 0.3, 0.175, 0.04), skin, fore, 0, -0.14, 0);
    mesh(rbox(0.18, 0.13, 0.2, 0.05), skin, fore, 0, -0.34, 0.01);                   // mão
    mesh(rbox(0.05, 0.07, 0.07, 0.02), skin, fore, 0, -0.33, 0.11);                  // polegar
    if (look.watch && side === "L") { mesh(rbox(0.19, 0.05, 0.205, 0.02), silver, fore, 0, -0.22, 0); mesh(rbox(0.035, 0.075, 0.075, 0.012), silver, fore, 0.09, -0.22, 0); }
    const thigh = new THREE.Group(); thigh.position.set(sx * 0.14, -0.03, 0); hips.add(thigh);
    if (shorts) { mesh(rbox(0.26, 0.26, 0.29, 0.05), bottom, thigh, 0, -0.13, 0); mesh(rbox(0.215, 0.22, 0.25, 0.04), skin, thigh, 0, -0.34, 0); }
    else mesh(rbox(0.26, 0.46, 0.3, 0.05), bottom, thigh, 0, -0.22, 0);
    if (!shorts && look.cargo) { mesh(rbox(0.05, 0.16, 0.18, 0.02), bottomDk, thigh, sx * 0.147, -0.2, 0.01); mesh(rbox(0.054, 0.05, 0.19, 0.015), bottom, thigh, sx * 0.15, -0.14, 0.01); }
    if (side === "L" && !shorts) mesh(plane(0.075, 0.033), logo.material, thigh, 0.03, -0.07, 0.1515);
    const shin = new THREE.Group(); shin.position.y = -0.45; thigh.add(shin);
    if (!shorts) { mesh(rbox(0.27, 0.42, 0.3, 0.05), bottom, shin, 0, -0.2, 0); mesh(rbox(0.285, 0.06, 0.315, 0.025), bottomDk, shin, 0, -0.385, 0); }
    else mesh(rbox(0.2, 0.34, 0.22, 0.04), skin, shin, 0, -0.17, 0);
    mesh(rbox(0.26, 0.04, 0.38, 0.018), sole, shin, 0, -0.43, 0.05);
    mesh(rbox(0.245, 0.085, 0.37, 0.04), shoeUp, shin, 0, -0.372, 0.05);
    mesh(rbox(0.232, 0.06, 0.14, 0.025), toe, shin, 0, -0.372, 0.15);
    j["arm" + side] = arm; j["fore" + side] = fore; j["thigh" + side] = thigh; j["shin" + side] = shin;
  }
  root.traverse((o) => { if (o.isMesh) o.castShadow = true; });

  let mood = "grin";
  const setMood = (k) => { if (k === mood) return; mood = k; mouthMat.map = mouthTex(k); };
  return { root, joints: j, eyes, mixer: null, clips: [], height: st === "afro" ? 2.06 : 1.98, setMood };
}
