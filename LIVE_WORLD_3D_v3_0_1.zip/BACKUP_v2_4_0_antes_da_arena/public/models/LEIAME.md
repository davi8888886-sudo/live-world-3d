# Modelos 3D de personagens (GLB)

Nenhum modelo GLB acompanha este projeto: o ambiente de criação estava sem internet e **não é permitido** incluir
modelos sem licença verificada. Sem GLB, o palco usa um humanoide procedural (rosto, cabelo, roupas, mãos, sapatos) —
é uma solução de reserva, **não é "ultra-realista"**.

## Como usar modelos realistas
1. Baixe/crie modelos **humanos com esqueleto (rig)** em `.glb`, com licença que permita seu uso
   (CC0/CC-BY, ou conforme os termos do site de origem; confira a licença de cada arquivo).
2. Copie para `public/models/characters/` (ex.: `ana.glb`, `bruno.glb`).
3. Edite `public/models/manifest.json`:
   ```json
   { "characters": [ { "file": "/models/characters/ana.glb" }, { "file": "/models/characters/bruno.glb" } ],
     "animations": "/models/animations.glb" }
   ```
   `animations` é opcional: um GLB só com clipes (funciona quando o esqueleto tem os mesmos nomes de ossos, como no padrão Mixamo).
4. Os clipes são escolhidos pelo **nome**: `walk` (andar), `dance`/`samba`/`hip`/`groove`… (dançar),
   `celebr`/`victory`/`cheer`/`jump` (comemorar), `wave`/`greet` (acenar), `spin`/`twirl` (girar).
   Sem clipe `walk`, o personagem aparece direto no lugar (sem andar).
5. Reinicie o servidor e abra `/stage.html?debug=1` para ver quantos modelos GLB carregaram.

Observações: arquivos grandes pesam no celular (prefira < 5 MB por modelo, texturas ≤ 1024). Formato VRM não é suportado
nesta versão (precisa da biblioteca three-vrm).
