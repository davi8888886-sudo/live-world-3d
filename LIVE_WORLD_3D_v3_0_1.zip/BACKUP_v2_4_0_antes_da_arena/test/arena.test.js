// Regras da arena: vagas, ranking real e inatividade. Nada aqui simula pessoas.
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { makeSlots, addGift, topSupporters, isActive, parseIdle, fmtNum, FLOOR } from "../public/stage/arena-rules.js";

test("vagas: únicas, dentro da pista, com espaço entre avatares, centro primeiro", () => {
  const s = makeSlots(56); assert.equal(s.length, 56);
  let min = 99; for (let i = 0; i < s.length; i++) for (let j = i + 1; j < s.length; j++) min = Math.min(min, Math.hypot(s[i][0] - s[j][0], s[i][1] - s[j][1]));
  assert.ok(min >= 1.5, "espaço mínimo " + min);
  for (const [x, z] of s) { assert.ok(Math.abs(x) < FLOOR.w / 2 - 1.5); assert.ok(Math.abs(z - FLOOR.cz) < FLOOR.d / 2 - 1.5); }
  assert.ok(Math.hypot(s[0][0], s[0][1]) < Math.hypot(s[55][0], s[55][1]), "primeiras vagas ficam no centro");
});
test("ranking: soma só diamantes reais; sem presente = vazio; top 5 ordenado", () => {
  const r = new Map(); assert.deepEqual(topSupporters(r), []);
  addGift(r, { id: "a", name: "Ana" }, 0); addGift(r, { id: "b", name: "Bia" }, -5); addGift(r, null, 10);
  assert.deepEqual(topSupporters(r), [], "presente de 0 diamantes ou sem usuário não conta");
  for (const [id, n, v] of [["a", "Ana", 100], ["b", "Bia", 300], ["a", "Ana", 250], ["c", "Caio", 10], ["d", "Duda", 20], ["e", "Edu", 30], ["f", "Fábio", 40]]) addGift(r, { id, name: n }, v);
  const top = topSupporters(r, 5); assert.equal(top.length, 5);
  assert.deepEqual(top.map((t) => [t.name, t.total]), [["Ana", 350], ["Bia", 300], ["Fábio", 40], ["Edu", 30], ["Duda", 20]]);
});
test("atividade/inatividade e formato de números", () => {
  assert.ok(isActive(1000, 1000 + 299000, 300000)); assert.ok(!isActive(1000, 1000 + 301000, 300000));
  assert.equal(parseIdle("60"), 60); assert.equal(parseIdle("1"), 300); assert.equal(parseIdle(null), 300); assert.equal(parseIdle("abc"), 300);
  assert.equal(fmtNum(950), "950"); assert.equal(fmtNum(12500), "12.5K"); assert.equal(fmtNum(2500000), "2.5M");
});
test("o cenário não cria multidão/silhueta/bot (análise estática)", () => {
  const w = fs.readFileSync(new URL("../public/stage/world.js", import.meta.url), "utf8"), e = fs.readFileSync(new URL("../public/stage/engine.js", import.meta.url), "utf8");
  assert.ok(!/InstancedMesh|CapsuleGeometry|crowd|plateia/i.test(w.replace(/^\s*\/\/.*$/gm, "")), "world.js não pode desenhar pessoas");
  assert.ok(!/Math\.random\(\)[^;]*spawn|spawn\([^)]*(fake|bot|npc)/i.test(e), "engine.js só cria avatar a partir de eventos");
  assert.equal((e.match(/\bspawn\(/g) || []).length, 3, "spawn só em: definição, onEvent (evento real) e hello (usuários reais recentes)");
});
