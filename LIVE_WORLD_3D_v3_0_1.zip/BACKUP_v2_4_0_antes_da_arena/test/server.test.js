import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createApp } from "../server.js";
import { encodeFrame, decodeFrames } from "../lib/ws.js";

class FakeConn extends EventEmitter {
  constructor(fail) { super(); this.fail = fail; }
  async connect() { if (this.fail) throw new Error(this.fail); }
  async disconnect() {}
}
let app, base, conns = [], dir;
const TOKEN = "segredo-de-teste";
const auth = { "x-admin-token": TOKEN, "content-type": "application/json" };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const post = (p, body, h = auth) => fetch(base + p, { method: "POST", headers: h, body: JSON.stringify(body ?? {}) });

before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "lw-"));
  app = createApp({
    port: 0, host: "127.0.0.1", adminToken: TOKEN, enableTestEvents: true, musicDir: dir, maxUploadMb: 1, backoff: [20, 20],
    log: () => {},
    connectorFactory: async (u) => { const c = new FakeConn(u === "offline" ? "The user is not live" : null); conns.push(c); return c; },
  });
  base = `http://127.0.0.1:${await app.start()}`;
});
after(async () => { await app.stop(); fs.rmSync(dir, { recursive: true, force: true }); });

function openWs() {
  const ws = new WebSocket(base.replace("http", "ws") + "/ws");
  const msgs = [];
  ws.onmessage = (e) => msgs.push(JSON.parse(e.data));
  return new Promise((res, rej) => { ws.onopen = () => res({ ws, msgs }); ws.onerror = () => rej(new Error("ws falhou")); });
}

test("codec WebSocket: ida e volta com payload pequeno, médio e grande", () => {
  for (const n of [5, 300, 70000]) {
    const payload = Buffer.alloc(n, 97);
    const f = encodeFrame(1, payload);
    assert.equal(f[0], 0x81);
    // monta frame de cliente mascarado equivalente para testar o decoder
    const mask = Buffer.from([1, 2, 3, 4]);
    const body = Buffer.from(payload.map((b, i) => b ^ mask[i & 3]));
    const head = n < 126 ? Buffer.from([0x81, 0x80 | n]) : n < 65536 ? Buffer.from([0x81, 0xfe, n >> 8, n & 255]) : (() => { const h = Buffer.alloc(10); h[0] = 0x81; h[1] = 0xff; h.writeBigUInt64BE(BigInt(n), 2); return h; })();
    head[1] |= 0x80;
    const r = decodeFrames(Buffer.concat([head, mask, body]), 100000);
    assert.equal(r.frames.length, 1); assert.ok(r.frames[0].data.equals(payload));
  }
  assert.equal(decodeFrames(Buffer.from([0x81, 0x05, 1, 2, 3, 4, 5, 6, 7]), 100).error, 1002); // sem máscara
  assert.equal(decodeFrames(Buffer.from([0x81, 0x85, 0, 0, 0, 0]), 2).error, 1009); // grande demais
});

test("GET /health responde 200 com diagnóstico", async () => {
  const r = await fetch(base + "/health"); const j = await r.json();
  assert.equal(r.status, 200); assert.equal(j.ok, true); assert.equal(j.tiktok.status, "disconnected");
  assert.match(j.node, /^v\d+/); assert.equal(typeof j.uptimeSec, "number");
});
test("arquivos estáticos, 404 JSON e proteção contra path traversal", async () => {
  assert.equal((await fetch(base + "/")).status, 200);
  assert.equal((await fetch(base + "/nao-existe.js")).status, 404);
  const r = await fetch(base + "/..%2fserver.js"); assert.ok([400, 404].includes(r.status));
  assert.equal((await fetch(base + "/%2e%2e/package.json")).status, 404);
  assert.equal((await fetch(base + "/vendor/three/package.json")).status, 404);
  assert.equal((await fetch(base + "/api/inexistente")).status, 404);
});
test("rotas administrativas exigem o token", async () => {
  assert.equal((await post("/api/connect", { username: "x1" }, { "content-type": "application/json" })).status, 401);
  assert.equal((await post("/api/connect", { username: "x1" }, { "x-admin-token": "errado" })).status, 401);
  assert.equal((await fetch(base + "/api/auth-check", { headers: auth })).status, 200);
});
test("conectar: usuário inválido 400; offline 502 com mensagem clara; sucesso 200", async () => {
  let r = await post("/api/connect", { username: "!!" }); assert.equal(r.status, 400);
  r = await post("/api/connect", { username: "@offline" }); let j = await r.json();
  assert.equal(r.status, 502); assert.match(j.error, /não está ao vivo/); assert.equal(j.status.status, "error");
  r = await post("/api/connect", { username: "@Fulano" }); j = await r.json();
  assert.equal(r.status, 200); assert.equal(j.status, "connected"); assert.equal(j.username, "fulano");
});
test("WebSocket: hello, eventos reais do conector e reconexão automática", async () => {
  const { ws, msgs } = await openWs();
  await wait(100);
  assert.equal(msgs[0].t, "hello"); assert.equal(msgs[0].status.status, "connected");
  const c = conns.at(-1);
  c.emit("member", { user: { uniqueId: "ana", nickname: "Ana" } });
  c.emit("member", { user: { uniqueId: "ana", nickname: "Ana" } });
  c.emit("gift", { user: { uniqueId: "ana", nickname: "Ana" }, giftId: 7, giftType: 1, repeatCount: 3, repeatEnd: false, giftDetails: { giftName: "Rose", diamondCount: 1 } });
  c.emit("gift", { user: { uniqueId: "ana", nickname: "Ana" }, giftId: 7, giftType: 1, repeatCount: 3, repeatEnd: true, giftDetails: { giftName: "Rose", diamondCount: 1 } });
  await wait(1200);
  const evs = msgs.filter((m) => m.t === "event").map((m) => m.ev);
  assert.deepEqual(evs.map((e) => e.type), ["member", "member", "gift-progress", "gift"]);
  assert.equal(evs[0].isNewViewer, true); assert.equal(evs[1].isNewViewer, false);
  assert.equal(evs[3].count, 3);
  assert.equal(msgs.filter((m) => m.t === "stats").at(-1).stats.gifts, 3);
  const before = conns.length; msgs.length = 0;
  c.emit("disconnected");
  await wait(150);
  assert.ok(conns.length > before, "criou nova conexão");
  assert.deepEqual([...new Set(msgs.filter((m) => m.t === "status").map((m) => m.status.status))], ["reconnecting", "connected"]);
  ws.close();
});
test("WebSocket recusa caminho errado", async () => {
  const ws = new WebSocket(base.replace("http", "ws") + "/outro");
  await new Promise((res) => { ws.onerror = res; ws.onclose = res; });
  assert.notEqual(ws.readyState, 1);
});
test("desconectar muda o status e para eventos", async () => {
  const r = await post("/api/disconnect"); const j = await r.json();
  assert.equal(j.status, "disconnected");
  assert.equal((await (await fetch(base + "/health")).json()).tiktok.status, "disconnected");
});
test("evento de teste local não muda o status da conexão", async () => {
  const { ws, msgs } = await openWs(); await wait(50);
  const r = await post("/api/test-event", { type: "member", name: "Teste1" }); assert.equal(r.status, 200);
  await wait(80);
  const ev = msgs.find((m) => m.t === "event").ev;
  assert.equal(ev.test, true); assert.equal(app.manager.status, "disconnected");
  assert.equal((await post("/api/test-event", { type: "xx" })).status, 400);
  ws.close();
});
test("comando de câmera é validado e transmitido", async () => {
  const { ws, msgs } = await openWs(); await wait(50);
  assert.equal((await post("/api/cmd", { camera: "voar" })).status, 400);
  assert.equal((await post("/api/cmd", { camera: "wide", dance: "samba" })).status, 200);
  await wait(80);
  assert.deepEqual(msgs.find((m) => m.t === "cmd").cmd, { camera: "wide", dance: "samba" });
  ws.close();
});
test("música: upload, lista, Range, controles sincronizados, remoção, limites", async () => {
  const bytes = Buffer.alloc(5000, 7);
  const up = (name, body, h = {}) => fetch(base + "/api/music", { method: "POST", headers: { "x-admin-token": TOKEN, "x-filename": encodeURIComponent(name), ...h }, body });
  assert.equal((await up("virus.exe", bytes)).status, 415);
  assert.equal((await fetch(base + "/api/music", { method: "POST", headers: { "x-filename": "a.mp3" }, body: bytes })).status, 401);
  assert.equal((await up("grande.mp3", Buffer.alloc(1048576 + 10))).status, 413);
  assert.equal((await up("vazio.mp3", Buffer.alloc(0))).status, 400);
  const r = await up("Minha Música.mp3", bytes); const j = await r.json();
  assert.equal(r.status, 201); assert.equal(j.track.name, "Minha Música");
  const list = await (await fetch(base + "/api/music")).json();
  assert.equal(list.tracks.length, 1); assert.equal(list.currentId, j.track.id);
  const full = await fetch(base + `/api/music/file/${j.track.id}`);
  assert.equal(full.headers.get("content-type"), "audio/mpeg"); assert.equal((await full.arrayBuffer()).byteLength, 5000);
  const part = await fetch(base + `/api/music/file/${j.track.id}`, { headers: { range: "bytes=100-199" } });
  assert.equal(part.status, 206); assert.equal(part.headers.get("content-range"), "bytes 100-199/5000"); assert.equal((await part.arrayBuffer()).byteLength, 100);
  assert.equal((await fetch(base + `/api/music/file/${j.track.id}`, { headers: { range: "bytes=9000-" } })).status, 416);
  const { ws, msgs } = await openWs(); await wait(50);
  await post("/api/music/control", { action: "play" }); await post("/api/music/control", { action: "volume", value: 0.3 });
  await wait(100);
  const last = msgs.filter((m) => m.t === "music").at(-1).music;
  assert.equal(last.playing, true); assert.equal(last.volume, 0.3);
  assert.equal((await post("/api/music/control", { action: "volume", value: "abc" })).status, 400);
  ws.send(JSON.stringify({ t: "ended", id: j.track.id })); await wait(80); // faixa única: reinicia, continua tocando
  assert.equal(app.music.snapshot().playing, true);
  assert.equal((await fetch(base + `/api/music/${j.track.id}`, { method: "DELETE", headers: auth })).status, 200);
  assert.equal((await (await fetch(base + "/api/music")).json()).tracks.length, 0);
  ws.close();
});
