import test from "node:test";
import assert from "node:assert/strict";
import { createTikTokConnection } from "../lib/adapter.js";
import { LiveManager } from "../lib/live.js";

// Módulo FALSO que imita a API documentada do piratetok-live-js. Não é a biblioteca real nem o TikTok.
const EventType = Object.fromEntries(["chat","gift","like","member","join","liveEnded","reconnecting","connected","disconnected"].map((k) => [k, k]));
function fakeModule() {
  const state = { handlers: {}, calls: [] };
  class TikTokLiveClient {
    constructor(u) { state.user = u; }
    maxRetries(n) { state.calls.push(["maxRetries", n]); return this; }
    staleTimeout(n) { state.calls.push(["staleTimeout", n]); return this; }
    proxy(u) { state.calls.push(["proxy", u]); return this; }
    on(t, f) { state.handlers[t] = f; return this; }
    async connect() { return "123"; }
    disconnect() { state.disc = true; }
  }
  class GiftStreakTracker { process(d) { return { eventGiftCount: d.__delta ?? 0 }; } }
  return { state, mod: { TikTokLiveClient, EventType, GiftStreakTracker } };
}
const U = { uniqueId: "ana", nickname: "Ana" };

test("adaptador → LiveManager: chat, curtida, presente (delta), entrada sem duplicar", async () => {
  const { state, mod } = fakeModule();
  const m = new LiveManager({ factory: (u) => createTikTokConnection(u, { loadModule: async () => mod, env: { TIKTOK_PROXY: "socks5://h:1" } }), flushEveryMs: 1000 });
  const evs = []; m.on("event", (e) => evs.push(e));
  await m.connect("fulano");
  assert.equal(state.user, "fulano"); assert.deepEqual(state.calls, [["proxy", "socks5://h:1"]]);
  const h = state.handlers;
  h.chat({ user: U, content: "oi!" });
  h.like({ user: U, count: 5, total: 90 });
  h.join({ user: U }); h.member({ user: U });
  h.gift({ user: U, gift: { id: 7, name: "Rose", diamondCount: 1 }, repeatCount: 3, __delta: 3 });
  h.gift({ user: U, gift: { id: 7, name: "Rose", diamondCount: 1 }, repeatCount: 3, __delta: 0 });
  assert.deepEqual(evs.map((e) => e.type), ["chat", "like", "member", "gift"]);
  assert.equal(evs[0].text, "oi!"); assert.equal(evs[1].count, 5);
  assert.equal(evs[3].count, 3); assert.equal(evs[3].total, 3); assert.equal(evs[3].giftName, "Rose");
  await m.disconnect(); assert.equal(state.disc, true);
});

test("reconexão interna da biblioteca reflete no status e volta a CONECTADO", async () => {
  const { state, mod } = fakeModule();
  const m = new LiveManager({ factory: (u) => createTikTokConnection(u, { loadModule: async () => mod, env: {} }), flushEveryMs: 1000 });
  const st = []; m.on("status", (s) => st.push(s.status));
  await m.connect("fulano");
  state.handlers.reconnecting({}); state.handlers.connected({});
  assert.deepEqual(st, ["connecting", "connected", "reconnecting", "connected"]);
  await m.disconnect();
});

test("módulo ausente → CONNECTOR_UNAVAILABLE", async () => {
  await assert.rejects(createTikTokConnection("x", { loadModule: async () => { throw new Error("nope"); } }), (e) => e.code === "CONNECTOR_UNAVAILABLE");
});
