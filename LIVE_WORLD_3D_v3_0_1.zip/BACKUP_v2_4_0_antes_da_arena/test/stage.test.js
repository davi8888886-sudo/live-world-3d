import test from "node:test";
import assert from "node:assert/strict";
import { dancePose, walkPose, POSE_KEYS, DANCE_IDS, SPECIAL_IDS, pickDance } from "../public/stage/dances.js";
import { BeatDetector } from "../public/stage/audio.js";

test("todas as danças geram poses finitas e limitadas, em qualquer fase/energia", () => {
  for (const id of [...DANCE_IDS, ...SPECIAL_IDS, "idle", "desconhecida"]) {
    for (let t = 0; t < 40; t += 0.37) for (const e of [0, 0.5, 1]) {
      const pose = dancePose(id, t * 2.1, e);
      for (const k of POSE_KEYS) {
        assert.ok(Number.isFinite(pose[k]), `${id}.${k}`);
        if (k !== "hry") assert.ok(Math.abs(pose[k]) < 3.2, `${id}.${k}=${pose[k]}`);
        if (k === "hy") assert.ok(pose[k] > -0.2 && pose[k] < 0.2, `${id}.hy`);
      }
    }
  }
});
test("caminhada: pernas alternam (sem as duas na mesma fase)", () => {
  let diff = 0;
  for (let p = 0; p < 6.3; p += 0.1) { const w = walkPose(p); assert.ok(POSE_KEYS.every((k) => Number.isFinite(w[k]))); diff += Math.abs(w.tlx + w.trx); }
  assert.ok(diff < 1e-9, "pernas em oposição");
});
test("pickDance é determinístico e válido", () => {
  assert.equal(pickDance("ana", 0), pickDance("ana", 0));
  assert.ok(DANCE_IDS.includes(pickDance("zé", 3)));
});
test("BeatDetector: batida a 120 BPM gera pulsos; silêncio não gera", () => {
  const d = new BeatDetector(); const dt = 1 / 60; let t = 0;
  for (let i = 0; i < 600; i++) { t += dt; const phase = (t % 0.5) / 0.5; d.update(0.15 + (phase < 0.12 ? 0.6 : 0), t, dt); }
  assert.ok(d.beats >= 12 && d.beats <= 24, `batidas=${d.beats}`);
  const q = new BeatDetector();
  for (let i = 0; i < 600; i++) { t += dt; q.update(0, t, dt); }
  assert.equal(q.beats, 0);
});
