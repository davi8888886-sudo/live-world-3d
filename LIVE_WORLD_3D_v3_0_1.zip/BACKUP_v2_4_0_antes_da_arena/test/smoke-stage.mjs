// Teste de fumaça do palco: roda o engine.js REAL (com THREE de mentira) ligado a um servidor real.
// Valida lógica (eventos → personagens, slots, presentes, câmera, números finitos). NÃO valida a aparência.
import assert from "node:assert/strict";
import fs from "node:fs"; import os from "node:os"; import path from "node:path";
import { EventEmitter } from "node:events";
import { createApp } from "../server.js";

class FakeConn extends EventEmitter { async connect() {} async disconnect() {} }
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "lw-smoke-"));
const app = createApp({ port: 0, host: "127.0.0.1", enableTestEvents: true, adminToken: "", musicDir: dir, log: () => {}, connectorFactory: async () => new FakeConn() });
const port = await app.start(), base = `http://127.0.0.1:${port}`;

const realFetch = globalThis.fetch;
globalThis.fetch = (u, o) => realFetch(new URL(u, base), o);
const els = {};
const mkEl = () => ({ hidden: false, textContent: "", style: {}, addEventListener() {}, setPointerCapture() {}, getContext: () => new Proxy(function () {}, { get: (_, k) => (k === "measureText" ? () => ({ width: 100 }) : () => new Proxy(function () {}, { get: () => () => {} })), set: () => true }), width: 0, height: 0 });
globalThis.window = globalThis;
Object.assign(globalThis, { innerWidth: 540, innerHeight: 960, devicePixelRatio: 1, addEventListener() {} });
Object.defineProperty(globalThis, "navigator", { value: { userAgent: "Android smoke" }, configurable: true });
globalThis.location = { search: process.env.SMOKE_MODE === "nobots" ? "?q=med&audio=0" : "?q=med&audio=0&test=1&idle=15", href: base + "/stage.html", protocol: "http:", host: `127.0.0.1:${port}`, replace() {} };
globalThis.document = { getElementById: (id) => (els[id] ??= mkEl()), createElement: () => mkEl(), addEventListener() {}, visibilityState: "visible" };
globalThis.Audio = class { constructor() { this.paused = true; this.readyState = 0; this.currentTime = 0; } addEventListener() {} pause() {} play() { return Promise.resolve(); } };
const rafs = []; globalThis.requestAnimationFrame = (cb) => { rafs.push(cb); return rafs.length; };
const warns = []; console.warn = (...a) => warns.push(a.join(" "));
const errors = []; process.on("uncaughtException", (e) => errors.push(e)); process.on("unhandledRejection", (e) => errors.push(e));
setTimeout(() => { console.error("SMOKE FALHOU: tempo esgotado"); process.exit(2); }, 90000).unref();
try {

await import("../public/stage/engine.js");
const S = globalThis.__stage;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let t = 1000;
const run = (frames) => { for (let i = 0; i < frames; i++) { t += 16.7; const cb = rafs.pop(); cb(t); assert.ok(Number.isFinite(S.director.cam.position.x + S.director.cam.position.y + S.director.cam.position.z), "câmera NaN"); const p = S.director.cam.position; assert.ok(p.y >= 0.99 && p.z >= -9.01 && p.z <= 45.01 && Math.abs(p.x) <= 24.01, `câmera fora dos limites ${p.x},${p.y},${p.z}`); } };
const post = (p, b) => realFetch(base + p, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(b) });

await sleep(400); run(5);
// ARENA VAZIA: sem eventos reais não existe nenhum personagem, multidão, silhueta nem malha instanciada no cenário.
run(300);
assert.equal(S.chars.size, 0, "sem eventos, a arena fica vazia");
let inst = 0; S.scene.traverse((o) => { if (o.instanceMatrix) inst++; });
assert.equal(inst, 0, "nenhuma multidão/instância decorativa no cenário");
if (process.env.SMOKE_MODE === "nobots") {
  // modo "nobots": eventos de teste do painel (ev.test) NÃO podem criar avatares sem ?test=1
  await post("/api/test-event", { type: "member", name: "Fantasma" }); await post("/api/test-event", { type: "gift", name: "Fantasma", giftName: "Rose", diamonds: 5, count: 1 });
  await sleep(400); run(120);
  assert.equal(S.chars.size, 0, "evento de teste não cria avatar");
  assert.deepEqual(S.led.rank, [], "evento de teste não entra no ranking");
  console.log("SMOKE NOBOTS OK"); await app.stop(); fs.rmSync(dir, { recursive: true, force: true }); process.exit(0);
}
await post("/api/test-event", { type: "member", name: "Ana" });
await post("/api/test-event", { type: "member", name: "Bruno" });
await post("/api/test-event", { type: "member", name: "Ana" }); // duplicada
await post("/api/test-event", { type: "chat", name: "Ana", text: "Oi pessoal! Que show lindo" });
await post("/api/test-event", { type: "like", name: "Bruno", count: 3 });
await sleep(300); run(30);
assert.equal(S.chars.size, 2, "Ana + Bruno, sem duplicar");
assert.ok([...S.chars.values()].every((c) => c.state === "entering"), "entram andando");
run(500); // ~8 s
assert.ok([...S.chars.values()].every((c) => c.state === "dancing"), "chegaram e dançam");
assert.ok(S.chars.size > 0 && [...S.chars.values()].every((c) => typeof c.model.setMood === "function"), "personagens bloco ativos (não caiu no humanoide de reserva)");
for (const c of S.chars.values()) {
  assert.ok(Math.abs(c.pos.x - c.target.x) < 0.06 && Math.abs(c.pos.z - c.target.z) < 0.06, "no lugar do palco");
  for (const j of Object.values(c.joints)) assert.ok(Number.isFinite(j.rotation.x + j.rotation.y + j.rotation.z + j.position.y), "pose finita");
}
// presente: dança especial + efeito + câmera
await post("/api/test-event", { type: "gift", name: "Carla", giftName: "Lion", diamonds: 500, count: 2 });
await sleep(300); run(20);
const carla = S.chars.get("carla"); assert.ok(carla, "Carla apareceu ao enviar presente");
assert.equal(carla.special, "spin", "Lion (≥1000💎 total) → spin (config/gifts.json)");
assert.equal(S.director.shot.kind, "gift", "câmera foca quem mandou presente");
run(400);
// ranking: só presentes reais (Carla: 500💎 x2 = 1000); ninguém mais aparece
assert.equal(S.led.rank.length, 1, "ranking só tem quem enviou presente");
assert.equal(S.led.rank[0].name, "Carla"); assert.equal(S.led.rank[0].total, 1000, "total real de diamantes");
// lotação: 30 espectadores → nunca passa do limite do palco; excedentes saem andando e são removidos
for (let i = 0; i < 30; i++) await post("/api/test-event", { type: "member", name: `Fã${i}` });
await sleep(600); run(60);
assert.ok(S.chars.size <= 24, `limite da arena (${S.chars.size})`);
const owners = new Set(); for (const c of S.chars.values()) { assert.ok(!owners.has(c.slot), "slot único"); owners.add(c.slot); }
run(700);
// saída por inatividade: sem nenhum evento real o avatar sai da arena e é removido
const before = S.chars.size; assert.ok(before > 0);
for (const c of S.chars.values()) c.lastActive -= 60000;
run(60); assert.equal(S.chars.size, 0, "inativos saem da arena");
run(900); assert.equal(S.leaving.length, 0, "saíram andando e foram removidos");
// quem volta a interagir reaparece (evento real)
await post("/api/test-event", { type: "chat", name: "Ana", text: "voltei" }); await sleep(300); run(20);
assert.ok(S.chars.get("ana"), "Ana reapareceu ao interagir");
// desconexão/novo reset limpa o palco
await app.manager.disconnect(); await app.manager.connect("@fulano"); await sleep(300); run(10);
assert.equal(S.chars.size, 0, "reset limpa personagens");
// modos de câmera
for (const m of ["wide", "manual", "auto"]) { S.director.setMode(m); run(120); }
S.director.drag(300, -200); S.director.zoom(0.1); run(60); // manual extremo respeita limites (assert dentro de run)
assert.equal(warns.filter((w) => /bloco falhou|item ignorado/.test(w)).length, 0, "personagem/cenário novos sem falhas: " + warns.join(" | "));
assert.equal(errors.length, 0, "sem exceções: " + errors.map((e) => e.stack || e).join("\n"));
assert.ok(globalThis.__renderCalls > 1500, "renderizou frames");
console.log(`SMOKE OK — frames=${globalThis.__renderCalls} chars=${S.chars.size}`);
await app.stop(); fs.rmSync(dir, { recursive: true, force: true });
// 2ª rodada: sem ?test=1 os eventos de teste não podem criar avatares
const { execFileSync } = await import("node:child_process");
const out = execFileSync(process.execPath, ["--import", "./test/stub/register.mjs", "test/smoke-stage.mjs"], { env: { ...process.env, SMOKE_MODE: "nobots" }, encoding: "utf8" });
assert.match(out, /SMOKE NOBOTS OK/); console.log(out.trim());
process.exit(0);
} catch (e) { console.error("SMOKE FALHOU:", e.message); process.exit(1); }
