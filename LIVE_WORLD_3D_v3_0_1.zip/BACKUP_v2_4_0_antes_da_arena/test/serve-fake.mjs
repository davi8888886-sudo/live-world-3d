// Servidor de TESTE com conector SIMULADO (só para testar o painel no navegador). Nunca use em produção.
import { EventEmitter } from "node:events"; import fs from "node:fs"; import os from "node:os"; import path from "node:path";
import { createApp } from "../server.js";
class Fake extends EventEmitter { constructor(u) { super(); this.u = u; } async connect() { if (this.u === "offline") throw new Error("The user is not live"); } async disconnect() {} }
const app = createApp({ port: Number(process.env.PORT || 0), host: "127.0.0.1", adminToken: "segredo", enableTestEvents: true, musicDir: fs.mkdtempSync(path.join(os.tmpdir(), "lw-fake-")), connectorFactory: async (u) => new Fake(u) });
console.log("PORT=" + (await app.start()));
