import test from "node:test";
import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import { LiveManager, friendlyError } from "../lib/live.js";

class Fake extends EventEmitter {
  constructor(script = {}) { super(); this.script = script; this.disconnected = 0; }
  async connect() { if (this.script.fail) throw new Error(this.script.fail); await (this.script.gate ?? null); }
  async disconnect() { this.disconnected++; }
}
const mk = (conns, opts = {}) => { let i = 0; const used = []; const m = new LiveManager({ factory: async () => { const c = conns[Math.min(i++, conns.length - 1)]; used.push(c); return c; }, backoff: [5, 5], flushEveryMs: 1000, ...opts }); m.used = used; return m; };
const statuses = (m) => { const a = []; m.on("status", (s) => a.push(s.status)); return a; };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

test("usuário inválido é rejeitado sem tocar no conector", async () => {
  const m = mk([new Fake()]);
  await assert.rejects(m.connect("!!"), (e) => e.friendly && e.kind === "invalid");
  assert.equal(m.status, "disconnected");
});
test("CONECTADO só depois que connect() confirma", async () => {
  let open; const gate = new Promise((r) => (open = r));
  const m = mk([new Fake({ gate })]); const st = statuses(m);
  const p = m.connect("@fulano");
  await wait(10);
  assert.equal(m.status, "connecting");
  open(); await p;
  assert.deepEqual(st, ["connecting", "connected"]);
});
test("falha na primeira conexão vira erro e não reconecta sozinho", async () => {
  const m = mk([new Fake({ fail: "user is not live" })]);
  await assert.rejects(m.connect("fulano"), (e) => e.kind === "offline");
  await wait(40);
  assert.equal(m.status, "error"); assert.equal(m.used.length, 1);
});
test("queda → reconecta sozinho e volta a CONECTADO", async () => {
  const a = new Fake(), b = new Fake(); const m = mk([a, b]); const st = statuses(m);
  await m.connect("fulano"); a.emit("disconnected");
  await wait(40);
  assert.deepEqual(st, ["connecting", "connected", "reconnecting", "reconnecting", "connected"]);
  assert.equal(m.used.length, 2);
});
test("reconexão esgotada → erro claro", async () => {
  const a = new Fake(); const bad = new Fake({ fail: "timeout" });
  const m = mk([a, bad]); await m.connect("fulano"); a.emit("disconnected");
  await wait(80);
  assert.equal(m.status, "error"); assert.match(m.message, /CONECTAR/);
});
test("desconectar manual cancela reconexão e fecha a conexão", async () => {
  const a = new Fake(); const m = mk([a, new Fake()]);
  await m.connect("fulano"); a.emit("disconnected");
  await m.disconnect(); await wait(30);
  assert.equal(m.status, "disconnected"); assert.equal(m.used.length, 1);
});
test("eventos de conexão descartada são ignorados", async () => {
  const a = new Fake(); const m = mk([a, new Fake()]); const evs = [];
  m.on("event", (e) => evs.push(e));
  await m.connect("fulano"); await m.connect("outro");
  a.emit("chat", { user: { uniqueId: "x" }, comment: "fantasma" });
  assert.equal(evs.length, 0); assert.equal(a.disconnected, 1);
});
test("eventos: entrada única, presente contado uma vez, fim da LIVE", async () => {
  const a = new Fake(); const m = mk([a]); const evs = [];
  m.on("event", (e) => evs.push(e)); await m.connect("fulano");
  const u = { uniqueId: "z", nickname: "Zé" };
  a.emit("member", { user: u }); a.emit("member", { user: u });
  a.emit("gift", { user: u, giftId: 1, giftType: 1, repeatCount: 2, repeatEnd: false, giftDetails: { giftName: "Rose", diamondCount: 1 } });
  a.emit("gift", { user: u, giftId: 1, giftType: 1, repeatCount: 5, repeatEnd: true, giftDetails: { giftName: "Rose", diamondCount: 1 } });
  assert.deepEqual(evs.map((e) => [e.type, e.isNewViewer]), [["member", true], ["member", false], ["gift-progress", false], ["gift", false]]);
  assert.equal(m.roster.stats.gifts, 5);
  a.emit("streamEnd"); assert.equal(m.status, "disconnected");
});
test("friendlyError traduz causas comuns", () => {
  assert.equal(friendlyError(new Error("The requested user isn't hosting a live")).kind, "offline");
  assert.equal(friendlyError(new Error("Sign server 429")).kind, "blocked");
  assert.equal(friendlyError({ code: "CONNECTOR_UNAVAILABLE" }).kind, "unavailable");
});
