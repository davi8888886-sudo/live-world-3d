// Personagens: humanoide procedural (reserva) OU modelos GLB (public/models). Nome flutuante, balão de comentário,
// entrada andando sem "patinar", danças por pose (procedural) ou por clipes (GLB).
import * as THREE from "three";
import { dancePose, walkPose, zeroPose, POSE_KEYS, pickDance } from "./dances.js";
import { STAGE, STAGE_Y } from "./world.js";

const SKIN = [0xf1c9a5, 0xe0ac82, 0xc68863, 0x9b6743, 0x6f4a2f, 0x4a3020];
const HAIR = [0x1b1512, 0x3a2a1e, 0x6b4a2a, 0xa8773a, 0xd8b36a, 0x8e2b1a, 0x2b2b3a, 0xc9c9d6];
const TOP = [0xe94f77, 0x35c6e8, 0xf2b134, 0x7a5af8, 0x2fd08a, 0xf25c2a, 0xf2f2f2, 0x1d1d26, 0xd62e2e];
const BOTTOM = [0x1f2a44, 0x2b2b2b, 0x3b4d7a, 0x5a3d2b, 0x1a1a1a, 0x6b6f80];
const SHOE = [0xf4f4f4, 0x151515, 0xe94f77, 0x35c6e8];
const EYE = [0x3a2a1e, 0x2e5d8a, 0x3c6e47, 0x5a4632];
const STYLES = ["short", "long", "bun", "afro"];
const TAU = Math.PI * 2, OMEGA = (Math.PI * 118) / 60;
const wrapPI = (a) => ((((a + Math.PI) % TAU) + TAU) % TAU) - Math.PI;

export function hash(str) { let h = 2166136261 >>> 0; for (const ch of String(str)) { h ^= ch.codePointAt(0); h = Math.imul(h, 16777619) >>> 0; } return h >>> 0; }
export function makeLook(id) {
  const h = hash(id);
  return { skin: SKIN[h % 6], hair: HAIR[(h >>> 3) % 8], top: TOP[(h >>> 6) % 9], bottom: BOTTOM[(h >>> 9) % 6], shoe: SHOE[(h >>> 12) % 4], style: STYLES[(h >>> 15) % 4], build: (h >>> 18) % 3, jacket: (h >>> 21) % 3 === 0, eye: EYE[(h >>> 24) % 4] };
}

function limb(len, r0, r1, mat) {
  const pts = [[r0 * 0.9, 0], [r0, -len * 0.12], [(r0 + r1) / 2, -len * 0.5], [r1, -len * 0.9], [r1 * 0.75, -len]].map(([r, y]) => new THREE.Vector2(r, y));
  const g = new THREE.Group();
  g.add(new THREE.Mesh(new THREE.LatheGeometry(pts, 14), mat));
  for (const [r, y] of [[r0, 0], [r1 * 0.8, -len]]) { const s = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), mat); s.position.y = y; g.add(s); }
  return g;
}

/** Humanoide procedural: proporções humanas, rosto (olhos, sobrancelhas, nariz, boca, orelhas), cabelo, roupas, mãos e sapatos. */
export function buildProcedural(look) {
  const M = (c, rough = 0.7) => new THREE.MeshStandardMaterial({ color: c, roughness: rough, side: THREE.DoubleSide });
  const skin = M(look.skin, 0.55), top = M(look.top), bottom = M(look.bottom), shoe = M(look.shoe, 0.5), hair = M(look.hair, 0.45);
  const jacket = look.jacket ? M(look.top) : skin, bw = [0.9, 1, 1.12][look.build];
  const root = new THREE.Group(), hips = new THREE.Group(); hips.position.y = 0.93; root.add(hips);
  const pelvis = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12), bottom); pelvis.scale.set(1.15 * bw, 0.8, 0.8); hips.add(pelvis);
  const spine = new THREE.Group(); spine.position.y = 0.05; hips.add(spine);
  const torsoPts = [[0.001, 0], [0.13, 0], [0.15, 0.1], [0.17, 0.28], [0.2, 0.42], [0.19, 0.52], [0.1, 0.58], [0.001, 0.6]].map(([r, y]) => new THREE.Vector2(r * bw, y));
  const torso = new THREE.Mesh(new THREE.LatheGeometry(torsoPts, 18), top); torso.scale.set(1, 0.92, 0.62); spine.add(torso);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.05, 0.1, 10), skin); neck.position.y = 0.58; spine.add(neck);

  const head = new THREE.Group(); head.position.y = 0.6; spine.add(head);
  const skull = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 16), skin); skull.scale.set(0.104, 0.128, 0.115); skull.position.y = 0.1; head.add(skull);
  const face = new THREE.Group(); face.position.y = 0.1; head.add(face);
  for (const sx of [-1, 1]) {
    const white = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 8), M(0xffffff, 0.3)); white.scale.set(1, 0.8, 0.5); white.position.set(sx * 0.042, 0.03, 0.1); face.add(white);
    const iris = new THREE.Mesh(new THREE.CircleGeometry(0.0125, 12), new THREE.MeshBasicMaterial({ color: look.eye })); iris.position.set(sx * 0.042, 0.03, 0.1115); face.add(iris);
    const pupil = new THREE.Mesh(new THREE.CircleGeometry(0.006, 10), new THREE.MeshBasicMaterial({ color: 0x050505 })); pupil.position.set(sx * 0.042, 0.03, 0.1122); face.add(pupil);
    const brow = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.007, 0.008), hair); brow.position.set(sx * 0.042, 0.063, 0.104); brow.rotation.z = -sx * 0.12; face.add(brow);
    const ear = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 6), skin); ear.scale.set(0.5, 1, 0.8); ear.position.set(sx * 0.104, 0, -0.005); face.add(ear);
  }
  const nose = new THREE.Mesh(new THREE.ConeGeometry(0.014, 0.035, 8), skin); nose.rotation.x = Math.PI / 2; nose.position.set(0, -0.012, 0.112); face.add(nose);
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.026, 0.0045, 6, 12, Math.PI), M(0x9e3d4a, 0.5)); mouth.rotation.z = Math.PI; mouth.position.set(0, -0.045, 0.098); face.add(mouth);

  const cap = (r, th, rotX, p, s = [1, 1, 1]) => { const m = new THREE.Mesh(new THREE.SphereGeometry(1, 18, 12, 0, TAU, 0, th), hair); m.scale.set(0.108 * r * s[0], 0.133 * r * s[1], 0.12 * r * s[2]); m.rotation.x = rotX; m.position.set(...p); head.add(m); };
  if (look.style === "afro") cap(1.45, Math.PI * 0.64, -0.5, [0, 0.12, -0.02]);
  else cap(1.05, Math.PI * 0.58, -0.45, [0, 0.1, -0.003]);
  if (look.style === "long") { const back = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 10), hair); back.scale.set(0.115, 0.23, 0.1); back.position.set(0, -0.02, -0.05); head.add(back); }
  if (look.style === "bun") { const bun = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), hair); bun.position.set(0, 0.25, -0.06); head.add(bun); }

  const j = { hips, spine, head };
  for (const [side, sx] of [["L", 1], ["R", -1]]) {
    const arm = new THREE.Group(); arm.position.set(sx * 0.19 * bw, 0.46, 0); spine.add(arm);
    arm.add(limb(0.3, 0.055, 0.045, top));
    const fore = new THREE.Group(); fore.position.y = -0.3; arm.add(fore); fore.add(limb(0.27, 0.042, 0.034, jacket));
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.04, 10, 8), skin); hand.scale.set(0.9, 1.25, 0.55); hand.position.y = -0.31; fore.add(hand);
    const thigh = new THREE.Group(); thigh.position.set(sx * 0.09 * bw, -0.03, 0); hips.add(thigh); thigh.add(limb(0.45, 0.09, 0.065, bottom));
    const shin = new THREE.Group(); shin.position.y = -0.45; thigh.add(shin); shin.add(limb(0.45, 0.062, 0.045, bottom));
    const foot = new THREE.Mesh(new THREE.SphereGeometry(1, 10, 8), shoe); foot.scale.set(0.05, 0.035, 0.11); foot.position.set(0, -0.46, 0.04); shin.add(foot);
    j["arm" + side] = arm; j["fore" + side] = fore; j["thigh" + side] = thigh; j["shin" + side] = shin;
  }
  root.traverse((o) => { if (o.isMesh) o.castShadow = true; });
  return { root, joints: j, mixer: null, clips: [], height: 1.8 };
}

export function applyPose(j, P) {
  j.hips.position.y = 0.93 + P.hy; j.hips.rotation.set(0, P.hry, P.hrz);
  j.spine.rotation.set(P.sx, 0, P.sz); j.head.rotation.set(P.hdx, 0, P.hdz);
  j.armL.rotation.set(-P.alx, 0, P.alz); j.armR.rotation.set(-P.arx, 0, -P.arz);
  j.foreL.rotation.set(-P.flx, 0, 0); j.foreR.rotation.set(-P.frx, 0, 0);
  j.thighL.rotation.set(-P.tlx, 0, P.tlz); j.thighR.rotation.set(-P.trx, 0, -P.trz);
  j.shinL.rotation.set(P.slx, 0, 0); j.shinR.rotation.set(P.srx, 0, 0);
}

/** Prepara um GLB já clonado (SkeletonUtils.clone) para uso: altura 1,75 m, pés no chão, mixer de animação. */
export function prepareGLB(clonedScene, clips) {
  const box = new THREE.Box3().setFromObject(clonedScene), h = Math.max(0.01, box.max.y - box.min.y), s = 1.75 / h;
  const wrap = new THREE.Group(); clonedScene.scale.multiplyScalar(s); clonedScene.position.y = -box.min.y * s; wrap.add(clonedScene);
  clonedScene.traverse((o) => { if (o.isMesh) { o.castShadow = true; o.frustumCulled = false; } });
  return { root: wrap, joints: null, mixer: new THREE.AnimationMixer(clonedScene), clips: clips || [], height: 1.75 };
}
const CLIP_WORDS = { walk: ["walk"], idle: ["idle", "stand"], dance: ["dance", "samba", "hip", "groove", "swing", "rumba", "salsa"], celebrate: ["celebr", "victory", "cheer", "jump", "clap", "win"], wave: ["wave", "greet", "hello"], spin: ["spin", "twirl", "turn"] };
function pickClip(clips, kind, i = 0) {
  const names = clips.map((c) => c.name.toLowerCase());
  for (const w of CLIP_WORDS[kind] || [kind]) { const hits = names.map((n, k) => (n.includes(w) ? k : -1)).filter((k) => k >= 0); if (hits.length) return clips[hits[i % hits.length]]; }
  return null;
}

function makeLabel(name) {
  const c = document.createElement("canvas"); c.width = 512; c.height = 200;
  const x = c.getContext("2d"), tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false }));
  sprite.scale.set(1.7, 0.664, 1); sprite.renderOrder = 10;
  const draw = (n, bubble) => {
    x.clearRect(0, 0, 512, 200);
    x.font = "700 40px system-ui, sans-serif"; let fs = 40; while (x.measureText(n).width > 430 && fs > 20) { fs -= 2; x.font = `700 ${fs}px system-ui, sans-serif`; }
    const w = Math.min(480, x.measureText(n).width + 50);
    x.fillStyle = "rgba(8,12,26,.82)"; x.beginPath(); x.roundRect(256 - w / 2, 120, w, 66, 33); x.fill();
    x.strokeStyle = "#6ce2d2"; x.lineWidth = 3; x.stroke();
    x.fillStyle = "#fff"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText(n, 256, 154);
    if (bubble) {
      x.font = "600 30px system-ui, sans-serif"; let t = bubble; while (x.measureText(t).width > 440 && t.length > 4) t = t.slice(0, -2);
      if (t !== bubble) t += "…";
      const bw = Math.min(490, x.measureText(t).width + 40);
      x.fillStyle = "rgba(255,255,255,.95)"; x.beginPath(); x.roundRect(256 - bw / 2, 20, bw, 80, 22); x.fill();
      x.fillStyle = "#111"; x.fillText(t, 256, 60);
    }
    tex.needsUpdate = true;
  };
  draw(name);
  return { sprite, draw, dispose() { tex.dispose(); sprite.material.dispose(); } };
}

export class Character {
  constructor(viewer, model) {
    this.id = viewer.id; this.name = viewer.name; this.model = model; this.joints = model.joints; this.mixer = model.mixer; this.clips = model.clips;
    this.group = new THREE.Group(); this.group.add(model.root);
    this.label = makeLabel(viewer.name); this.label.sprite.position.y = model.height + 0.37; this.group.add(this.label.sprite);
    this.state = "entering"; this.done = false; this.slot = -1; this.target = new THREE.Vector3(); this.exit = new THREE.Vector3();
    this.cur = zeroPose(); this.walkPhase = Math.random() * TAU; this.phase = Math.random() * 1.2; this.yaw = 0; this.yawTarget = 0;
    this.dance = pickDance(this.id, 0); this.danceIdx = 0; this.nextDance = 12 + Math.random() * 12;
    this.special = null; this.specialLeft = 0; this.bubbleLeft = 0; this.lastActive = performance.now(); this.lastLike = 0; this.age = 0;
    this.clipAction = null; this.clipKey = "";
    this.hasWalk = !this.mixer || !!pickClip(this.clips, "walk");
  }
  get pos() { return this.group.position; }
  place(slotPos, fromSide) {
    this.target.set(slotPos[0], STAGE_Y, slotPos[1]);
    if (this.hasWalk) this.pos.set(fromSide * (STAGE.w / 2 + 2.6), STAGE_Y, slotPos[1] + (Math.random() - 0.5) * 0.6);
    else { this.pos.copy(this.target); this.state = "dancing"; this.group.scale.setScalar(0.01); }
    this.exit.set(fromSide * (STAGE.w / 2 + 3), STAGE_Y, slotPos[1]);
  }
  moveTo(slotPos) { this.target.set(slotPos[0], STAGE_Y, slotPos[1]); if (this.hasWalk) this.state = "entering"; else this.pos.copy(this.target); }
  leave() { this.state = "leaving"; this.exit.x = this.pos.x >= 0 ? STAGE.w / 2 + 3 : -(STAGE.w / 2 + 3); this.exit.z = this.pos.z; }
  setName(n) { if (n !== this.name) { this.name = n; this.label.draw(n, this.bubbleLeft > 0 ? this.bubble : null); } }
  say(text) { this.bubble = text; this.bubbleLeft = 4.5; this.label.draw(this.name, text); this.lastActive = performance.now(); }
  triggerSpecial(id, seconds) { this.special = id; this.specialLeft = seconds; this.lastActive = performance.now(); }
  #wantClip(kind, i = 0) {
    if (!this.mixer) return;
    const key = kind + i; if (key === this.clipKey) return; this.clipKey = key;
    const clip = pickClip(this.clips, kind, i) || pickClip(this.clips, "dance", i) || this.clips[0]; if (!clip) return;
    const next = this.mixer.clipAction(clip); next.reset().fadeIn(0.35).play();
    if (this.clipAction && this.clipAction !== next) this.clipAction.fadeOut(0.35);
    this.clipAction = next;
  }
  update(dt, t, audio, override) {
    this.age += dt;
    if (this.group.scale.x < 1) this.group.scale.setScalar(Math.min(1, this.group.scale.x + dt * 2.2 + 0.001));
    if (this.bubbleLeft > 0 && (this.bubbleLeft -= dt) <= 0) this.label.draw(this.name);
    let target;
    if (this.state === "entering" || this.state === "leaving") {
      const to = this.state === "entering" ? this.target : this.exit;
      const dx = to.x - this.pos.x, dz = to.z - this.pos.z, d = Math.hypot(dx, dz), step = Math.min(d, 1.7 * dt);
      if (d > 0.001) { this.pos.x += (dx / d) * step; this.pos.z += (dz / d) * step; this.walkPhase += (step / 1.4) * TAU; this.yawTarget = Math.atan2(dx, dz); }
      if (d < 0.05) { if (this.state === "entering") this.state = "dancing"; else this.done = true; }
      target = walkPose(this.walkPhase); this.#wantClip("walk");
    } else {
      if (this.specialLeft > 0 && (this.specialLeft -= dt) <= 0) this.special = null;
      if ((this.nextDance -= dt) <= 0) { this.danceIdx++; this.dance = pickDance(this.id, this.danceIdx); this.nextDance = 12 + Math.random() * 12; }
      const id = this.special || (override && override !== "auto" ? override : this.dance);
      this.yawTarget = id === "hiphop" ? 0.25 : 0;
      target = dancePose(id, this.phase + t * OMEGA, audio.energy);
      this.#wantClip(this.special ? this.special : "dance", this.danceIdx);
    }
    this.yaw += wrapPI(this.yawTarget - this.yaw) * (1 - Math.exp(-dt * 8)); this.group.rotation.y = this.yaw;
    if (this.mixer) { this.mixer.update(dt); return; }
    const k = 1 - Math.exp(-dt * (this.state === "dancing" ? 9 : 14));
    for (const key of POSE_KEYS) this.cur[key] += (key === "hry" ? wrapPI(target[key] - this.cur[key]) : target[key] - this.cur[key]) * k;
    const out = { ...this.cur };
    if (this.state === "dancing") { out.hy += 0.045 * audio.pulse; out.sx += 0.05 * audio.pulse; }
    applyPose(this.joints, out);
  }
  dispose() {
    this.group.removeFromParent(); this.label.dispose();
    this.group.traverse((o) => { if (o.isMesh) { o.geometry?.dispose(); (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m?.dispose()); } });
  }
}
