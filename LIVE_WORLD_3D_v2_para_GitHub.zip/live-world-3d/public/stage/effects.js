// Partículas (confete, corações, fogos) e ondas de choque. Um único Points reaproveitado (sem alocar por frame).
import * as THREE from "three";
const PALETTE = [[1, 0.25, 0.6], [0.2, 0.85, 1], [1, 0.85, 0.25], [0.65, 0.45, 1], [0.3, 1, 0.6], [1, 1, 1]];

export class Effects {
  constructor(scene, max = 500) {
    this.max = max; this.cursor = 0;
    this.pos = new Float32Array(max * 3).fill(0); this.col = new Float32Array(max * 3);
    this.vel = new Float32Array(max * 3); this.life = new Float32Array(max); this.grav = new Float32Array(max);
    for (let i = 0; i < max; i++) this.pos[i * 3 + 1] = -999;
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(this.pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(this.col, 3));
    this.points = new THREE.Points(g, new THREE.PointsMaterial({ size: 0.16, vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    this.points.frustumCulled = false; scene.add(this.points);
    this.rings = [];
    for (let i = 0; i < 4; i++) {
      const m = new THREE.Mesh(new THREE.RingGeometry(0.35, 0.45, 48), new THREE.MeshBasicMaterial({ color: 0x35d6ff, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
      m.rotation.x = -Math.PI / 2; m.visible = false; scene.add(m); this.rings.push({ m, age: 9 });
    }
  }
  emit(x, y, z, vx, vy, vz, c, life, grav) {
    const i = this.cursor++ % this.max, k = i * 3;
    this.pos[k] = x; this.pos[k + 1] = y; this.pos[k + 2] = z;
    this.vel[k] = vx; this.vel[k + 1] = vy; this.vel[k + 2] = vz;
    this.col[k] = c[0]; this.col[k + 1] = c[1]; this.col[k + 2] = c[2];
    this.life[i] = life; this.grav[i] = grav;
  }
  burst(p, n, speed, { color = null, up = 0, grav = 4, life = 1.4, dy = 0 } = {}) {
    for (let i = 0; i < n; i++) {
      const th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1), s = speed * (0.4 + Math.random() * 0.6);
      this.emit(p.x, p.y + dy, p.z, Math.sin(ph) * Math.cos(th) * s, Math.cos(ph) * s + up, Math.sin(ph) * Math.sin(th) * s, color || PALETTE[(Math.random() * PALETTE.length) | 0], life * (0.7 + Math.random() * 0.6), grav);
    }
  }
  ring(p, color = 0x35d6ff) {
    const r = this.rings.reduce((a, b) => (a.age > b.age ? a : b));
    r.age = 0; r.m.position.set(p.x, p.y + 0.05, p.z); r.m.material.color.setHex(color); r.m.visible = true;
  }
  /** Efeito de presente, a partir da posição do personagem. */
  effect(name, p) {
    switch (name) {
      case "hearts": this.burst(p, 26, 0.9, { color: [1, 0.3, 0.6], up: 1.6, grav: -0.2, life: 2, dy: 1.6 }); break;
      case "rings": this.ring(p); setTimeout(() => this.ring(p, 0xff2d95), 220); this.burst(p, 30, 2.4, { dy: 1.2, up: 1.5 }); break;
      case "fireworks":
        for (let i = 0; i < 3; i++) setTimeout(() => this.burst({ x: p.x + (i - 1) * 1.7, y: p.y, z: p.z - 0.5 }, 70, 5, { dy: 3.6 + i * 0.4, grav: 3, life: 1.6 }), i * 280);
        this.ring(p); break;
      case "burst": this.burst(p, 50, 3.5, { dy: 1.2, up: 1 }); break;
      default: this.burst(p, 70, 3, { dy: 3, up: 2, grav: 4.5, life: 1.8 }); // confetti
    }
  }
  update(dt) {
    const f = Math.pow(0.35, dt);
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      const k = i * 3; this.life[i] -= dt;
      if (this.life[i] <= 0) { this.pos[k + 1] = -999; continue; }
      this.vel[k + 1] -= this.grav[i] * dt;
      this.pos[k] += this.vel[k] * dt; this.pos[k + 1] += this.vel[k + 1] * dt; this.pos[k + 2] += this.vel[k + 2] * dt;
      this.col[k] *= f; this.col[k + 1] *= f; this.col[k + 2] *= f;
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    this.points.geometry.attributes.color.needsUpdate = true;
    for (const r of this.rings) {
      if (r.age > 1) { r.m.visible = false; continue; }
      r.age += dt; const s = 1 + r.age * 9; r.m.scale.set(s, s, s); r.m.material.opacity = Math.max(0, 0.8 * (1 - r.age));
    }
  }
}
