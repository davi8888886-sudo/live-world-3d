// Poses de dança como funções puras (sem THREE): fáceis de testar e de ajustar.
// Ângulos em radianos. Chaves: hy=altura do quadril, hrz/hry=quadril, sx/sz=tronco, hdx/hdz=cabeça,
// alx/alz,arx/arz=braço esq./dir. (x=para frente, z=para o lado), flx/frx=cotovelo,
// tlx/tlz,trx/trz=coxa, slx/srx=joelho (dobra).
export const POSE_KEYS = ["hy", "hrz", "hry", "sx", "sz", "hdx", "hdz", "alx", "alz", "arx", "arz", "flx", "frx", "tlx", "tlz", "trx", "trz", "slx", "srx"];
export const zeroPose = () => Object.fromEntries(POSE_KEYS.map((k) => [k, 0]));
export const DANCE_IDS = ["groove", "bounce", "samba", "hiphop", "passinho"];
export const SPECIAL_IDS = ["celebrate", "spin", "wave"];
const s = Math.sin, c = Math.cos, PI = Math.PI;
const bend = (b) => ({ hy: -0.07 * b, tlx: 0.28 * b, trx: 0.28 * b, slx: 0.55 * b, srx: 0.55 * b });

// p = fase (2π = 2 batidas); e = energia 0..1 (amplitude)
const D = {
  idle: (p) => ({ sx: 0.02 * s(p / 2), hdx: 0.02 * s(p / 3), alz: 0.12, arz: 0.12, flx: 0.15, frx: 0.15 }),
  groove: (p, e) => { const a = 0.6 + 0.4 * e, b = (0.5 + 0.5 * s(2 * p)) * a; return { ...bend(b), hrz: 0.07 * s(p) * a, hry: 0.3 * s(p) * a, sz: 0.05 * s(p), hdz: 0.08 * s(p + 1), alx: 0.25 * s(p), alz: 0.5 + 0.3 * s(p) * a, arx: 0.25 * s(p + PI), arz: 0.5 + 0.3 * s(p + PI) * a, flx: 0.7 + 0.3 * s(2 * p), frx: 0.7 + 0.3 * s(2 * p + 1) }; },
  bounce: (p, e) => { const a = 0.7 + 0.3 * e, b = (0.5 + 0.5 * s(2 * p)) * 1.3 * a; return { ...bend(b), sx: 0.08 * s(2 * p), alz: 1.0 + 0.5 * s(2 * p) * a, arz: 1.0 + 0.5 * s(2 * p) * a, flx: 0.4, frx: 0.4, hdx: 0.1 * s(2 * p) }; },
  samba: (p, e) => { const a = 0.6 + 0.4 * e; return { hy: -0.03 + 0.02 * s(4 * p), hrz: 0.17 * s(p) * a, hry: 0.2 * s(p + 1) * a, sz: -0.1 * s(p) * a, tlx: 0.5 * s(p) * a, trx: -0.5 * s(p) * a, slx: Math.max(0, -s(p)) * 0.7 * a, srx: Math.max(0, s(p)) * 0.7 * a, alx: -0.5 * s(p) * a, arx: 0.5 * s(p) * a, alz: 0.35, arz: 0.35, flx: 0.5, frx: 0.5, hdz: 0.1 * s(p) }; },
  hiphop: (p, e) => { const a = 0.7 + 0.3 * e, b = (0.5 + 0.5 * s(2 * p)) * 1.2 * a, k = 0.5 + 0.5 * s(p); return { ...bend(b), sx: 0.18 * s(2 * p) * a + 0.08, hdx: 0.15 * s(2 * p), alz: 0.4 + 0.9 * k * a, arz: 0.4 + 0.9 * (1 - k) * a, flx: 1.0 - 0.5 * k, frx: 0.5 + 0.5 * k, hry: 0.2 * s(p) }; },
  passinho: (p, e) => { const a = 0.6 + 0.4 * e; return { hy: -0.04 + 0.03 * Math.abs(s(2 * p)), hrz: 0.1 * s(p), tlz: 0.28 * Math.max(0, s(p)) * a, trz: 0.28 * Math.max(0, -s(p)) * a, slx: 0.3 * Math.max(0, s(p)), srx: 0.3 * Math.max(0, -s(p)), alx: 0.7 * s(p) * a, arx: -0.7 * s(p) * a, alz: 0.25, arz: 0.25, flx: 0.9, frx: 0.9, sz: -0.06 * s(p), hdz: 0.08 * s(p) }; },
  wave: (p) => ({ hrz: 0.04 * s(p), sz: 0.03 * s(p), arz: 2.5 + 0.1 * s(2 * p), arx: 0.1, frx: 0.35 + 0.6 * s(6 * p), alz: 0.15, flx: 0.3, hdz: 0.12, hdx: -0.05 }),
  celebrate: (p, e) => { const j = Math.abs(s(1.5 * p)), a = 0.8 + 0.2 * e; return { hy: 0.14 * j * a, ...bend(0.5 * (1 - j)), alz: 2.7 + 0.2 * s(4 * p), arz: 2.7 + 0.2 * s(4 * p + 1), alx: -0.1, arx: -0.1, flx: 0.15, frx: 0.15, hdx: -0.15, sx: -0.05 }; },
  spin: (p) => ({ hry: p * 0.6, hy: 0.02 * Math.abs(s(2 * p)), alz: 1.45, arz: 1.45, flx: 0.15, frx: 0.15, sx: 0.04, hdx: -0.05 }),
};
export function dancePose(id, p, e = 0.5) {
  const f = D[id] || D.groove;
  return { ...zeroPose(), ...f(p, Math.min(1, Math.max(0, e))) };
}
export function walkPose(phase) {
  const k = s(phase);
  return { ...zeroPose(), hy: -0.015 + 0.025 * Math.abs(c(phase)), tlx: 0.55 * k, trx: -0.55 * k, slx: 0.1 + 0.6 * Math.max(0, -s(phase + 0.9)), srx: 0.1 + 0.6 * Math.max(0, s(phase + 0.9)), alx: -0.45 * k, arx: 0.45 * k, alz: 0.1, arz: 0.1, flx: 0.25, frx: 0.25, sx: 0.04, hry: 0.06 * k };
}
export function pickDance(id, i) { const n = (Number(String(id).split("").reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 7)) + i) % DANCE_IDS.length; return DANCE_IDS[n]; }
