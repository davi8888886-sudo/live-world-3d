// Cenário de show: palco, telão LED, treliça com moving heads e lasers, plateia, névoa.
import * as THREE from "three";
export const STAGE_Y = 0.4;
export const STAGE = { w: 9, d: 6.2 };

function canvasTex(w, h) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d"); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return { c, x, t, w, h };
}
const rng = (seed) => () => ((seed = (seed * 16807) % 2147483647) / 2147483647);

/** Desenha o telão principal. s = {spectrum, hasAudio, title, username, status, viewers, gifts, likes, ticker, alert, now} */
export function drawLed(L, s, t) {
  const { x, w, h } = L, hue = (t * 12) % 360;
  const g = x.createLinearGradient(0, 0, w, h);
  g.addColorStop(0, `hsl(${hue},70%,13%)`); g.addColorStop(1, `hsl(${(hue + 80) % 360},70%,7%)`);
  x.fillStyle = g; x.fillRect(0, 0, w, h);
  const n = s.spectrum.length, bw = w / n;
  for (let i = 0; i < n; i++) {
    const v = s.hasAudio ? Math.max(0.04, s.spectrum[i]) : 0.1 + 0.06 * Math.sin(t * 2 + i * 0.6);
    x.fillStyle = `hsl(${(hue + i * 9) % 360},90%,58%)`;
    x.fillRect(i * bw + 4, h - v * h * 0.5, bw - 8, v * h * 0.5);
  }
  x.shadowColor = "#000"; x.shadowBlur = 8; x.fillStyle = "#fff"; x.textBaseline = "alphabetic";
  x.font = "900 54px system-ui, sans-serif"; x.textAlign = "left"; x.fillText("LIVE WORLD 3D", 34, 78);
  x.font = "600 28px system-ui, sans-serif"; x.fillStyle = "#9ff5e6";
  x.fillText(s.username ? `@${s.username} · ${s.status}` : s.status, 36, 118);
  x.fillStyle = "#fff"; x.font = "700 30px system-ui, sans-serif"; x.textAlign = "right";
  x.fillText(`👥 ${s.viewers}   🎁 ${s.gifts}   ❤ ${s.likes}`, w - 34, 70);
  x.textAlign = "left"; x.font = "600 26px system-ui, sans-serif";
  s.ticker.slice(-3).forEach((line, i) => { x.fillStyle = i === s.ticker.slice(-3).length - 1 ? "#ffffff" : "#b8c2e0"; x.fillText(line, 36, 168 + i * 36); });
  if (s.alert && s.now < s.alert.until) {
    const k = 1 + 0.04 * Math.sin(t * 14);
    x.save(); x.translate(w / 2, h * 0.42); x.scale(k, k);
    x.fillStyle = "rgba(0,0,0,.6)"; x.fillRect(-w * 0.45, -70, w * 0.9, 140);
    x.textAlign = "center"; x.fillStyle = `hsl(${(t * 200) % 360},100%,70%)`; x.font = "900 54px system-ui, sans-serif";
    x.fillText("🎁 " + s.alert.text.slice(0, 34), 0, 14); x.font = "600 28px system-ui, sans-serif"; x.fillStyle = "#fff"; x.fillText(s.alert.sub || "", 0, 56);
    x.restore();
  }
  x.shadowBlur = 0; L.t.needsUpdate = true;
}

export function buildWorld(scene, q) {
  const upd = [];
  scene.background = new THREE.Color(0x04050c);
  scene.fog = new THREE.FogExp2(0x05060f, 0.03);
  scene.add(new THREE.HemisphereLight(0x8fa6ff, 0x1b1033, 0.9));
  const key = new THREE.DirectionalLight(0xffffff, 1.4); key.position.set(2, 9, 10); key.target.position.set(0, 1, 0);
  scene.add(key, key.target);
  if (q >= 2) {
    key.castShadow = true; key.shadow.mapSize.set(1024, 1024);
    Object.assign(key.shadow.camera, { left: -6, right: 6, top: 6, bottom: -4, near: 1, far: 30 }); key.shadow.bias = -0.0005;
  }
  const washes = [0xff2d95, 0x35d6ff, 0xa66bff].map((c, i) => { const l = new THREE.PointLight(c, q ? 40 : 22, 16, 2); l.position.set((i - 1) * 3.6, 4.8, -1.2); scene.add(l); return l; });

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.MeshStandardMaterial({ color: 0x07080f, roughness: 0.55, metalness: 0.3 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

  const tile = canvasTex(128, 128);
  tile.x.fillStyle = "#0a0c18"; tile.x.fillRect(0, 0, 128, 128);
  tile.x.strokeStyle = "#5b6cff"; tile.x.lineWidth = 3; tile.x.strokeRect(0, 0, 128, 128);
  tile.x.strokeStyle = "#1b2040"; tile.x.lineWidth = 1; tile.x.beginPath(); tile.x.moveTo(64, 0); tile.x.lineTo(64, 128); tile.x.moveTo(0, 64); tile.x.lineTo(128, 64); tile.x.stroke();
  tile.t.wrapS = tile.t.wrapT = THREE.RepeatWrapping; tile.t.repeat.set(STAGE.w * 2, STAGE.d * 2); tile.t.needsUpdate = true;
  const topMat = new THREE.MeshStandardMaterial({ map: tile.t, emissiveMap: tile.t, emissive: 0x6a7bff, emissiveIntensity: 0.45, roughness: 0.35, metalness: 0.5 });
  const sideMat = new THREE.MeshStandardMaterial({ color: 0x0b0d1a, roughness: 0.5, metalness: 0.6 });
  const stage = new THREE.Mesh(new THREE.BoxGeometry(STAGE.w, STAGE_Y, STAGE.d), [sideMat, sideMat, topMat, sideMat, sideMat, sideMat]);
  stage.position.y = STAGE_Y / 2; stage.receiveShadow = true; scene.add(stage);
  const trim = new THREE.MeshBasicMaterial({ color: 0xff2d95 });
  for (const [w, d, px, pz] of [[STAGE.w + 0.1, 0.06, 0, STAGE.d / 2 + 0.03], [0.06, STAGE.d, -(STAGE.w / 2 + 0.03), 0], [0.06, STAGE.d, STAGE.w / 2 + 0.03, 0]]) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.07, d), trim); m.position.set(px, STAGE_Y - 0.03, pz); scene.add(m);
  }

  // Telão principal + moldura
  const led = canvasTex(960, 440);
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 3.94), new THREE.MeshBasicMaterial({ map: led.t, toneMapped: false }));
  wall.position.set(0, STAGE_Y + 3.1, -3.0); scene.add(wall);
  const frame = new THREE.Mesh(new THREE.BoxGeometry(8.8, 4.14, 0.12), new THREE.MeshStandardMaterial({ color: 0x0d0f1d, metalness: 0.7, roughness: 0.4 }));
  frame.position.set(0, STAGE_Y + 3.1, -3.07); scene.add(frame);
  // Torres laterais (equalizador)
  const side = canvasTex(128, 384);
  const towerMat = new THREE.MeshBasicMaterial({ map: side.t, toneMapped: false });
  for (const sx of [-1, 1]) {
    const tw = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 3.9), towerMat); tw.position.set(sx * 5.3, 2.4, -2.2); tw.rotation.y = -sx * 0.28; scene.add(tw);
    const fr = new THREE.Mesh(new THREE.BoxGeometry(1.4, 4.0, 0.1), frame.material); fr.position.set(sx * 5.3, 2.4, -2.27); fr.rotation.y = -sx * 0.28; scene.add(fr);
  }

  // Treliça + moving heads
  const metal = new THREE.MeshStandardMaterial({ color: 0x1a1d2e, metalness: 0.8, roughness: 0.35 });
  for (const z of [-1.1, 0.7]) { const b = new THREE.Mesh(new THREE.BoxGeometry(10, 0.12, 0.12), metal); b.position.set(0, 6.3, z); scene.add(b); }
  for (const px of [-5, 5]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.14, 6.3, 0.14), metal); p.position.set(px, 3.15, -0.2); scene.add(p); }
  const heads = [];
  const beamGeo = new THREE.ConeGeometry(0.85, 5.8, 20, 1, true); beamGeo.translate(0, -2.9, 0);
  const nHeads = q ? 8 : 5;
  for (let i = 0; i < nHeads; i++) {
    const pivot = new THREE.Group(); pivot.position.set(-4.2 + (8.4 * i) / (nHeads - 1), 6.15, -0.2);
    pivot.add(new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.1, 0.34, 10), metal));
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    pivot.add(new THREE.Mesh(beamGeo, mat)); scene.add(pivot); heads.push({ pivot, mat, i });
  }
  const lasers = [];
  if (q >= 1) for (let i = 0; i < 6; i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.018, 11, 0.018).translate(0, -5.5, 0), new THREE.MeshBasicMaterial({ color: i % 2 ? 0x2cff9a : 0x35d6ff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }));
    m.position.set(-2.5 + i, 6.0, -1.8); scene.add(m); lasers.push(m);
  }

  // Plateia (silhuetas escuras) com luzes de celular
  const R = rng(7), N = q ? 90 : 48;
  const bodies = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.2, 0.55, 2, 6), new THREE.MeshStandardMaterial({ color: 0x090b14, roughness: 0.9 }), N);
  const headsI = new THREE.InstancedMesh(new THREE.SphereGeometry(0.14, 8, 6), bodies.material, N);
  const crowd = [];
  for (let i = 0; i < N; i++) crowd.push({ x: (R() - 0.5) * 15, z: 5.6 + R() * 5.4, ph: R() * 6.28 });
  scene.add(bodies, headsI);
  const phones = new Float32Array(Math.floor(N * 0.4) * 3);
  crowd.slice(0, phones.length / 3).forEach((c, i) => { phones[i * 3] = c.x + 0.25; phones[i * 3 + 1] = 2.1; phones[i * 3 + 2] = c.z; });
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(phones, 3));
  const phoneMat = new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.16, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
  scene.add(new THREE.Points(pg, phoneMat));
  const dummy = new THREE.Object3D();

  // Névoa
  let haze = null;
  if (q >= 1) {
    const sp = canvasTex(64, 64); const gr = sp.x.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, "rgba(255,255,255,.9)"); gr.addColorStop(1, "rgba(255,255,255,0)"); sp.x.fillStyle = gr; sp.x.fillRect(0, 0, 64, 64); sp.t.needsUpdate = true;
    const hp = new Float32Array(120 * 3); for (let i = 0; i < 120; i++) { hp[i * 3] = (R() - 0.5) * 16; hp[i * 3 + 1] = 0.5 + R() * 5; hp[i * 3 + 2] = -3 + R() * 11; }
    const hg = new THREE.BufferGeometry(); hg.setAttribute("position", new THREE.BufferAttribute(hp, 3));
    haze = new THREE.Points(hg, new THREE.PointsMaterial({ map: sp.t, color: 0x6677ff, size: 2.6, transparent: true, opacity: 0.07, depthWrite: false, blending: THREE.AdditiveBlending }));
    scene.add(haze);
  }
  const col = new THREE.Color();

  function update(t, dt, a) {
    trim.color.setHSL((t * 0.1) % 1, 1, 0.55);
    washes.forEach((l, i) => { l.intensity = (q ? 40 : 22) * (0.75 + 0.7 * a.pulse + 0.15 * Math.sin(t * 2 + i)); });
    for (const h of heads) {
      h.pivot.rotation.x = Math.sin(t * 0.7 + h.i * 0.8) * 0.55 + a.pulse * 0.08;
      h.pivot.rotation.z = Math.cos(t * 0.5 + h.i * 1.3) * 0.7;
      h.mat.color.setHSL((t * 0.05 + h.i * 0.12) % 1, 1, 0.6);
      h.mat.opacity = 0.05 + 0.1 * (0.4 + a.energy) + 0.12 * a.pulse;
    }
    lasers.forEach((m, i) => { m.rotation.z = Math.sin(t * 0.9 + i) * 0.9; m.rotation.x = Math.cos(t * 0.6 + i * 1.7) * 0.5; m.material.opacity = 0.25 + 0.5 * a.pulse; });
    const bob = 0.03 + 0.06 * a.energy;
    for (let i = 0; i < N; i++) {
      const c = crowd[i], y = Math.abs(Math.sin(t * 3 + c.ph)) * bob + a.pulse * 0.05;
      dummy.position.set(c.x, 0.475 + y, c.z); dummy.rotation.set(0, 0, Math.sin(t + c.ph) * 0.04); dummy.updateMatrix(); bodies.setMatrixAt(i, dummy.matrix);
      dummy.position.set(c.x, 1.15 + y, c.z); dummy.updateMatrix(); headsI.setMatrixAt(i, dummy.matrix);
    }
    bodies.instanceMatrix.needsUpdate = true; headsI.instanceMatrix.needsUpdate = true;
    phoneMat.opacity = 0.55 + 0.35 * Math.sin(t * 7);
    if (haze) haze.rotation.y = t * 0.01;
    // torres laterais
    const x = side.x; x.fillStyle = "#05060c"; x.fillRect(0, 0, 128, 384);
    for (let i = 0; i < 12; i++) {
      const v = a.hasAudio ? a.spectrum[i * 2] || 0 : 0.35 + 0.3 * Math.sin(t * 2.2 + i * 0.7);
      col.setHSL(((t * 0.05) + i * 0.04) % 1, 0.9, 0.55); x.fillStyle = `#${col.getHexString()}`;
      x.fillRect(8, 384 - (i + 1) * 31, Math.max(6, 112 * Math.min(1, v * 1.4)), 24);
    }
    side.t.needsUpdate = true;
  }
  return { update, led, drawLed: (s, t) => drawLed(led, s, t) };
}
