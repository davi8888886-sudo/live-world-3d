// Câmera cinematográfica: automática (plano aberto ↔ close em quem entra/manda presente), aberta ou manual (arrastar/pinçar).
// Nunca atravessa objetos: limites de área, altura mínima sobre a plateia e distância mínima dos personagens.
import * as THREE from "three";
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export class Director {
  constructor(camera) {
    this.cam = camera; this.mode = "auto"; this.t = 0; this.aspect = 9 / 16;
    this.shot = { type: "wide", until: 3 }; this.queue = [];
    this.pos = new THREE.Vector3(0, 3.4, 14); this.look = new THREE.Vector3(0, 2.6, 0);
    this.dPos = new THREE.Vector3(); this.dLook = new THREE.Vector3();
    this.orbit = { theta: 0, phi: 1.3, r: 11 };
  }
  setAspect(a) { this.aspect = a; this.cam.fov = a < 1 ? 50 : 40; this.cam.aspect = a; this.cam.updateProjectionMatrix(); }
  setMode(m) { this.mode = m; this.queue.length = 0; this.shot = { type: "wide", until: this.t + 2 }; }
  /** Pede um close. gift tem prioridade sobre entrada. */
  cut(char, seconds, kind) {
    const s = { type: "focus", target: char, until: 0, dur: seconds, kind };
    if (kind === "gift") { this.queue = this.queue.filter((q) => q.kind === "gift"); this.shot = { ...s, until: this.t + seconds }; }
    else if (this.queue.length < 2 && this.shot.kind !== "gift") this.queue.push(s);
  }
  drag(dx, dy) { this.mode = "manual"; this.orbit.theta -= dx * 0.008; this.orbit.phi = clamp(this.orbit.phi - dy * 0.006, 0.25, 1.45); }
  zoom(f) { this.mode = "manual"; this.orbit.r = clamp(this.orbit.r * f, 4, 20); }
  wideFit() {
    const half = 3.9, a = Math.min(this.aspect, 1.8), d = half / (Math.tan((this.cam.fov * Math.PI) / 360) * a);
    return clamp(d, 9, 20);
  }
  update(dt, chars) {
    this.t += dt;
    if (this.mode === "manual") {
      const o = this.orbit; this.dLook.set(0, 2, 0);
      this.dPos.set(Math.sin(o.phi) * Math.sin(o.theta) * o.r, 2 + Math.cos(o.phi) * o.r, Math.sin(o.phi) * Math.cos(o.theta) * o.r);
    } else {
      if (this.mode === "auto" && this.t >= this.shot.until) {
        const next = this.queue.shift();
        if (next) { next.until = this.t + next.dur; this.shot = next; }
        else if (this.shot.type === "wide" && chars.length && Math.random() < 0.7) this.shot = { type: "focus", target: chars[(Math.random() * chars.length) | 0], until: this.t + 3.5, kind: "idle" };
        else this.shot = { type: "wide", until: this.t + 5 + Math.random() * 3 };
      }
      const tg = this.shot.target;
      if (this.mode === "wide" || this.shot.type === "wide" || !tg || tg.done || !chars.includes(tg)) {
        const d = this.wideFit();
        this.dPos.set(Math.sin(this.t * 0.2) * 0.9, 3.3 + Math.sin(this.t * 0.13) * 0.25, d); this.dLook.set(0, 2.9, 0);
        if (this.shot.type === "focus" && this.mode === "auto") this.shot.until = 0;
      } else {
        const p = tg.pos, side = tg.id.length % 2 ? 1 : -1, dist = this.shot.kind === "gift" ? 3.4 : 4.2;
        this.dPos.set(p.x + side * 1.5, p.y + 1.55, p.z + dist); this.dLook.set(p.x, p.y + 1.15, p.z);
      }
    }
    const k = 1 - Math.exp(-dt * (this.mode === "manual" ? 10 : 2.2));
    this.pos.lerp(this.dPos, k); this.look.lerp(this.dLook, k);
    this.constrain(chars);
    this.cam.position.copy(this.pos); this.cam.lookAt(this.look);
  }
  constrain(chars) {
    const p = this.pos;
    p.x = clamp(p.x, -11, 11); p.y = clamp(p.y, 1.0, 9); p.z = clamp(p.z, 2.4, 22);
    if (p.z > 4.8 && p.z < 12.5) p.y = Math.max(p.y, 2.3); // acima da plateia
    for (const c of chars) {
      if (p.y > 2.6) break;
      const dx = p.x - c.pos.x, dz = p.z - c.pos.z, d = Math.hypot(dx, dz);
      if (d < 1.4) { const s = d > 0.001 ? 1.4 / d : 0; p.x = c.pos.x + (d > 0.001 ? dx * s : 0); p.z = c.pos.z + (d > 0.001 ? dz * s : 1.4); }
    }
  }
}
