// Teste de fumaça do palco: roda o engine.js REAL (com THREE de mentira) ligado a um servidor real.
// Valida lógica (eventos → personagens, slots, presentes, câmera, números finitos). NÃO valida a aparência.
import assert from "node:assert/strict";
import fs from "node:fs"; import os from "node:os"; import path from "node:path";
import { EventEmitter } from "node:events";
import { createApp } from "../server.js";

class FakeConn extends EventEmitter { async connect() {} async disconnect() {} }
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "lw-smoke-"));
const app = createApp({ port: 0, host: "127.0.0.1", enableTestEvents: true, adminToken: "", musicDir: dir, log: () => {}, connectorFactory: async () => new FakeConn() });
const port = await app.start(), base = `http://127.0.0.1:${port}`;

const realFetch = globalThis.fetch;
globalThis.fetch = (u, o) => realFetch(new URL(u, base), o);
const els = {};
const mkEl = () => ({ hidden: false, textContent: "", style: {}, addEventListener() {}, setPointerCapture() {}, getContext: () => new Proxy(function () {}, { get: (_, k) => (k === "measureText" ? () => ({ width: 100 }) : () => new Proxy(function () {}, { get: () => () => {} })), set: () => true }), width: 0, height: 0 });
globalThis.window = globalThis;
Object.assign(globalThis, { innerWidth: 540, innerHeight: 960, devicePixelRatio: 1, addEventListener() {} });
Object.defineProperty(globalThis, "navigator", { value: { userAgent: "Android smoke" }, configurable: true });
globalThis.location = { search: "?q=med&audio=0", href: base + "/stage.html", protocol: "http:", host: `127.0.0.1:${port}`, replace() {} };
globalThis.document = { getElementById: (id) => (els[id] ??= mkEl()), createElement: () => mkEl(), addEventListener() {}, visibilityState: "visible" };
globalThis.Audio = class { constructor() { this.paused = true; this.readyState = 0; this.currentTime = 0; } addEventListener() {} pause() {} play() { return Promise.resolve(); } };
const rafs = []; globalThis.requestAnimationFrame = (cb) => { rafs.push(cb); return rafs.length; };
const errors = []; process.on("uncaughtException", (e) => errors.push(e)); process.on("unhandledRejection", (e) => errors.push(e));
setTimeout(() => { console.error("SMOKE FALHOU: tempo esgotado"); process.exit(2); }, 90000).unref();
try {

await import("../public/stage/engine.js");
const S = globalThis.__stage;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let t = 1000;
const run = (frames) => { for (let i = 0; i < frames; i++) { t += 16.7; const cb = rafs.pop(); cb(t); assert.ok(Number.isFinite(S.director.cam.position.x + S.director.cam.position.y + S.director.cam.position.z), "câmera NaN"); const p = S.director.cam.position; assert.ok(p.y >= 0.99 && p.z >= 2.39 && p.z <= 22.01 && Math.abs(p.x) <= 11.01, `câmera fora dos limites ${p.x},${p.y},${p.z}`); } };
const post = (p, b) => realFetch(base + p, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(b) });

await sleep(400); run(5);
await post("/api/test-event", { type: "member", name: "Ana" });
await post("/api/test-event", { type: "member", name: "Bruno" });
await post("/api/test-event", { type: "member", name: "Ana" }); // duplicada
await post("/api/test-event", { type: "chat", name: "Ana", text: "Oi pessoal! Que show lindo" });
await post("/api/test-event", { type: "like", name: "Bruno", count: 3 });
await sleep(300); run(30);
assert.equal(S.chars.size, 2, "Ana + Bruno, sem duplicar");
assert.ok([...S.chars.values()].every((c) => c.state === "entering"), "entram andando");
run(500); // ~8 s
assert.ok([...S.chars.values()].every((c) => c.state === "dancing"), "chegaram e dançam");
for (const c of S.chars.values()) {
  assert.ok(Math.abs(c.pos.x - c.target.x) < 0.06 && Math.abs(c.pos.z - c.target.z) < 0.06, "no lugar do palco");
  for (const j of Object.values(c.joints)) assert.ok(Number.isFinite(j.rotation.x + j.rotation.y + j.rotation.z + j.position.y), "pose finita");
}
// presente: dança especial + efeito + câmera
await post("/api/test-event", { type: "gift", name: "Carla", giftName: "Lion", diamonds: 500, count: 2 });
await sleep(300); run(20);
const carla = S.chars.get("carla"); assert.ok(carla, "Carla apareceu ao enviar presente");
assert.equal(carla.special, "spin", "Lion (≥1000💎 total) → spin (config/gifts.json)");
assert.equal(S.director.shot.kind, "gift", "câmera foca quem mandou presente");
run(400);
// lotação: 30 espectadores → nunca passa do limite do palco; excedentes saem andando e são removidos
for (let i = 0; i < 30; i++) await post("/api/test-event", { type: "member", name: `Fã${i}` });
await sleep(600); run(60);
assert.ok(S.chars.size <= 14, `limite de palco (${S.chars.size})`);
const owners = new Set(); for (const c of S.chars.values()) { assert.ok(!owners.has(c.slot), "slot único"); owners.add(c.slot); }
run(700);
// desconexão/novo reset limpa o palco
await app.manager.disconnect(); await app.manager.connect("@fulano"); await sleep(300); run(10);
assert.equal(S.chars.size, 0, "reset limpa personagens");
// modos de câmera
for (const m of ["wide", "manual", "auto"]) { S.director.setMode(m); run(120); }
S.director.drag(300, -200); S.director.zoom(0.1); run(60); // manual extremo respeita limites (assert dentro de run)
assert.equal(errors.length, 0, "sem exceções: " + errors.map((e) => e.stack || e).join("\n"));
assert.ok(globalThis.__renderCalls > 1500, "renderizou frames");
console.log(`SMOKE OK — frames=${globalThis.__renderCalls} chars=${S.chars.size}`);
await app.stop(); fs.rmSync(dir, { recursive: true, force: true }); process.exit(0);
} catch (e) { console.error("SMOKE FALHOU:", e.message); process.exit(1); }
