// THREE de mentira SÓ para testes de lógica (sem renderizar). Vetores/objetos têm matemática real; o resto aceita qualquer chamada.
function deep() {
  const props = {}; const f = function () {};
  const p = new Proxy(f, {
    get(_, k) { if (k === Symbol.toPrimitive) return () => 0; if (typeof k === "symbol" || k === "then") return undefined; if (!(k in props)) props[k] = deep(); return props[k]; },
    set(_, k, v) { props[k] = v; return true; }, apply() { return p; }, construct() { return p; },
  });
  return p;
}
const D = class { constructor() { return deep(); } };
export class Vector2 { constructor(x = 0, y = 0) { this.x = x; this.y = y; } }
export class Vector3 {
  constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
  set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
  setScalar(s) { return this.set(s, s, s); }
  copy(v) { return this.set(v.x, v.y, v.z); }
  clone() { return new Vector3(this.x, this.y, this.z); }
  lerp(v, k) { this.x += (v.x - this.x) * k; this.y += (v.y - this.y) * k; this.z += (v.z - this.z) * k; return this; }
  multiplyScalar(s) { return this.set(this.x * s, this.y * s, this.z * s); }
}
class Euler { constructor() { this.x = 0; this.y = 0; this.z = 0; } set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; } }
export class Object3D {
  constructor() { this.position = new Vector3(); this.rotation = new Euler(); this.scale = new Vector3(1, 1, 1); this.children = []; this.parent = null; this.matrix = deep(); this.shadow = deep(); }
  add(...c) { for (const o of c) { o.parent = this; this.children.push(o); } return this; }
  removeFromParent() { if (this.parent) this.parent.children = this.parent.children.filter((o) => o !== this); this.parent = null; return this; }
  traverse(fn) { fn(this); this.children.forEach((c) => c.traverse?.(fn)); }
  updateMatrix() {} lookAt() {}
}
export class Group extends Object3D {}
export class Scene extends Object3D {}
export class Mesh extends Object3D { constructor(g, m) { super(); this.geometry = g ?? deep(); this.material = m ?? deep(); this.isMesh = true; } }
export class InstancedMesh extends Mesh { constructor(g, m, n) { super(g, m); this.count = n; this.instanceMatrix = deep(); } setMatrixAt() {} }
export class Points extends Object3D { constructor(g, m) { super(); this.geometry = g ?? deep(); this.material = m ?? deep(); } }
export class Sprite extends Object3D { constructor(m) { super(); this.material = m ?? deep(); } }
export class PerspectiveCamera extends Object3D { constructor(fov, aspect) { super(); this.fov = fov; this.aspect = aspect; } updateProjectionMatrix() {} }
for (const n of ["DirectionalLight", "HemisphereLight", "PointLight"]) globalThis["__" + n] = null;
export class DirectionalLight extends Object3D { constructor() { super(); this.target = new Object3D(); } }
export class HemisphereLight extends Object3D {}
export class PointLight extends Object3D { constructor(c, i) { super(); this.intensity = i; } }
export class WebGLRenderer { constructor() { this.shadowMap = {}; this.frames = 0; } setPixelRatio() {} setSize() {} render() { this.frames++; globalThis.__renderCalls = (globalThis.__renderCalls || 0) + 1; } }
export const ACESFilmicToneMapping = 4, AdditiveBlending = 2, DoubleSide = 2, PCFSoftShadowMap = 2, RepeatWrapping = 1000, SRGBColorSpace = "srgb";
export const AnimationMixer = D, Box3 = D, BoxGeometry = D, BufferAttribute = D, BufferGeometry = D, CanvasTexture = D, CapsuleGeometry = D, CircleGeometry = D, Color = D, ConeGeometry = D, CylinderGeometry = D, FogExp2 = D, LatheGeometry = D, MeshBasicMaterial = D, MeshStandardMaterial = D, PlaneGeometry = D, PointsMaterial = D, RingGeometry = D, SphereGeometry = D, SpriteMaterial = D, TorusGeometry = D;
export const GLTFLoader = D, clone = (s) => s;
