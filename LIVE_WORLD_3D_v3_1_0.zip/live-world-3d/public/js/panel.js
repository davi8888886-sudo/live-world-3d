// Painel de controle (celular). Nomes de espectadores sempre entram via textContent (sem HTML).
import { connectSocket } from "./net.js";
const $ = (id) => document.getElementById(id);
const el = (tag, props = {}, ...kids) => { const e = Object.assign(document.createElement(tag), props); e.append(...kids); return e; };
const store = { get: (k, d = "") => { try { return localStorage.getItem(k) ?? d; } catch { return d; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch { /* modo privado */ } } };
let cfg = { adminRequired: false, testEvents: false, dances: ["auto"], maxUploadMb: 30 };
let music = { tracks: [], currentId: null, playing: false, volume: 0.8 };
let status = { status: "disconnected", message: "" };

// ---------- API ----------
const token = () => (store.get("lw_token") || $("token").value || "").trim();
async function api(path, { method = "GET", body, headers = {} } = {}) {
  const h = { "x-admin-token": token(), ...headers };
  if (body && typeof body === "object" && !(body instanceof Blob)) { h["content-type"] = "application/json"; body = JSON.stringify(body); }
  let r;
  try { r = await fetch(path, { method, headers: h, body }); } catch { throw new Error("Sem conexão com o servidor."); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || `Erro ${r.status}`); e.status = r.status; e.data = j; throw e; }
  return j;
}
function authError(e, target) {
  if (e.status === 401) { $("tokenRow").hidden = false; target.textContent = "Senha do painel incorreta ou ausente. Informe o ADMIN_TOKEN."; return true; }
  return false;
}

// ---------- abas ----------
const tabs = [...document.querySelectorAll("section[data-tab]")];
function go(name) {
  tabs.forEach((s) => (s.hidden = s.dataset.tab !== name));
  document.querySelectorAll("nav button").forEach((b) => b.classList.toggle("on", b.dataset.go === name));
  store.set("lw_tab", name);
  if (name === "stage") mountStage(); else { unmountStage(); if ($("frameWrap")?.classList.contains("grown")) growStage(false); }
  if (name === "more") loadDiag();
}
document.querySelectorAll("nav button").forEach((b) => (b.onclick = () => go(b.dataset.go)));

// ---------- status ----------
const PILL = { connected: ["TikTok: CONECTADO", "ok"], connecting: ["TikTok: conectando…", "warn"], reconnecting: ["TikTok: reconectando…", "warn"], disconnected: ["TikTok: desconectado", "off"], error: ["TikTok: erro", "bad"] };
function renderStatus(s) {
  status = s;
  const [txt, cls] = PILL[s.status] || PILL.disconnected;
  $("ttPill").textContent = s.status === "connected" && s.username ? `TikTok: CONECTADO @${s.username}` : txt; $("ttPill").className = "pill " + cls;
  const busy = s.status === "connecting";
  $("btnConnect").disabled = busy || s.status === "connected";
  $("btnDisconnect").disabled = s.status === "disconnected" || s.status === "error";
  const m = $("ttMsg"); m.textContent = s.message || (s.status === "connected" ? `Conectado à LIVE de @${s.username}.` : ""); m.className = "msg " + (s.status === "error" ? "bad" : s.status === "connected" ? "ok" : "");
}
function renderStats(st) { if (!st) return; $("stV").textContent = st.viewers; $("stC").textContent = st.comments; $("stL").textContent = st.likes; $("stG").textContent = st.gifts; }
function feed(ev) {
  const n = ev.user?.name || "?"; let t = "";
  if (ev.type === "member") t = `👋 ${n} entrou`;
  else if (ev.type === "chat") t = `💬 ${n}: ${ev.text}`;
  else if (ev.type === "like") t = `❤ ${n} +${ev.count}`;
  else if (ev.type === "gift") t = `🎁 ${n} enviou ${ev.count}x ${ev.giftName}${ev.total ? ` (${ev.total}💎)` : ""}`;
  else return;
  const ul = $("feed"); if (ul.firstChild?.classList?.contains("dim")) ul.textContent = "";
  ul.prepend(el("li", { className: ev.test ? "test" : "", textContent: (ev.test ? "[teste] " : "") + t }));
  while (ul.children.length > 40) ul.lastChild.remove();
}

// ---------- WebSocket ----------
const wsPill = (ok) => { $("wsPill").textContent = ok ? "Servidor: online" : "Servidor: reconectando…"; $("wsPill").className = "pill " + (ok ? "ok" : "warn"); };
connectSocket({
  onOpen: () => wsPill(true), onClose: () => wsPill(false),
  onMessage: (m) => {
    if (m.t === "hello") { renderStatus(m.status); renderStats(m.stats); music = m.music; renderMusic(); if (m.testEvents) $("testCard").hidden = false; }
    else if (m.t === "status") renderStatus(m.status);
    else if (m.t === "stats") renderStats(m.stats);
    else if (m.t === "event") feed(m.ev);
    else if (m.t === "reset") { $("feed").replaceChildren(el("li", { className: "dim", textContent: "Nova conexão…" })); renderStats({ viewers: 0, comments: 0, likes: 0, gifts: 0 }); }
    else if (m.t === "music") { music = m.music; renderMusic(); }
  },
});

// ---------- conectar ----------
$("user").value = store.get("lw_user"); $("token").value = store.get("lw_token");
$("btnConnect").onclick = async () => {
  const v = $("user").value; store.set("lw_user", v); store.set("lw_token", $("token").value.trim());
  $("ttMsg").className = "msg"; $("ttMsg").textContent = "Conectando…"; $("btnConnect").disabled = true;
  try { renderStatus(await api("/api/connect", { method: "POST", body: { username: v } })); }
  catch (e) { if (!authError(e, $("ttMsg"))) { $("ttMsg").className = "msg bad"; $("ttMsg").textContent = e.message; } if (e.data?.status) renderStatus(e.data.status); $("btnConnect").disabled = false; }
};
$("btnDisconnect").onclick = async () => { try { renderStatus(await api("/api/disconnect", { method: "POST" })); } catch (e) { if (!authError(e, $("ttMsg"))) $("ttMsg").textContent = e.message; } };
$("user").addEventListener("keydown", (e) => { if (e.key === "Enter") $("btnConnect").click(); });
$("token").addEventListener("change", () => store.set("lw_token", $("token").value.trim()));

// ---------- palco ----------
let frame = null;
const qSel = $("qSel"); qSel.value = store.get("lw_q", /Android|iPhone|iPad/i.test(navigator.userAgent) ? "low" : "med");
$("listen").checked = store.get("lw_listen") === "1";
const stageUrl = (extra = "") => `/stage.html?q=${qSel.value}&audio=${$("listen").checked ? 1 : 0}${extra}`;
function mountStage() { if (frame) return; frame = el("iframe", { src: stageUrl(), allow: "autoplay; fullscreen", title: "Palco 3D" }); $("frameBox").replaceChildren(frame); }
function unmountStage() { if (!frame) return; frame.src = "about:blank"; frame.remove(); frame = null; }
qSel.onchange = () => { store.set("lw_q", qSel.value); if (frame) frame.src = stageUrl(); };
$("listen").onchange = () => { store.set("lw_listen", $("listen").checked ? "1" : "0"); if (frame) frame.src = stageUrl(); };
$("btnFull").onclick = () => { const f = frame || $("frameBox"); const rq = f.requestFullscreen || f.webkitRequestFullscreen; if (rq) rq.call(f).catch(() => window.open(stageUrl("&fit=free"), "_blank")); else window.open(stageUrl("&fit=free"), "_blank"); };
// botão pequeno: aumenta o palco para a tela inteira (sem recarregar o iframe, então nada reconecta)
function growStage(on) {
  const w = $("frameWrap"), btn = $("btnGrow"); if (!w || !btn) return;
  w.classList.toggle("grown", on); btn.textContent = on ? "✕" : "⛶"; btn.title = on ? "Voltar" : "Aumentar a tela";
  document.body.style.overflow = on ? "hidden" : "";
  if (on) { const d = document.documentElement; (d.requestFullscreen || d.webkitRequestFullscreen)?.call(d, { navigationUI: "hide" })?.catch?.(() => {}); }
  else if (document.fullscreenElement) document.exitFullscreen?.().catch?.(() => {});
}
$("btnGrow").onclick = () => growStage(!$("frameWrap").classList.contains("grown"));
document.addEventListener("fullscreenchange", () => { if (!document.fullscreenElement && $("frameWrap").classList.contains("grown")) growStage(false); });
addEventListener("keydown", (e) => { if (e.key === "Escape" && $("frameWrap").classList.contains("grown")) growStage(false); });
$("btnNew").onclick = () => window.open(stageUrl("&fit=free"), "_blank");
async function cmd(body, out) { try { await api("/api/cmd", { method: "POST", body }); } catch (e) { if (!authError(e, out || $("ttMsg"))) alert(e.message); } }
$("camSeg").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; [...$("camSeg").children].forEach((x) => x.classList.toggle("on", x === b)); cmd({ camera: b.dataset.v }); };
document.querySelectorAll(".evBtn").forEach((b) => { b.onclick = () => cmd({ event: { kind: b.dataset.ev } }); });
$("djNext").onclick = () => cmd({ dj: { action: "next" } });
$("djOff").onclick = () => cmd({ dj: { action: "release" } });
$("danceSel").onchange = () => cmd({ dance: $("danceSel").value });

// ---------- música ----------
const mb = (n) => (n / 1048576).toFixed(1) + " MB";
function renderMusic() {
  const cur = music.tracks.find((t) => t.id === music.currentId);
  $("now").textContent = cur ? `${music.playing ? "▶" : "⏸"} ${cur.name}` : "Nenhuma música";
  $("bPlay").textContent = music.playing ? "⏸" : "▶"; $("vol").value = Math.round(music.volume * 100);
  $("list").replaceChildren(...(music.tracks.length ? music.tracks.map((t) => el("li", { className: t.id === music.currentId ? "cur" : "" },
    el("span", { textContent: `${t.name} · ${mb(t.size)}` }),
    el("button", { textContent: "Tocar", onclick: () => mctl("select", t.id) }),
    el("button", { textContent: "🗑", ariaLabel: "Remover", onclick: () => del(t) }))) : [el("li", { className: "dim", textContent: "Nenhuma música enviada." })]));
}
async function mctl(action, value) { try { await api("/api/music/control", { method: "POST", body: { action, value } }); } catch (e) { if (!authError(e, $("upMsg"))) { $("upMsg").className = "msg bad"; $("upMsg").textContent = e.message; } } }
async function del(t) { if (!confirm(`Remover "${t.name}"?`)) return; try { await api(`/api/music/${t.id}`, { method: "DELETE" }); } catch (e) { $("upMsg").textContent = e.message; } }
$("bPlay").onclick = () => mctl(music.playing ? "pause" : "play"); $("bNext").onclick = () => mctl("next"); $("bPrev").onclick = () => mctl("prev");
let vt; $("vol").oninput = () => { clearTimeout(vt); vt = setTimeout(() => mctl("volume", $("vol").value / 100), 120); };
function upload(file) {
  return new Promise((resolve) => {
    const x = new XMLHttpRequest(); x.open("POST", "/api/music");
    x.setRequestHeader("x-admin-token", token()); x.setRequestHeader("x-filename", encodeURIComponent(file.name));
    x.upload.onprogress = (e) => { if (e.lengthComputable) $("upMsg").textContent = `Enviando ${file.name}… ${Math.round((e.loaded / e.total) * 100)}%`; };
    x.onload = () => { let j = {}; try { j = JSON.parse(x.responseText); } catch { /* ignora */ } if (x.status === 201) { $("upMsg").className = "msg ok"; $("upMsg").textContent = `“${file.name}” enviada.`; } else if (x.status === 401) { $("tokenRow").hidden = false; $("upMsg").className = "msg bad"; $("upMsg").textContent = "Senha do painel incorreta (veja a aba Conectar)."; } else { $("upMsg").className = "msg bad"; $("upMsg").textContent = j.error || `Falha no envio (${x.status}).`; } resolve(); };
    x.onerror = () => { $("upMsg").className = "msg bad"; $("upMsg").textContent = "Falha de rede no envio."; resolve(); };
    x.send(file);
  });
}
$("file").onchange = async (e) => { for (const f of e.target.files) await upload(f); e.target.value = ""; };

// ---------- transmitir / diagnóstico / teste ----------
$("obsUrl").value = `${location.origin}/stage.html?clean=1`;
$("copyUrl").onclick = async () => { try { await navigator.clipboard.writeText($("obsUrl").value); $("copyUrl").textContent = "Copiado ✓"; } catch { $("obsUrl").select(); $("copyUrl").textContent = "Selecione e copie"; } setTimeout(() => ($("copyUrl").textContent = "Copiar endereço"), 2000); };
$("openUrl").onclick = () => window.open($("obsUrl").value + "&debug=1", "_blank");
async function loadDiag() { try { const h = await (await fetch("/health")).json(); $("diag").textContent = JSON.stringify(h, null, 2); } catch { $("diag").textContent = "Servidor indisponível."; } }
$("btnDiag").onclick = loadDiag;
document.querySelectorAll("[data-test]").forEach((b) => (b.onclick = () => { const name = $("tName").value || "Visitante1"; api("/api/test-event", { method: "POST", body: { type: b.dataset.test, name, uniqueId: name, text: "Olá, palco!", giftName: "Rose", count: 1, diamonds: 1, } }).catch((e) => { if (!authError(e, $("ttMsg"))) alert(e.message); }); }));

// ---------- início ----------
fetch("/api/config").then((r) => r.json()).then((c) => {
  cfg = c; $("tokenRow").hidden = !c.adminRequired;
  $("danceSel").replaceChildren(...c.dances.map((d) => el("option", { value: d, textContent: d === "auto" ? "Automática (variada)" : d })));
  if (c.testEvents) $("testCard").hidden = false;
}).catch(() => {});
renderStatus(status); renderMusic(); wsPill(false);
go(store.get("lw_tab", "connect"));
