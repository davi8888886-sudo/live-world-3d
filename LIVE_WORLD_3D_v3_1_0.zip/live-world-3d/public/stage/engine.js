// Palco 3D: liga eventos reais do servidor (WebSocket) a personagens, câmera, efeitos e áudio.
import * as THREE from "three";
import { connectSocket } from "../js/net.js";
import { buildWorld } from "./world.js";
import { Effects } from "./effects.js";
import { Character, makeLook, buildCharacter, prepareGLB, hash } from "./characters.js";
import { Director } from "./camera.js";
import { StageAudio, BeatDetector } from "./audio.js";
import { resolveGift } from "./gifts.js";
import { makeSlots, addGift, topSupporters, isActive, parseIdle, DJ_SPOT } from "./arena-rules.js";
import "./dance-library.js";
import { DjQueue, isDjCommand } from "./dj-queue.js";
import { EffectQueue } from "./effect-queue.js";
import { ArenaEvents, ComboTracker, makePairs, EVENT_NAMES } from "./arena-events.js";

const qs = new URLSearchParams(location.search);
// TEST=1 só para você testar com os "eventos de teste" do painel. Sem isso, eventos de teste NUNCA criam avatares.
const TEST = qs.get("test") === "1", IDLE_MS = parseIdle(qs.get("idle")) * 1000;
const CLEAN = qs.get("clean") === "1", DEBUG = qs.get("debug") === "1", AUDIO_ON = qs.get("audio") !== "0";
const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
const QN = ["low", "med", "high"];
const qName = QN.includes(qs.get("q")) ? qs.get("q") : isMobile ? "med" : "high";   // celular começa em "med"; a qualidade adaptativa ajusta sozinha
const Q = QN.indexOf(qName);
const $ = (id) => document.getElementById(id);
const msg = $("msg"), canvas = $("c");
const fatal = (t) => { msg.textContent = t; msg.hidden = false; };

let renderer;
try { renderer = new THREE.WebGLRenderer({ canvas, antialias: Q >= 1, powerPreference: "high-performance" }); }
catch (e) { fatal("Este navegador não conseguiu iniciar o WebGL (gráficos 3D)."); throw e; }
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
if (Q >= 2) { renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; }
// Resolução: renderiza no mínimo ~1280/1600/1920 px de altura (antes: 1x no celular = imagem borrada). A qualidade adaptativa só reduz se o FPS cair.
const TARGET_H = [1280, 1600, 1920][Q]; let qScale = 1, pixelRatio = 1;
const prFor = (h) => Math.max(0.6, Math.min(Math.max(devicePixelRatio || 1, TARGET_H / Math.max(1, h)), [1.5, 2, 2.5][Q]) * qScale);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(52, 9 / 16, 0.1, 160);
const world = buildWorld(scene, Q), effects = new Effects(scene, Q ? 600 : 300), director = new Director(camera);
const beat = new BeatDetector();
const sock = { s: null };
const audio = new StageAudio({ enabled: AUDIO_ON, onEnded: (id) => sock.s?.send({ t: "ended", id }), onBlocked: () => { if (!CLEAN) $("unlock").hidden = false; } });
$("unlock").onclick = async () => { await audio.unlock(); $("unlock").hidden = !audio.blocked; };
addEventListener("pointerdown", () => { if (audio.blocked) audio.unlock(); }, { passive: true });

// Tela cheia: o 1º toque na página do palco esconde a barra de endereço (só vale fora do painel; use ?fs=0 para desligar).
addEventListener("pointerdown", () => {
  if (qs.get("fs") === "0" || window.self !== window.top) return;
  const el = document.documentElement;
  if (el?.requestFullscreen && !document.fullscreenElement) el.requestFullscreen({ navigationUI: "hide" }).catch(() => {});
}, { passive: true });

function resize() {
  let w = innerWidth, h = innerHeight;
  if (!CLEAN && qs.get("fit") !== "free") { const r = 9 / 16; if (w / h > r) w = Math.round(h * r); else h = Math.round(w / r); }
  pixelRatio = prFor(h); renderer.setPixelRatio(pixelRatio); renderer.setSize(w, h, false);
  canvas.style.width = w + "px"; canvas.style.height = h + "px"; director.setAspect(w / h);
}
addEventListener("resize", resize); resize();

// ---------- personagens ----------
// Arena gigante: vagas em leque, do centro para fora (ver arena-rules.js). Cada vaga só é usada por um usuário REAL.
const SLOTS = makeSlots(96);
const MAX = [24, 48, 72][Q];   // vagas ocupadas só por usuários reais
const chars = new Map(), leaving = [], slotOwner = SLOTS.map(() => null);
const templates = []; let SU = null, danceOverride = "auto", giftCfg = null, skew = 0;
const led = { spectrum: new Array(24).fill(0), hasAudio: false, username: "", status: "Aguardando conexão", viewers: 0, gifts: 0, likes: 0, ticker: ["Aguardando a LIVE…"], alert: null, join: null, rank: [], now: 0, dj: { name: "", queue: 0 } };
const dj = new DjQueue(), fxq = new EffectQueue();
function syncDj() {   // atualiza telão, cabine e câmera; move o avatar do DJ ativo (sempre um usuário real)
  const snap = dj.snapshot(); led.dj = { name: snap.active?.name || "", queue: snap.queue.length }; world.setDj?.(snap.active?.name || ""); director.dj = snap.active ? true : null;
}

// Memória local (só deste navegador) para o ranking e para saber quem esteve ativo há pouco. Nada disso vem de bots.
const store = { get(k) { try { return JSON.parse(localStorage.getItem(k) || "null"); } catch { return null; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }, del(k) { try { localStorage.removeItem(k); } catch {} } };
const rank = new Map(); let seen = {}, seenSaveAt = 0, rankUser = "";
const saveRank = () => store.set("lw_rank", { user: rankUser, items: [...rank.values()] });
const loadRank = (username) => { rank.clear(); rankUser = username || ""; const r = store.get("lw_rank"); if (r && r.user === rankUser && Array.isArray(r.items)) for (const it of r.items) if (it?.id && it.total > 0) rank.set(it.id, { id: it.id, name: String(it.name || ""), total: Number(it.total) }); led.rank = topSupporters(rank); };
const resetMemory = () => { rank.clear(); seen = {}; store.del("lw_rank"); store.del("lw_seen"); led.rank = []; };
const pushTicker = (s) => { led.ticker.push(s); if (led.ticker.length > 6) led.ticker.shift(); };
const STATUS_TXT = { connected: "CONECTADO", connecting: "Conectando…", reconnecting: "Reconectando…", disconnected: "Desconectado", error: "Erro de conexão" };

async function loadModels() {
  try {
    const r = await fetch("/models/manifest.json", { cache: "no-cache" }); if (!r.ok) return;
    const m = await r.json(), list = (m.characters || []).filter((x) => x && x.file);
    if (!list.length) return;
    const [{ GLTFLoader }, su] = await Promise.all([import("three/addons/loaders/GLTFLoader.js"), import("three/addons/utils/SkeletonUtils.js")]);
    SU = su; const loader = new GLTFLoader(); let shared = [];
    if (m.animations) { try { shared = (await loader.loadAsync(m.animations)).animations; } catch (e) { console.warn("animações não carregaram", e); } }
    for (const f of list) { try { const g = await loader.loadAsync(f.file); templates.push({ scene: g.scene, clips: [...g.animations, ...shared] }); } catch (e) { console.warn("modelo não carregou:", f.file, e); } }
  } catch (e) { console.warn("manifest de modelos", e); }
}
const modelsReady = loadModels();
function makeModel(id) {
  if (templates.length) { const t = templates[hash(id) % templates.length]; return prepareGLB(SU.clone(t.scene), t.clips); }
  return buildCharacter(makeLook(id));
}
function setSlot(c, s) { if (c.slot >= 0 && slotOwner[c.slot] === c) slotOwner[c.slot] = null; c.slot = s; if (s >= 0) slotOwner[s] = c; }
function evictOldest() {
  let o = null; for (const c of chars.values()) if (!o || c.lastActive < o.lastActive) o = c;
  if (!o) return; chars.delete(o.id); setSlot(o, -1); o.leave(); leaving.push(o);
}
function spawn(u) {
  const have = chars.get(u.id); if (have) return have;
  let s = slotOwner.findIndex((o, i) => !o && i < MAX);
  if (s < 0) { evictOldest(); s = slotOwner.findIndex((o, i) => !o && i < MAX); }
  if (s < 0) return null;
  const c = new Character(u, makeModel(u.id));
  c.place(SLOTS[s], Math.random() < 0.5 ? -1 : 1); setSlot(c, s);
  scene.add(c.group); chars.set(u.id, c); return c;
}
function djEnter(u) {   // coloca o DJ real na cabine; se ele não está na arena ainda, cria o avatar dele (usuário real)
  const c = chars.get(u.id) || spawn(u); if (!c) return;
  setSlot(c, -1); c.goDj(DJ_SPOT); c.lastActive = performance.now(); c.special = null; pushTicker(`🎧 ${u.name} assumiu a cabine`);
  led.alert = { text: `DJ ${u.name} na cabine!`, sub: "", until: performance.now() + 4000 }; world.hype?.("gift"); director.cut(c, 4, "gift");
}
function djExit(u) {
  const c = chars.get(u.id); if (!c || !c.djMode) return;
  const s = slotOwner.findIndex((o, i) => !o && i < MAX); if (s < 0) { chars.delete(c.id); c.leave(); leaving.push(c); return; }
  setSlot(c, s); c.leaveDj(SLOTS[s]);
}
function djCmd(cmd) {   // comandos do dono (painel): {action: "next"|"pick"|"release", id?}
  if (cmd.action === "release") { const p = dj.release(); if (p) djExit(p); }
  else if (cmd.action === "next" || cmd.action === "pick") { const r = dj.select(cmd.action === "pick" ? cmd.id : null); if (r) { if (r.previous) djExit(r.previous); djEnter(r.active); } }
  syncDj();
}
function clearAll() { for (const c of [...chars.values(), ...leaving]) c.dispose(); chars.clear(); leaving.length = 0; slotOwner.fill(null); }
function bringFront(c) {
  if (c.slot < 3) return;
  for (let s = 0; s < 3; s++) {
    const o = slotOwner[s];
    if (!o) { slotOwner[c.slot] = null; setSlot(c, s); c.moveTo(SLOTS[s]); return; }
    if (!o.special) { const a = c.slot, b = o.slot; slotOwner[a] = o; slotOwner[b] = c; c.slot = b; o.slot = a; c.moveTo(SLOTS[b]); o.moveTo(SLOTS[a]); return; }
  }
}
const combos = new ComboTracker(), events = new ArenaEvents(); let eventDance = null, eventDanceUntil = 0, battle = null;
const notice = (text, sub = "") => { led.alert = { text, sub, until: performance.now() + 3800 }; };
const titleOf = (c) => ((led.rank[0] && led.rank[0].id === c.id) ? "👑 " : "") + (c.baseName || c.name.replace(/^👑 /, ""));
function refreshCrowns() { for (const c of chars.values()) c.setName(titleOf(c)); }   // destaque visual do maior apoiador (coroa no nome)
function reactAround(c, n) {   // reação dos avatares reais próximos ao presente
  const near = [...chars.values()].filter((o) => o !== c && !o.djMode && !o.special && Math.hypot(o.pos.x - c.pos.x, o.pos.z - c.pos.z) < 8).sort((a, b) => Math.hypot(a.pos.x - c.pos.x, a.pos.z - c.pos.z) - Math.hypot(b.pos.x - c.pos.x, b.pos.z - c.pos.z)).slice(0, n);
  near.forEach((o, i) => { const d = 0.15 * i; setTimeout(() => { if (chars.get(o.id) === o && !o.special) o.triggerSpecial(i % 2 ? "celebrate" : "wave", 2 + Math.random() * 1.5); }, d * 1000); });
}
function groupCelebrate(secs, dance = "grupo_jamal") { for (const o of chars.values()) if (!o.djMode) o.triggerSpecial(dance, secs); }
function onGift(c, ev) {
  const g = resolveGift(giftCfg, ev), secs = g.focusSeconds || 5, now = performance.now(), total = Number(ev.total) || 0;
  const combo = combos.hit(c.id, now, Math.max(1, ev.count || 1)), epic = total >= (giftCfg?.epic?.minDiamonds ?? 2000);
  if (!c.djMode) c.triggerSpecial(g.dance, Math.max(4, secs + (combo >= 5 ? 3 : 0)));   // a dança é só do avatar de quem enviou
  effects.effect(g.effect, c.pos); world.hype?.(g.effect === "cinematic" || epic ? "epic" : "gift");
  if (combo >= 5) { effects.effect("fireworks", c.pos); setTimeout(() => effects.effect("lasers", c.pos), 350); }
  if (combo >= 12) setTimeout(() => effects.effect("cinematic", c.pos), 700);
  led.alert = { text: `${epic ? "🔥 " : ""}Obrigado, ${c.name}!`, sub: `${ev.count > 1 ? ev.count + "x " : ""}${ev.giftName}${total ? " · " + total + "💎" : ""}${combo >= 3 ? " · COMBO x" + combo : ""}`, until: now + (epic ? 6500 : 4500) };
  director.cut(c, epic ? secs + 4 : secs, "gift"); if (!c.djMode) bringFront(c);
  reactAround(c, epic ? 10 : combo >= 3 ? 6 : 3);
  if (epic) { setTimeout(() => groupCelebrate(9), 600); for (let i = 0; i < 4; i++) setTimeout(() => effects.effect("fireworks", { x: (i - 1.5) * 6, y: 0, z: -4 }), 300 + i * 450); pushTicker(`🔥 ${c.name} fez a arena explodir!`); }
}
function startEvent(kind) {
  const now = performance.now(), live = [...chars.values()].filter((c) => !c.djMode);
  if (kind === "cancel") { endEvent({ kind: events.cancel()?.kind, cancelled: true }); return; }
  if (!live.length) return notice("Sem participantes reais na arena");
  if (events.cur) return notice("Já existe um evento em andamento");
  if (kind === "apoiador") {
    const top = topSupporters(rank)[0], c = top && chars.get(top.id); if (!c) return notice("Ainda não há apoiador na arena");
    events.start(kind, now); c.triggerSpecial("jamal", 12); bringFront(c); director.cut(c, 12, "gift"); effects.effect("cinematic", c.pos); reactAround(c, 8); world.hype?.("epic");
    return notice(`👑 ${c.name}, o maior apoiador!`, `${top.total} 💎 em presentes`);
  }
  if (!events.start(kind, now)) return;
  if (kind === "passinho") { eventDance = "jamal"; notice("Desafio do Passinho!", "Quem mais apoiar ganha a pista"); }
  else if (kind === "coletiva") { eventDance = "grupo_jamal"; notice("Rodada coletiva!", "Todo mundo junto"); }
  else if (kind === "batalha") notice("Batalha de dança!", "Comente !entrar (2 vagas)");
  else if (kind === "duplas") {
    const pairs = makePairs(live.map((c) => ({ id: c.id, x: c.pos.x, z: c.pos.z })));
    if (!pairs.length) { events.cancel(); return notice("Poucas pessoas para formar duplas"); }
    for (const [A, B] of pairs) { const a = chars.get(A), b = chars.get(B); a.partner = { lead: false }; b.partner = { lead: true }; a.face = Math.atan2(b.pos.x - a.pos.x, b.pos.z - a.pos.z); b.face = a.face + Math.PI; a.triggerSpecial("dupla_espelho", 25); b.triggerSpecial("dupla_espelho", 25); }
    notice("Rodada de duplas!", `${pairs.length} dupla(s)`);
  }
  world.hype?.("gift"); pushTicker(`🎯 ${EVENT_NAMES[kind]}`);
}
function tickEvents() {
  const r = events.tick(performance.now()); if (!r) return;
  if (r.do === "battleStart") {
    const [A, B] = r.fighters.map((f) => chars.get(f.id)); battle = [A, B];
    if (!A || !B) { events.cancel(); return notice("Batalha cancelada", "um lutador saiu da arena"); }
    [[A, -2.6, Math.PI / 2, "jamal"], [B, 2.6, -Math.PI / 2, "vini"]].forEach(([c, x, face, d]) => { c.moveTo([x, -1]); c.face = face; c.triggerSpecial(d, 42); });
    eventDance = "ola"; director.cut(A, 6, "gift"); world.hype?.("gift"); return notice("BATALHA!", `${A.name} × ${B.name}`);
  }
  if (r.do === "end") endEvent(r);
}
function endEvent(r) {
  eventDance = null; const now = performance.now();
  for (const c of chars.values()) { if (c.face != null) { c.face = null; if (c.slot >= 0) c.moveTo(SLOTS[c.slot]); } c.partner = null; if (r.kind === "duplas" && c.special === "dupla_espelho") c.special = null; }
  battle = null; if (r.cancelled) return r.why ? notice("Evento cancelado", r.why) : undefined;
  const w = r.result?.winner; if (r.result?.tie) return notice("Empate!", "ninguém levou a pista");
  if (r.kind === "coletiva" || r.kind === "apoiador" || r.kind === "duplas") return notice("Evento encerrado", "obrigado a todos!");
  if (!w) return notice("Evento encerrado", "ninguém mandou presentes desta vez");
  const c = chars.get(w.id); if (c) { c.triggerSpecial("celebrate", 7); bringFront(c); director.cut(c, 7, "gift"); effects.effect("cinematic", c.pos); }
  world.hype?.("epic"); led.alert = { text: `🏆 ${w.name} venceu!`, sub: r.kind === "passinho" ? `${w.total} 💎 no desafio` : "batalha de dança", until: now + 7000 }; pushTicker(`🏆 ${w.name} venceu o ${EVENT_NAMES[r.kind].toLowerCase()}`);
}
function onGoal() { groupCelebrate(8, "celebrate"); effects.effect("cinematic", { x: 0, y: 0, z: -2 }); world.hype?.("epic"); notice("🎉 META ALCANÇADA!", `próxima: ${events.goal.target} 💎`); pushTicker("🎉 Meta de presentes alcançada!"); }
function onEvent(ev) {
  const u = ev.user; if (!u) return;
  if (ev.test && !TEST) return;   // evento de teste do painel: não vira avatar na arena
  seen[u.id] = Date.now(); if (Date.now() - seenSaveAt > 2000) { seenSaveAt = Date.now(); store.set("lw_seen", seen); }
  let c = chars.get(u.id);
  if (!c) { c = spawn(u); if (c && ev.isNewViewer) { director.cut(c, 3.2, "join"); pushTicker(`${u.name} entrou`); led.join = { text: u.name, until: performance.now() + 3200 }; world.hype?.("join"); } }
  if (!c) return;
  c.baseName = u.name; c.setName(titleOf(c)); c.lastActive = performance.now();
  if (ev.type === "chat") { c.say(ev.text); pushTicker(`${u.name}: ${ev.text}`); if (events.chat(u, ev.text, performance.now())) pushTicker(`⚔️ ${u.name} entrou na batalha`); if (isDjCommand(ev.text) && dj.join({ id: u.id, name: u.name })) { pushTicker(`🎧 ${u.name} entrou na fila de DJ`); syncDj(); } }
  else if (ev.type === "like") { if (performance.now() - c.lastLike > 1200) { c.lastLike = performance.now(); effects.effect("hearts", c.pos); world.hype?.("like"); } }
  else if (ev.type === "gift-progress") { if (!c.special) c.triggerSpecial("celebrate", 1.6); }
  else if (ev.type === "gift") {   // presente REAL: ranking e metas somam na hora; o efeito entra na fila (1 por vez)
    addGift(rank, { id: c.id, name: c.name.replace(/^👑 /, "") }, ev.total); led.rank = topSupporters(rank); saveRank(); refreshCrowns();
    if (events.gift({ id: c.id, name: c.baseName }, ev.total, performance.now()).goalReached) onGoal();
    if (fxq.push(ev, performance.now())) pushTicker(`🎁 ${c.baseName}: ${ev.count}x ${ev.giftName}`);
  }
}
const setStats = (st) => { if (!st) return; led.viewers = st.viewers; led.gifts = st.gifts; led.likes = st.likes; };
const setStatus = (s) => { led.status = STATUS_TXT[s.status] || s.status; led.username = s.status === "connected" || s.status === "reconnecting" ? s.username || "" : ""; };

fetch("/api/config").then((r) => r.json()).then((c) => { giftCfg = c.gifts; events.setGoal(Number(giftCfg?.goal?.diamonds) || 0); }).catch(() => { giftCfg = { default: { dance: "celebrate", effect: "confetti", focusSeconds: 5 } }; });
sock.s = connectSocket({
  onOpen: () => { msg.hidden = true; },
  onClose: () => { if (!CLEAN) { msg.textContent = "Reconectando ao servidor…"; msg.hidden = false; } },
  onMessage: async (m) => {
    if (m.t === "hello") {
      skew = m.serverTime - Date.now(); setStatus(m.status); setStats(m.stats);
      await modelsReady; clearAll(); loadRank(m.status?.username); seen = store.get("lw_seen") || {};
      // Ao abrir/recarregar: só reaparecem usuários REAIS com atividade recente conhecida (a conexão não informa quem já saiu).
      m.viewers.filter((v) => seen[v.id] && Date.now() - seen[v.id] <= IDLE_MS).slice(-MAX).forEach((v, i) => setTimeout(() => { const c = spawn(v); if (c) c.lastActive = performance.now() - (Date.now() - seen[v.id]); }, i * 350));
      audio.apply(m.music, skew);
    } else if (m.t === "status") setStatus(m.status);
    else if (m.t === "stats") setStats(m.stats);
    else if (m.t === "event") onEvent(m.ev);
    else if (m.t === "reset") { events.cancel(); eventDance = null; dj.queue = []; dj.active = null; syncDj(); clearAll(); resetMemory(); led.ticker = ["Nova conexão…"]; }
    else if (m.t === "music") { skew = m.serverTime - Date.now(); audio.apply(m.music, skew); }
    else if (m.t === "cmd") {
      if (m.cmd.camera) director.setMode(m.cmd.camera);
      if (m.cmd.dance) danceOverride = m.cmd.dance;
      if (m.cmd.dj) djCmd(m.cmd.dj);
      if (m.cmd.event) startEvent(m.cmd.event.kind);
      if (m.cmd.quality && m.cmd.quality !== qName) { const u = new URL(location.href); u.searchParams.set("q", m.cmd.quality); location.replace(u); }
    }
  },
});

// ---------- câmera manual: arrastar / pinçar / roda ----------
const ptrs = new Map(); let pinch = 0;
canvas.addEventListener("pointerdown", (e) => { canvas.setPointerCapture?.(e.pointerId); ptrs.set(e.pointerId, [e.clientX, e.clientY]); });
canvas.addEventListener("pointermove", (e) => {
  const p = ptrs.get(e.pointerId); if (!p) return;
  if (ptrs.size === 1) director.drag(e.clientX - p[0], e.clientY - p[1]);
  p[0] = e.clientX; p[1] = e.clientY;
  if (ptrs.size === 2) { const [a, b] = [...ptrs.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]); if (pinch) director.zoom(pinch / d); pinch = d; }
});
const up = (e) => { ptrs.delete(e.pointerId); pinch = 0; };
canvas.addEventListener("pointerup", up); canvas.addEventListener("pointercancel", up);
canvas.addEventListener("wheel", (e) => { e.preventDefault(); director.zoom(e.deltaY > 0 ? 1.08 : 0.92); }, { passive: false });
canvas.addEventListener("dblclick", () => director.setMode("auto"));

// ---------- loop ----------
let last = performance.now() / 1000, ledAt = 0, idleAt = 0, slow = 0, fAvg = 0.016, okT = 0, evAt = 0, fpsAcc = 0, fpsN = 0;
const dbg = $("debug"); if (DEBUG) dbg.hidden = false;
const OMEGA_B = (Math.PI * 118) / 60, clock = { dT: 0, bpm: 118, last: 0, armed: true, ema: 0.508 };
function tickClock(t, dt, a, hasAudio) {   // tempo de dança: acompanha o BPM da música e trava na batida (sem áudio: 118 BPM)
  if (hasAudio) {
    if (a.pulse > 0.5) {
      if (clock.armed && t - clock.last > 0.27) {
        const iv = t - clock.last; if (iv < 1.1) { clock.ema = clock.ema * 0.85 + iv * 0.15; clock.bpm = Math.min(180, Math.max(80, 60 / clock.ema)); }
        clock.last = t; clock.armed = false; const ph = clock.dT * OMEGA_B, err = ph - Math.round(ph / Math.PI) * Math.PI; clock.dT -= (err * 0.25) / OMEGA_B;
      }
    } else if (a.pulse < 0.25) clock.armed = true;
  } else clock.bpm += (118 - clock.bpm) * Math.min(1, dt);
  clock.dT += (dt * clock.bpm) / 118;
}
function frame(now) {
  requestAnimationFrame(frame);
  const t = now / 1000, dt = Math.min(0.05, t - last); last = t;
  const hasAudio = audio.playing; let a;
  if (hasAudio) a = beat.update(audio.bass(), t, dt);
  else { const ph = (t % 0.508) / 0.508; a = { energy: 0.45, pulse: Math.max(0, 1 - ph * 5) * 0.55 }; }
  led.hasAudio = hasAudio; led.spectrum = audio.spectrum(24);
  world.update(t, dt, { ...a, spectrum: led.spectrum, hasAudio });
  { const ev = fxq.pop(performance.now()); if (ev) { const c = chars.get(ev.user?.id); if (c) onGift(c, ev); } }   // 1 efeito por vez
  tickClock(t, dt, a, hasAudio); const dT = clock.dT, ovr = eventDance || danceOverride;
  for (const c of chars.values()) c.update(dt, dT, a, ovr);
  for (let i = leaving.length - 1; i >= 0; i--) { leaving[i].update(dt, dT, a, ovr); if (leaving[i].done) { leaving[i].dispose(); leaving.splice(i, 1); } }
  if (t - idleAt > 1) { idleAt = t; const nowMs = performance.now(); for (const c of [...chars.values()]) if (!isActive(c.lastActive, nowMs, IDLE_MS)) { if (c.djMode) { dj.drop(c.id); syncDj(); } dj.leave(c.id); chars.delete(c.id); setSlot(c, -1); c.leave(); leaving.push(c); } }   // sem atividade real = saiu da arena
  director.update(dt, [...chars.values()]);
  effects.update(dt);
  if (t - evAt > 0.5) { evAt = t; tickEvents(); }
  if (t - ledAt > 0.08) { ledAt = t; led.now = performance.now(); led.event = events.view(performance.now()); world.drawLed(led, t); }
  renderer.render(scene, camera);
  fpsAcc += dt; fpsN++;
  // Qualidade adaptativa: FPS médio baixo → reduz resolução; FPS folgado por vários segundos → devolve aos poucos.
  fAvg += (dt - fAvg) * 0.05;
  if (fAvg > 0.026 && qScale > 0.55 && (okT = 0, ++slow > 45)) { qScale = Math.max(0.55, qScale - 0.1); slow = 0; resize(); }
  else if (fAvg < 0.019 && qScale < 1 && ++okT > 360) { qScale = Math.min(1, qScale + 0.05); okT = 0; resize(); }
  else if (fAvg <= 0.026) slow = 0;
  if (DEBUG && fpsAcc > 0.5) { dbg.textContent = `fps ${(fpsN / fpsAcc) | 0} · q=${qName} · pr=${pixelRatio} · chars ${chars.size} · modelos GLB ${templates.length} · áudio ${hasAudio ? "tocando" : audio.blocked ? "bloqueado" : "parado"} · bpm ${clock.bpm | 0} · qs ${qScale.toFixed(2)} · cam ${director.mode}`; fpsAcc = 0; fpsN = 0; }
}
requestAnimationFrame(frame);
window.__stage = { events, clock, dj, fxq, chars, director, scene, templates, led, rank, leaving };
