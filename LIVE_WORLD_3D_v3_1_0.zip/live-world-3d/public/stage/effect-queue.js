// Fila de efeitos de presentes: um efeito grande por vez (sem conflito), com tamanho máximo e deduplicação.
// Dados vêm só dos eventos reais já normalizados pelo servidor (usuário, giftId, giftName, count, total).
export class EffectQueue {
  constructor({ gapMs = 700, max = 24, dupMs = 0 } = {}) { Object.assign(this, { gapMs, max, dupMs }); this.items = []; this.next = 0; this.recent = new Map(); }
  /** Chave de deduplicação: o mesmo remetente + presente + quantidade + total dentro de dupMs é o MESMO evento repetido. */
  static key(ev) { return [ev.user?.id, ev.giftId, ev.giftName, ev.count, ev.total].join("|"); }
  push(ev, now) {
    const k = EffectQueue.key(ev), last = this.recent.get(k);   // o servidor já deduplica por msgId; dupMs>0 só se você quiser uma 2ª barreira
    if (this.dupMs > 0 && last !== undefined && now - last < this.dupMs) return false;
    this.recent.set(k, now); if (this.recent.size > 200) this.recent.delete(this.recent.keys().next().value);
    if (this.items.length >= this.max) this.items.shift();        // sobrecarga: descarta o mais antigo (o ranking já foi somado)
    this.items.push(ev); return true;
  }
  /** Devolve o próximo evento se já passou o intervalo; senão null. */
  pop(now) { if (!this.items.length || now < this.next) return null; this.next = now + this.gapMs; return this.items.shift(); }
  get size() { return this.items.length; }
}
