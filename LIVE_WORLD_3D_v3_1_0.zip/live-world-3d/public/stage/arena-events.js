// Eventos e desafios (lógica pura, sem THREE). Tudo é calculado só com presentes e comentários REAIS recebidos; sem participantes → o evento é cancelado.
export const EVENT_KINDS = { passinho: 60, batalha: 60, coletiva: 20, apoiador: 12, duplas: 25 };
export const EVENT_NAMES = { passinho: "DESAFIO DO PASSINHO", batalha: "BATALHA DE DANÇA", coletiva: "RODADA COLETIVA", apoiador: "DANÇA DO MAIOR APOIADOR", duplas: "RODADA DE DUPLAS" };

export class ArenaEvents {
  constructor() { this.cur = null; this.goal = { target: 0, cur: 0, round: 0 }; }
  setGoal(target) { if (target > 0 && !this.goal.target) this.goal = { target, cur: 0, round: 1 }; }
  start(kind, now, extra = {}) {
    if (!EVENT_KINDS[kind] || this.cur) return false;
    this.cur = { kind, name: EVENT_NAMES[kind], start: now, until: now + EVENT_KINDS[kind] * 1000, scores: new Map(), fighters: [], battleOn: false, ...extra }; return true;
  }
  /** Presente real: soma na pontuação do desafio/batalha e na meta. Retorna {goalReached} */
  gift(user, diamonds, now) {
    const e = this.cur, d = Math.max(0, Number(diamonds) || 0);
    if (e && now < e.until && d > 0) {
      if (e.kind === "passinho") this.#add(e, user, d);
      else if (e.kind === "batalha" && e.battleOn && e.fighters.some((f) => f.id === user.id)) this.#add(e, user, d);
    }
    const g = this.goal; let goalReached = false;
    if (g.target && d > 0) { g.cur += d; if (g.cur >= g.target) { goalReached = true; g.round++; g.cur -= g.target; g.target = Math.round(g.target * 1.6); } }
    return { goalReached };
  }
  #add(e, u, d) { const o = e.scores.get(u.id) || { id: u.id, name: u.name, total: 0 }; o.total += d; o.name = u.name; e.scores.set(u.id, o); }
  /** "!entrar" na batalha: os 2 primeiros usuários reais a comentar durante os primeiros 20 s. */
  chat(user, text, now) {
    const e = this.cur; if (!e || e.kind !== "batalha" || e.battleOn || e.fighters.length >= 2 || now > e.start + 20000) return null;
    if (!/^\s*!entrar\b/i.test(text || "") || e.fighters.some((f) => f.id === user.id)) return null;
    e.fighters.push({ id: user.id, name: user.name }); return e.fighters.length;
  }
  /** Chamada a cada ~0,5 s. Retorna ações: {do:"battleStart"|"end", ...} */
  tick(now) {
    const e = this.cur; if (!e) return null;
    if (e.kind === "batalha" && !e.battleOn && now >= e.start + 20000) {
      if (e.fighters.length < 2) { this.cur = null; return { do: "end", cancelled: true, kind: e.kind, why: "Faltaram lutadores (comente !entrar)" }; }
      e.battleOn = true; return { do: "battleStart", fighters: e.fighters };
    }
    if (now >= e.until) { this.cur = null; return { do: "end", kind: e.kind, result: this.#result(e) }; }
    return null;
  }
  cancel() { const e = this.cur; this.cur = null; return e; }
  #result(e) {
    const list = [...e.scores.values()].sort((a, b) => b.total - a.total);
    if (e.kind === "batalha") { const [a, b] = e.fighters.map((f) => e.scores.get(f.id)?.total || 0); if (a === b) return { tie: true, scores: e.fighters.map((f) => ({ ...f, total: e.scores.get(f.id)?.total || 0 })) }; const w = a > b ? e.fighters[0] : e.fighters[1]; return { winner: w, scores: [a, b] }; }
    return list.length ? { winner: list[0], top: list.slice(0, 3) } : { winner: null };
  }
  /** Para o telão. */
  view(now) {
    const e = this.cur, g = this.goal; if (!e && !g.target) return null;
    const v = { goal: g.target ? { cur: g.cur, target: g.target, round: g.round } : null };
    if (e) {
      v.title = e.name; v.left = Math.max(0, Math.ceil((e.until - now) / 1000));
      if (e.kind === "batalha") v.sub = e.battleOn ? e.fighters.map((f) => `${f.name.slice(0, 10)} ${e.scores.get(f.id)?.total || 0}💎`).join("  ×  ") : `Comente !entrar (${e.fighters.length}/2)`;
      else if (e.kind === "passinho") { const t = [...e.scores.values()].sort((a, b) => b.total - a.total)[0]; v.sub = t ? `Líder: ${t.name.slice(0, 14)} · ${t.total}💎` : "Mande presentes para ganhar a pista!"; }
      else if (e.kind === "coletiva") v.sub = "Todo mundo dançando junto!";
    }
    return v;
  }
}

/** Formata duplas: avatares vizinhos na mesma fileira (x próximo) viram pares. slots = [{id,x,z}]; retorna [[idA,idB],...]. */
export function makePairs(items, maxDist = 3.2) {
  const left = [...items].sort((a, b) => a.z - b.z || a.x - b.x), used = new Set(), out = [];
  for (const a of left) { if (used.has(a.id)) continue; const b = left.find((o) => o !== a && !used.has(o.id) && Math.hypot(o.x - a.x, o.z - a.z) <= maxDist); if (b) { used.add(a.id); used.add(b.id); out.push([a.id, b.id]); } }
  return out;
}

/** Combo: o mesmo usuário enviando presentes em sequência (janela de 9 s). */
export class ComboTracker {
  constructor(windowMs = 9000) { this.w = windowMs; this.m = new Map(); }
  hit(id, now, count = 1) { const o = this.m.get(id); const n = o && now - o.at < this.w ? o.n + Math.max(1, count) : Math.max(1, count); this.m.set(id, { n, at: now }); if (this.m.size > 300) this.m.delete(this.m.keys().next().value); return n; }
}
