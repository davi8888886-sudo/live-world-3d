// Poses de dança como funções puras (sem THREE): fáceis de testar e de ajustar.
// Ângulos em radianos. Chaves: hy=altura do quadril, hrz/hry=quadril, sx/sz=tronco, hdx/hdz=cabeça,
// alx/alz,arx/arz=braço esq./dir. (x=para frente, z=para o lado), flx/frx=cotovelo,
// tlx/tlz,trx/trz=coxa, slx/srx=joelho (dobra).
export const POSE_KEYS = ["hx", "hy", "hrz", "hry", "sx", "sz", "hdx", "hdz", "alx", "alz", "arx", "arz", "flx", "frx", "tlx", "tlz", "trx", "trz", "slx", "srx"];
export const zeroPose = () => Object.fromEntries(POSE_KEYS.map((k) => [k, 0]));
export const DANCE_IDS = ["groove", "bounce", "samba", "hiphop", "passinho", "funk", "disco", "swag"];   // rotação automática (registerDance acrescenta)
export const LIBRARY = [];                          // catálogo: {id, name, category, source, verified, group?}
export const SPECIAL_IDS = ["celebrate", "spin", "wave", "flex"];
const s = Math.sin, c = Math.cos, PI = Math.PI;
const bend = (b) => ({ hy: -0.07 * b, tlx: 0.28 * b, trx: 0.28 * b, slx: 0.55 * b, srx: 0.55 * b });
const sm = (x) => x * x * (3 - 2 * x);          // transição suave 0..1
const down = (p) => 0.5 + 0.5 * c(2 * p);        // 1 = "descendo" na batida, 0 = em cima
const pos = (x) => Math.max(0, x);

// p = fase (2π = 2 batidas); e = energia 0..1 (amplitude)
// Princípios: peso do corpo alterna de lado, joelhos dobram na batida, ombros giram contra o quadril,
// cotovelos e cabeça atrasam um pouco (movimento "solto", menos robótico).
const D = {
  idle: (p) => ({ sx: 0.02 * s(p / 2), hdx: 0.02 * s(p / 3), alz: 0.12, arz: 0.12, flx: 0.15, frx: 0.15 }),
  // Balanço leve: passo para o lado, quadril e ombros em oposição, braços soltos.
  groove: (p, e) => { const a = 0.65 + 0.35 * e, k = down(p) * 0.7 * a; return { ...bend(k), hrz: 0.08 * s(p) * a, hry: 0.28 * s(p) * a, sz: -0.06 * s(p) * a, sx: 0.03 * c(2 * p) * a, hdz: 0.07 * s(p + 0.7), hdx: 0.05 * c(2 * p) * a, tlz: 0.1 * pos(s(p)), trz: 0.1 * pos(-s(p)), alx: 0.3 * s(p) * a, arx: -0.3 * s(p) * a, alz: 0.28 + 0.12 * c(2 * p) * a, arz: 0.28 + 0.12 * c(2 * p) * a, flx: 0.6 + 0.25 * s(p + 0.5), frx: 0.6 + 0.25 * s(p + PI + 0.5) }; },
  // Pulinho com os dois braços bombeando junto, como corrida no lugar.
  bounce: (p, e) => { const a = 0.7 + 0.3 * e, k = down(p) * 1.1 * a; return { ...bend(k), sx: 0.07 * c(2 * p) * a, hdx: 0.1 * c(2 * p), hrz: 0.03 * s(p), alx: 0.45 + 0.4 * s(2 * p + 0.6) * a, arx: 0.45 + 0.4 * s(2 * p + 0.6) * a, alz: 0.22, arz: 0.22, flx: 1.1 + 0.4 * s(2 * p + 1.2), frx: 1.1 + 0.4 * s(2 * p + 1.2) }; },
  // Samba: quadril desenha um 8, pés alternam rápido, braços abertos.
  samba: (p, e) => { const a = 0.6 + 0.4 * e; return { hy: -0.03 + 0.015 * s(4 * p), hrz: 0.15 * s(p) * a, hry: 0.22 * c(p) * a, sz: -0.09 * s(p) * a, tlx: 0.4 * s(p) * a, trx: -0.4 * s(p) * a, slx: pos(-s(p)) * 0.65 * a, srx: pos(s(p)) * 0.65 * a, alx: -0.35 * s(p) * a, arx: 0.35 * s(p) * a, alz: 0.55 + 0.15 * s(p), arz: 0.55 - 0.15 * s(p), flx: 0.45, frx: 0.45, hdz: 0.1 * s(p), hdx: 0.04 * c(2 * p) }; },
  // Hip-hop: base aberta, peito "pulsando", braços alternando na altura do peito, cabeça marcando a batida.
  hiphop: (p, e) => { const a = 0.7 + 0.3 * e, k = 0.5 + 0.5 * s(p), b = down(p) * 1.0 * a; return { ...bend(b), tlz: 0.12, trz: 0.12, sx: 0.1 + 0.1 * c(2 * p) * a, hdx: 0.14 * c(2 * p) - 0.04, hry: 0.3 * s(p) * a, hrz: 0.05 * s(p), sz: -0.05 * s(p), alx: 0.35, arx: 0.35, alz: 0.4 + 0.7 * k * a, arz: 0.4 + 0.7 * (1 - k) * a, flx: 1.1 - 0.5 * k, frx: 0.6 + 0.5 * k }; },
  // Passinho (funk carioca): pés rápidos alternando, joelhos soltos, braços pendulando.
  passinho: (p, e) => { const a = 0.6 + 0.4 * e, q = 2 * p; return { hy: -0.04 + 0.025 * Math.abs(s(q)), hrz: 0.12 * s(q), hry: 0.15 * s(q), sx: 0.1, tlx: 0.3 * pos(s(q)) * a, trx: 0.3 * pos(-s(q)) * a, tlz: 0.2 * pos(s(q)) * a, trz: 0.2 * pos(-s(q)) * a, slx: 0.6 * pos(s(q)) * a, srx: 0.6 * pos(-s(q)) * a, alx: 0.55 * s(q) * a, arx: -0.55 * s(q) * a, alz: 0.3, arz: 0.3, flx: 0.9, frx: 0.9, sz: -0.07 * s(q), hdz: 0.08 * s(q) }; },
  // Funk: agachadinho com balanço de quadril e braços soltos de um lado para o outro.
  funk: (p, e) => { const a = 0.65 + 0.35 * e, b = 1.0 + 0.5 * down(p) * a; return { ...bend(b), tlz: 0.15, trz: 0.15, sx: 0.22 + 0.05 * c(2 * p), hdx: -0.2, hrz: 0.1 * s(p) * a, hry: 0.35 * s(p) * a, sz: -0.08 * s(p), alx: 0.45 + 0.1 * c(2 * p), arx: 0.45 + 0.1 * c(2 * p), alz: 0.35 + 0.25 * s(p) * a, arz: 0.35 - 0.25 * s(p) * a, flx: 0.35, frx: 0.35, hdz: 0.08 * s(p + 0.5) }; },
  // Disco: braço aponta para o alto na diagonal, alternando a cada batida dupla.
  disco: (p, e) => { const a = 0.7 + 0.3 * e, L = sm(0.5 + 0.5 * s(p)), R = 1 - L; return { ...bend(down(p) * 0.5 * a), hrz: 0.09 * s(p) * a, hry: 0.2 * s(p) * a, sz: -0.1 * s(p) * a, tlz: 0.1 * pos(s(p)), trz: 0.1 * pos(-s(p)), alz: 0.2 + 2.0 * L * a, arz: 0.2 + 2.0 * R * a, alx: 0.3 * L, arx: 0.3 * R, flx: 0.45 - 0.2 * L, frx: 0.45 - 0.2 * R, hdz: -0.1 * s(p), hdx: -0.05 }; },
  // Swag: balanço "de boa", mãos perto dos bolsos, cabeça acenando no ritmo, ombros alternando.
  swag: (p, e) => { const a = 0.65 + 0.35 * e; return { ...bend(down(p) * 0.55 * a), tlz: 0.08, trz: 0.08, hrz: 0.06 * s(p) * a, hry: 0.2 * s(p) * a, sz: -0.06 * s(p) * a, sx: -0.03, hdx: 0.1 * c(2 * p) * a, hdz: 0.06 * s(p + 0.6), alx: 0.12 + 0.1 * s(p) * a, arx: 0.12 - 0.1 * s(p) * a, alz: 0.3, arz: 0.3, flx: 1.0 + 0.12 * c(2 * p) * a, frx: 1.0 + 0.12 * c(2 * p + 1) * a }; },
  // Flex (presentes grandes): braços dobrados mostrando força, pulinhos e peito aberto.
  flex: (p, e) => { const j = Math.abs(s(1.5 * p)), a = 0.8 + 0.2 * e; return { hy: 0.08 * j * a, ...bend(0.35 * (1 - j)), alz: 1.5, arz: 1.5, alx: -0.1, arx: -0.1, flx: 2.0 + 0.15 * s(3 * p), frx: 2.0 + 0.15 * s(3 * p + 1), sx: -0.06, hdx: -0.12, hdz: 0.08 * s(p), sz: 0.04 * s(2 * p) }; },
  wave: (p) => ({ hrz: 0.04 * s(p), sz: 0.03 * s(p), arz: 2.5 + 0.1 * s(2 * p), arx: 0.1, frx: 0.35 + 0.6 * s(6 * p), alz: 0.15, flx: 0.3, hdz: 0.12, hdx: -0.05 }),
  celebrate: (p, e) => { const j = Math.abs(s(1.5 * p)), a = 0.8 + 0.2 * e; return { hy: 0.14 * j * a, ...bend(0.5 * (1 - j)), alz: 2.7 + 0.2 * s(4 * p), arz: 2.7 + 0.2 * s(4 * p + 1), alx: -0.1, arx: -0.1, flx: 0.15, frx: 0.15, hdx: -0.15, sx: -0.05 }; },
  spin: (p) => ({ hry: p * 0.6, hy: 0.02 * Math.abs(s(2 * p)), alz: 1.45, arz: 1.45, flx: 0.15, frx: 0.15, sx: 0.04, hdx: -0.05 }),
};
/** Biblioteca extensível: adicione uma dança sem tocar no resto do sistema.
 *  meta = {id, name, category, source, verified, desc, group?: "sync"|"wave", auto?: true}; fn(p, e) -> pose parcial. */
export function registerDance(meta, fn) {
  if (!meta?.id || typeof fn !== "function") throw new Error("registerDance: id e função são obrigatórios");
  D[meta.id] = fn; const i = LIBRARY.findIndex((m) => m.id === meta.id); if (i >= 0) LIBRARY[i] = meta; else LIBRARY.push(meta);
  if (meta.auto !== false && meta.category !== "especiais" && !DANCE_IDS.includes(meta.id)) DANCE_IDS.push(meta.id);
}
export const danceMeta = (id) => LIBRARY.find((m) => m.id === id) || null;
/** Ficha da dança: duração de um ciclo (s, a 118 BPM), intensidade 1-3, tempo (1 normal, 2 acelerado). */
export const danceInfo = (id) => { const m = danceMeta(id); return m ? { ...m, durationSec: +((m.beats || 4) * 60 / 118 / (m.tempo || 1)).toFixed(1), intensity: m.intensity || 2 } : null; };
export function dancePose(id, p, e = 0.5) {
  const f = D[id] || D.groove;
  return { ...zeroPose(), ...f(p, Math.min(1, Math.max(0, e))) };
}
export function walkPose(phase) {
  const k = s(phase);
  return { ...zeroPose(), hy: -0.015 + 0.025 * Math.abs(c(phase)), tlx: 0.55 * k, trx: -0.55 * k, slx: 0.1 + 0.6 * Math.max(0, -s(phase + 0.9)), srx: 0.1 + 0.6 * Math.max(0, s(phase + 0.9)), alx: -0.45 * k, arx: 0.45 * k, alz: 0.1, arz: 0.1, flx: 0.25, frx: 0.25, sx: 0.04, hry: 0.06 * k };
}
export function pickDance(id, i) { const n = (Number(String(id).split("").reduce((a, ch) => (a * 31 + ch.charCodeAt(0)) >>> 0, 7)) + i) % DANCE_IDS.length; return DANCE_IDS[n]; }

const base = [
  ["groove", "Groove", "individuais"], ["bounce", "Pulinho", "individuais"], ["samba", "Samba no pé", "individuais"], ["hiphop", "Hip-hop", "individuais"],
  ["swag", "Swag", "individuais"], ["disco", "Disco", "individuais"], ["passinho", "Passinho de funk", "passinhos"], ["funk", "Funk agachadinho", "funk"],
  ["celebrate", "Comemoração", "especiais"], ["spin", "Giro", "especiais"], ["wave", "Aceno", "especiais"], ["flex", "Flex", "especiais"],
];
for (const [id, name, category] of base) LIBRARY.push({ id, name, category, source: "própria (v2)", verified: false, desc: "Coreografia procedural própria do projeto.", auto: category !== "especiais" });
