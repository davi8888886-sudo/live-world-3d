// Regras da arena: vagas, ranking real e inatividade. Nada aqui simula pessoas.
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { makeSlots, addGift, topSupporters, isActive, parseIdle, fmtNum, FLOOR } from "../public/stage/arena-rules.js";

test("vagas: únicas, dentro da pista, com espaço entre avatares, centro primeiro", () => {
  const s = makeSlots(56); assert.equal(s.length, 56);
  let min = 99; for (let i = 0; i < s.length; i++) for (let j = i + 1; j < s.length; j++) min = Math.min(min, Math.hypot(s[i][0] - s[j][0], s[i][1] - s[j][1]));
  assert.ok(min >= 1.5, "espaço mínimo " + min);
  for (const [x, z] of s) { assert.ok(Math.abs(x) < FLOOR.w / 2 - 1.5); assert.ok(Math.abs(z - FLOOR.cz) < FLOOR.d / 2 - 1.5); }
  assert.ok(Math.hypot(s[0][0], s[0][1]) < Math.hypot(s[55][0], s[55][1]), "primeiras vagas ficam no centro");
});
test("ranking: soma só diamantes reais; sem presente = vazio; top 5 ordenado", () => {
  const r = new Map(); assert.deepEqual(topSupporters(r), []);
  addGift(r, { id: "a", name: "Ana" }, 0); addGift(r, { id: "b", name: "Bia" }, -5); addGift(r, null, 10);
  assert.deepEqual(topSupporters(r), [], "presente de 0 diamantes ou sem usuário não conta");
  for (const [id, n, v] of [["a", "Ana", 100], ["b", "Bia", 300], ["a", "Ana", 250], ["c", "Caio", 10], ["d", "Duda", 20], ["e", "Edu", 30], ["f", "Fábio", 40]]) addGift(r, { id, name: n }, v);
  const top = topSupporters(r, 5); assert.equal(top.length, 5);
  assert.deepEqual(top.map((t) => [t.name, t.total]), [["Ana", 350], ["Bia", 300], ["Fábio", 40], ["Edu", 30], ["Duda", 20]]);
});
test("atividade/inatividade e formato de números", () => {
  assert.ok(isActive(1000, 1000 + 299000, 300000)); assert.ok(!isActive(1000, 1000 + 301000, 300000));
  assert.equal(parseIdle("60"), 60); assert.equal(parseIdle("1"), 300); assert.equal(parseIdle(null), 300); assert.equal(parseIdle("abc"), 300);
  assert.equal(fmtNum(950), "950"); assert.equal(fmtNum(12500), "12.5K"); assert.equal(fmtNum(2500000), "2.5M");
});
test("o cenário não cria multidão/silhueta/bot (análise estática)", () => {
  const w = fs.readFileSync(new URL("../public/stage/world.js", import.meta.url), "utf8"), e = fs.readFileSync(new URL("../public/stage/engine.js", import.meta.url), "utf8");
  assert.ok(!/InstancedMesh|CapsuleGeometry|crowd|plateia/i.test(w.replace(/^\s*\/\/.*$/gm, "")), "world.js não pode desenhar pessoas");
  assert.ok(!/Math\.random\(\)[^;]*spawn|spawn\([^)]*(fake|bot|npc)/i.test(e), "engine.js só cria avatar a partir de eventos");
  assert.equal((e.match(/\bspawn\(/g) || []).length, 4, "spawn só em: definição, onEvent (evento real), hello (usuários reais recentes) e djEnter (usuário real escolhido como DJ)");
});

import { DjQueue, isDjCommand } from "../public/stage/dj-queue.js";
import { EffectQueue } from "../public/stage/effect-queue.js";
import "../public/stage/dance-library.js";
import { LIBRARY, DANCE_IDS, dancePose, POSE_KEYS, danceMeta } from "../public/stage/dances.js";
import { CATEGORIES } from "../public/stage/dance-library.js";

test("arena v3: pista gigante e 96 vagas únicas dentro da pista", () => {
  assert.ok(FLOOR.w >= 40 && FLOOR.d >= 28);
  const s = makeSlots(96); assert.equal(s.length, 96);
  for (const [x, z] of s) { assert.ok(Math.abs(x) < FLOOR.w / 2 - 1.5); assert.ok(Math.abs(z - FLOOR.cz) < FLOOR.d / 2 - 1.5); }
  assert.equal(new Set(s.map((p) => p.join())).size, 96);
});
test("fila de DJ: só entra quem pede, um ativo por vez, troca e liberação", () => {
  const q = new DjQueue(); assert.deepEqual(q.snapshot(), { active: null, queue: [] });
  assert.ok(q.join({ id: "a", name: "Ana" })); assert.ok(!q.join({ id: "a", name: "Ana" })); q.join({ id: "b", name: "Bia" });
  let r = q.select(); assert.equal(r.active.id, "a"); assert.equal(r.previous, null);
  assert.ok(!q.join({ id: "a", name: "Ana" }), "DJ ativo não volta à fila");
  r = q.select("b"); assert.equal(r.active.id, "b"); assert.equal(r.previous.id, "a");
  assert.equal(q.select(), null); assert.equal(q.release().id, "b"); assert.equal(q.snapshot().active, null);
  assert.ok(isDjCommand("!DJ") && isDjCommand(" !dj por favor") && !isDjCommand("quero ser dj"));
});
test("fila de efeitos: duplicado ignorado, um por vez, limite de tamanho", () => {
  const q = new EffectQueue({ gapMs: 500, max: 3, dupMs: 1000 }), ev = (n, id = "g1") => ({ user: { id: "u" }, giftId: id, giftName: "Rose", count: 1, total: n });
  assert.ok(q.push(ev(1), 0)); assert.ok(!q.push(ev(1), 100), "mesmo evento repetido");
  assert.ok(q.push(ev(2), 200)); assert.ok(q.push(ev(3), 300)); assert.ok(q.push(ev(4), 400)); assert.equal(q.size, 3, "limite");
  assert.equal(q.pop(1000).total, 2); assert.equal(q.pop(1200), null, "intervalo entre efeitos"); assert.equal(q.pop(1600).total, 3);
});
test("biblioteca de danças: Jamal + 3 trends, categorias válidas, poses finitas", () => {
  for (const id of ["jamal", "bombaye", "vini", "quicando"]) assert.ok(danceMeta(id), id);
  assert.equal(danceMeta("jamal").verified, true);
  const cats = new Set(CATEGORIES.map((c) => c.id)); assert.equal(cats.size, 6);
  for (const m of LIBRARY) { assert.ok(cats.has(m.category), m.id + " categoria"); assert.ok(m.name); for (let p = 0; p < 40; p += 0.31) { const P = dancePose(m.id, p, 0.7); for (const k of POSE_KEYS) assert.ok(Number.isFinite(P[k]), m.id + k); } }
  assert.ok(DANCE_IDS.includes("jamal"));
});

import { ArenaEvents, ComboTracker, makePairs } from "../public/stage/arena-events.js";
test("eventos: desafio só pontua presentes reais; vencedor = quem mais apoiou; sem presentes = sem vencedor", () => {
  const E = new ArenaEvents(); assert.ok(E.start("passinho", 0)); assert.ok(!E.start("coletiva", 1), "um evento por vez");
  E.gift({ id: "a", name: "Ana" }, 10, 1000); E.gift({ id: "b", name: "Bia" }, 30, 2000); E.gift({ id: "a", name: "Ana" }, 5, 3000);
  const r = E.tick(61000); assert.equal(r.do, "end"); assert.equal(r.result.winner.id, "b");
  E.start("passinho", 0); assert.equal(E.tick(61000).result.winner, null);
});
test("batalha: 2 lutadores reais via !entrar; sem eles cancela; só lutadores pontuam", () => {
  const E = new ArenaEvents(); E.start("batalha", 0);
  assert.equal(E.chat({ id: "a", name: "A" }, "!entrar", 1000), 1); assert.equal(E.chat({ id: "a", name: "A" }, "!entrar", 1100), null);
  assert.equal(E.chat({ id: "b", name: "B" }, "!ENTRAR", 2000), 2); assert.equal(E.chat({ id: "c", name: "C" }, "!entrar", 2500), null);
  assert.equal(E.tick(20500).do, "battleStart"); E.gift({ id: "a" , name: "A" }, 7, 21000); E.gift({ id: "c", name: "C" }, 99, 22000);
  const r = E.tick(61000); assert.equal(r.result.winner.id, "a");
  const F = new ArenaEvents(); F.start("batalha", 0); const c = F.tick(20500); assert.ok(c.cancelled);
});
test("meta de presentes: soma só diamantes reais, sobe a meta e emparelha duplas vizinhas", () => {
  const E = new ArenaEvents(); E.setGoal(100); assert.ok(!E.gift({ id: "a" }, 60, 0).goalReached); assert.ok(E.gift({ id: "b" }, 50, 1).goalReached);
  assert.equal(E.goal.target, 160); assert.equal(E.goal.cur, 10); assert.ok(!E.gift({ id: "a" }, 0, 2).goalReached);
  const p = makePairs([{ id: "1", x: 0, z: 0 }, { id: "2", x: 2, z: 0 }, { id: "3", x: 30, z: 0 }]); assert.deepEqual(p, [["1", "2"]]);
  const C = new ComboTracker(1000); assert.equal(C.hit("u", 0), 1); assert.equal(C.hit("u", 500), 2); assert.equal(C.hit("u", 2000), 1);
});
