// Cenário de show (v2.3): palco com piso de LED, telão gigante com pixels de LED e vários "programas" animados,
// arcos neon, treliça com moving heads (com poças de luz no palco), lasers, plateia, névoa e estrelas.
// Efeitos reagem à batida da música e aos eventos da LIVE via world.hype(). Itens decorativos novos ficam em safe():
// se um deles falhar, o palco continua funcionando sem ele.
import * as THREE from "three";
export const STAGE_Y = 0.4;
export const STAGE = { w: 9, d: 6.2 };
const WALL_W = 8.6, WALL_H = 5.4, WALL_Y = 4.45, WALL_Z = -3.0, TRUSS_Y = 8.3;

const safe = (name, fn) => { try { return fn(); } catch (e) { console.warn("cenário (item ignorado):", name, e); return null; } };
function canvasTex(w, h) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const x = c.getContext("2d"); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  return { c, x, t, w, h };
}
const rng = (seed) => () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const hsl = (h, s, l, a = 1) => `hsla(${(((h % 360) + 360) % 360).toFixed(0)},${s}%,${l}%,${a})`;
const rrect = (x, px, py, w, h, r) => { x.beginPath(); if (x.roundRect) x.roundRect(px, py, w, h, r); else x.rect(px, py, w, h); };

// ---------- telão: programas de fundo ----------
const MODES = ["waves", "tunnel", "synth", "bars"];
function paintMode(mode, x, w, h, t, s) {
  const hue = (t * 14) % 360, p = s.pulse || 0, e = s.energy || 0.4;
  if (mode === "waves") {
    for (let k = 0; k < 5; k++) {
      x.beginPath(); x.moveTo(0, h);
      for (let i = 0; i <= w; i += 16) x.lineTo(i, h * (0.46 + 0.075 * k) + Math.sin(i * 0.011 + t * (0.7 + k * 0.28) + k * 1.3) * h * (0.04 + 0.03 * e + 0.035 * p));
      x.lineTo(w, h); x.closePath(); x.fillStyle = hsl(hue + k * 38 + 180, 90, 52, 0.16 + 0.05 * k); x.fill();
    }
    x.globalCompositeOperation = "lighter";
    for (let k = 0; k < 3; k++) { const r = h * (0.18 + 0.12 * k) * (1 + 0.1 * p); const g = x.createRadialGradient(w * (0.2 + 0.3 * k), h * 0.3, 0, w * (0.2 + 0.3 * k), h * 0.3, r); g.addColorStop(0, hsl(hue + k * 90, 100, 60, 0.35)); g.addColorStop(1, hsl(hue + k * 90, 100, 60, 0)); x.fillStyle = g; x.fillRect(0, 0, w, h); }
    x.globalCompositeOperation = "source-over";
  } else if (mode === "tunnel") {
    const cx = w / 2, cy = h * 0.5; x.lineJoin = "round";
    for (let i = 0; i < 16; i++) {
      const z = ((i + t * 0.9) % 16) / 16, k = z * z * 1.25 + 0.015, rw = w * k, rh = h * k;
      x.lineWidth = 2 + 9 * z; x.strokeStyle = hsl(hue + i * 22, 100, 55, Math.min(1, z * 1.6) * (0.55 + 0.4 * p)); x.strokeRect(cx - rw / 2, cy - rh / 2, rw, rh);
    }
    x.strokeStyle = hsl(hue + 200, 100, 70, 0.25); x.lineWidth = 2;
    for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2 + t * 0.15; x.beginPath(); x.moveTo(cx, cy); x.lineTo(cx + Math.cos(a) * w, cy + Math.sin(a) * w); x.stroke(); }
  } else if (mode === "synth") {
    const hz = h * 0.56, g = x.createLinearGradient(0, hz - h * 0.3, 0, hz); g.addColorStop(0, hsl(hue + 300, 100, 60, 0.95)); g.addColorStop(1, hsl(hue + 340, 100, 55, 0.95));
    x.fillStyle = g; x.beginPath(); x.arc(w / 2, hz, h * (0.27 + 0.02 * p), Math.PI, 0); x.fill();
    x.fillStyle = "rgba(6,4,24,.92)"; x.fillRect(0, hz, w, h - hz);
    x.strokeStyle = hsl(hue + 190, 100, 60, 0.8); x.lineWidth = 2;
    for (let i = -14; i <= 14; i++) { x.beginPath(); x.moveTo(w / 2 + i * 14, hz); x.lineTo(w / 2 + i * 120, h); x.stroke(); }
    for (let i = 0; i < 9; i++) { const z = ((i + t * 0.6) % 9) / 9, y = hz + (h - hz) * z * z; x.beginPath(); x.moveTo(0, y); x.lineTo(w, y); x.stroke(); }
  } else {
    const n = s.spectrum.length, bw = w / n;
    for (let i = 0; i < n; i++) {
      const v = s.hasAudio ? Math.max(0.05, s.spectrum[i]) : 0.14 + 0.1 * Math.sin(t * 2.4 + i * 0.55) + 0.1 * p, bh = v * h * 0.62;
      const g = x.createLinearGradient(0, h - bh, 0, h); g.addColorStop(0, hsl(hue + i * 10, 100, 62)); g.addColorStop(1, hsl(hue + i * 10 + 60, 100, 40));
      x.fillStyle = g; rrect(x, i * bw + 5, h - bh, bw - 10, bh, 8); x.fill();
      x.fillStyle = "rgba(255,255,255,.85)"; x.fillRect(i * bw + 5, h - bh - 8, bw - 10, 4);
    }
  }
}

/** Desenha o telão. s = {spectrum, hasAudio, username, status, viewers, gifts, likes, ticker, alert, join, now, pulse, energy, flash} */
export function drawLed(L, s, t) {
  const { x, w, h } = L, hue = (t * 14) % 360, k = w / 1024;
  if (L.mode === undefined) { L.mode = 0; L.prev = 0; L.mix = 1; L.at = t; L.last = t; }
  const dt = Math.min(0.5, Math.max(0, t - L.last)); L.last = t;
  if (t - L.at > 16) { L.prev = L.mode; L.mode = (L.mode + 1) % MODES.length; L.mix = 0; L.at = t; }
  L.mix = Math.min(1, L.mix + dt / 1.3);

  const bg = x.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, hsl(hue + 240, 70, 9)); bg.addColorStop(1, hsl(hue + 300, 75, 5));
  x.fillStyle = bg; x.fillRect(0, 0, w, h);
  if (L.mix < 1) { paintMode(MODES[L.prev], x, w, h, t, s); x.globalAlpha = L.mix; }
  paintMode(MODES[L.mode], x, w, h, t, s); x.globalAlpha = 1;
  // escurece a parte de baixo: os personagens ficam na frente dela e precisam de contraste
  const vg = x.createLinearGradient(0, h * 0.45, 0, h); vg.addColorStop(0, "rgba(0,0,10,0)"); vg.addColorStop(1, "rgba(0,0,10,.62)"); x.fillStyle = vg; x.fillRect(0, h * 0.45, w, h * 0.55);

  // cabeçalho
  const hb = x.createLinearGradient(0, 0, 0, 130 * k); hb.addColorStop(0, "rgba(0,0,14,.7)"); hb.addColorStop(1, "rgba(0,0,14,0)"); x.fillStyle = hb; x.fillRect(0, 0, w, 130 * k);
  x.textBaseline = "alphabetic"; x.textAlign = "left";
  const tg = x.createLinearGradient(30 * k, 0, 470 * k, 0); tg.addColorStop(0, "#35d6ff"); tg.addColorStop(0.55, "#ffffff"); tg.addColorStop(1, "#ff2d95");
  x.shadowColor = hsl(hue + 300, 100, 60, 0.9); x.shadowBlur = 16 * k; x.fillStyle = tg; x.font = `900 ${58 * k}px system-ui, sans-serif`; x.fillText("LIVE WORLD 3D", 32 * k, 70 * k);
  x.shadowBlur = 0; x.font = `700 ${27 * k}px system-ui, sans-serif`; x.fillStyle = s.status === "CONECTADO" ? "#7dffb2" : "#9ff5e6";
  x.fillText(s.username ? `● @${s.username} · ${s.status}` : `● ${s.status}`, 34 * k, 108 * k);
  // estatísticas
  x.font = `800 ${28 * k}px system-ui, sans-serif`; let cx = w - 26 * k;
  for (const [ic, v] of [["❤", s.likes], ["🎁", s.gifts], ["👥", s.viewers]]) {
    const txt = `${ic} ${v}`, tw = x.measureText(txt).width + 28 * k; cx -= tw;
    rrect(x, cx, 26 * k, tw, 48 * k, 24 * k); x.fillStyle = "rgba(0,0,20,.55)"; x.fill(); x.strokeStyle = hsl(hue + 180, 100, 65, 0.8); x.lineWidth = 2; x.stroke();
    x.fillStyle = "#fff"; x.fillText(txt, cx + 14 * k, 60 * k); cx -= 10 * k;
  }
  // últimas mensagens
  const lines = s.ticker.slice(-3);
  x.font = `600 ${24 * k}px system-ui, sans-serif`;
  lines.forEach((line, i) => {
    const txt = line.length > 38 ? line.slice(0, 37) + "…" : line, tw = Math.min(w * 0.7, x.measureText(txt).width + 30 * k), y = 150 * k + i * 44 * k, last = i === lines.length - 1;
    rrect(x, 30 * k, y - 28 * k, tw, 38 * k, 19 * k); x.fillStyle = last ? "rgba(0,0,20,.62)" : "rgba(0,0,20,.4)"; x.fill();
    x.fillStyle = last ? "#fff" : "#b8c2e0"; x.fillText(txt, 44 * k, y);
  });
  // quem acabou de entrar
  if (s.join && s.now < s.join.until) {
    const age = Math.min(1, (s.join.until - s.now) / 3200), slide = Math.min(1, (1 - age) * 6) * (age < 0.15 ? age / 0.15 : 1);
    const txt = `👋 ${s.join.text.slice(0, 22)} entrou!`; x.font = `800 ${28 * k}px system-ui, sans-serif`;
    const tw = x.measureText(txt).width + 40 * k, px = w - tw - 26 * k + (1 - slide) * (tw + 40 * k);
    rrect(x, px, 92 * k, tw, 46 * k, 23 * k); x.fillStyle = hsl(hue + 120, 90, 45, 0.9); x.fill(); x.fillStyle = "#fff"; x.fillText(txt, px + 20 * k, 125 * k);
  }
  // alerta de presente
  if (s.alert && s.now < s.alert.until) {
    const age = Math.min(1, Math.max(0, 1 - (s.alert.until - s.now) / 4500)), pop = 1 + 0.05 * Math.sin(t * 14) + (age < 0.1 ? (0.1 - age) * 3 : 0);
    x.globalCompositeOperation = "lighter"; x.lineWidth = 10 * k * (1 - age); x.strokeStyle = hsl(hue + 40, 100, 65, 0.9 * (1 - age));
    x.beginPath(); x.arc(w / 2, h * 0.36, age * w * 0.6, 0, Math.PI * 2); x.stroke(); x.globalCompositeOperation = "source-over";
    x.save(); x.translate(w / 2, h * 0.36); x.scale(pop, pop);
    const bgr = x.createLinearGradient(-w * 0.45, 0, w * 0.45, 0); bgr.addColorStop(0, "rgba(255,45,149,.85)"); bgr.addColorStop(1, "rgba(53,214,255,.85)");
    rrect(x, -w * 0.45, -66 * k, w * 0.9, 132 * k, 30 * k); x.fillStyle = bgr; x.fill(); x.strokeStyle = "#fff"; x.lineWidth = 4; x.stroke();
    x.textAlign = "center"; x.fillStyle = "#fff"; x.shadowColor = "#000"; x.shadowBlur = 8; x.font = `900 ${50 * k}px system-ui, sans-serif`; x.fillText("🎁 " + s.alert.text.slice(0, 32), 0, 8 * k);
    x.font = `700 ${28 * k}px system-ui, sans-serif`; x.fillText(s.alert.sub || "", 0, 48 * k); x.shadowBlur = 0; x.restore();
  }
  // cantoneiras + flash
  x.strokeStyle = hsl(hue + 180, 100, 65, 0.9); x.lineWidth = 5; const m = 14, c = 46 * k;
  for (const [px, py, dx, dy] of [[m, m, 1, 1], [w - m, m, -1, 1], [m, h - m, 1, -1], [w - m, h - m, -1, -1]]) { x.beginPath(); x.moveTo(px, py + dy * c); x.lineTo(px, py); x.lineTo(px + dx * c, py); x.stroke(); }
  if (s.flash > 0.02) { x.fillStyle = `rgba(255,255,255,${(0.4 * s.flash).toFixed(3)})`; x.fillRect(0, 0, w, h); }
  L.t.needsUpdate = true;
}

export function buildWorld(scene, q) {
  scene.background = new THREE.Color(0x04050c);
  scene.fog = new THREE.FogExp2(0x05060f, 0.026);
  scene.add(new THREE.HemisphereLight(0x9fb4ff, 0x2a1647, 1.2));
  const key = new THREE.DirectionalLight(0xffffff, 1.45); key.position.set(2, 9, 10); key.target.position.set(0, 1, 0);
  scene.add(key, key.target);
  if (q >= 2) {
    key.castShadow = true; key.shadow.mapSize.set(1024, 1024);
    Object.assign(key.shadow.camera, { left: -6, right: 6, top: 6, bottom: -4, near: 1, far: 30 }); key.shadow.bias = -0.0005;
  }
  // Luz de contorno colorida por trás: separa os personagens do fundo.
  const rimA = new THREE.DirectionalLight(0xff3da0, 1.2), rimB = new THREE.DirectionalLight(0x35d6ff, 1.2);
  rimA.position.set(-6, 5, -7); rimB.position.set(6, 5, -7); scene.add(rimA, rimB);
  const washes = [0xff2d95, 0x35d6ff, 0xa66bff].map((c, i) => { const l = new THREE.PointLight(c, q ? 40 : 22, 16, 2); l.position.set((i - 1) * 3.6, 4.8, -1.2); scene.add(l); return l; });
  const H = { flash: 0, hue: 0 };   // "hype": reação a eventos da LIVE
  const A = { energy: 0.4, pulse: 0 };

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(80, 80), new THREE.MeshStandardMaterial({ color: 0x07080f, roughness: 0.5, metalness: 0.35 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

  // brilho radial reutilizado (poças de luz, derramamento no chão, névoa)
  const glow = canvasTex(128, 128), gg = glow.x.createRadialGradient(64, 64, 0, 64, 64, 64);
  gg.addColorStop(0, "rgba(255,255,255,.9)"); gg.addColorStop(0.45, "rgba(255,255,255,.35)"); gg.addColorStop(1, "rgba(255,255,255,0)"); glow.x.fillStyle = gg; glow.x.fillRect(0, 0, 128, 128); glow.t.needsUpdate = true;

  // palco com piso de LED animado (12 x 8 células)
  const fl = canvasTex(288, 192);
  const topMat = new THREE.MeshStandardMaterial({ color: 0x0b0d1a, map: fl.t, emissive: 0xffffff, emissiveMap: fl.t, emissiveIntensity: 0.85, roughness: 0.32, metalness: 0.5 });
  const sideMat = new THREE.MeshStandardMaterial({ color: 0x0b0d1a, roughness: 0.45, metalness: 0.6 });
  const stage = new THREE.Mesh(new THREE.BoxGeometry(STAGE.w, STAGE_Y, STAGE.d), [sideMat, sideMat, topMat, sideMat, sideMat, sideMat]);
  stage.position.y = STAGE_Y / 2; stage.receiveShadow = true; scene.add(stage);
  const drawFloor = (t) => {
    const x = fl.x, cw = fl.w / 12, ch = fl.h / 8; x.fillStyle = "#05060e"; x.fillRect(0, 0, fl.w, fl.h);
    for (let cy = 0; cy < 8; cy++) for (let cx = 0; cx < 12; cx++) {
      const d = Math.hypot(cx - 5.5, (cy - 3.5) * 1.2), wv = Math.max(0, Math.sin(d * 0.95 - t * 3.2)), l = 8 + 40 * wv * (0.3 + A.pulse + 0.4 * A.energy) + 10 * H.flash;
      x.fillStyle = hsl(t * 30 + d * 24 + H.hue * 360 * H.flash, 90, Math.min(70, l)); x.fillRect(cx * cw + 2, cy * ch + 2, cw - 4, ch - 4);
    }
    fl.t.needsUpdate = true;
  };
  drawFloor(0);
  const trim = new THREE.MeshBasicMaterial({ color: 0xff2d95 });
  for (const [w, d, px, pz] of [[STAGE.w + 0.1, 0.06, 0, STAGE.d / 2 + 0.03], [0.06, STAGE.d, -(STAGE.w / 2 + 0.03), 0], [0.06, STAGE.d, STAGE.w / 2 + 0.03, 0]]) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.07, d), trim); m.position.set(px, STAGE_Y - 0.03, pz); scene.add(m);
  }

  // Disco central luminoso (anéis + raios), gira devagar e pulsa com a batida.
  const disc = canvasTex(512, 512), dx = disc.x;
  const rg = dx.createRadialGradient(256, 256, 0, 256, 256, 256); rg.addColorStop(0, "rgba(255,255,255,.28)"); rg.addColorStop(0.6, "rgba(120,140,255,.10)"); rg.addColorStop(1, "rgba(0,0,0,0)");
  dx.fillStyle = rg; dx.fillRect(0, 0, 512, 512);
  dx.lineWidth = 6; for (const [r, c] of [[236, "#ff2d95"], [200, "#35d6ff"], [120, "#a66bff"], [60, "#ffffff"]]) { dx.strokeStyle = c; dx.beginPath(); dx.arc(256, 256, r, 0, Math.PI * 2); dx.stroke(); }
  dx.lineWidth = 3; dx.strokeStyle = "rgba(160,190,255,.7)"; for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2; dx.beginPath(); dx.moveTo(256 + Math.cos(a) * 66, 256 + Math.sin(a) * 66); dx.lineTo(256 + Math.cos(a) * 196, 256 + Math.sin(a) * 196); dx.stroke(); }
  disc.t.needsUpdate = true;
  const discMat = new THREE.MeshBasicMaterial({ map: disc.t, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  const discMesh = new THREE.Mesh(new THREE.CircleGeometry(2.9, 64), discMat); discMesh.rotation.x = -Math.PI / 2; discMesh.position.set(0, STAGE_Y + 0.012, 0.2); scene.add(discMesh);
  // Degrau + brilho do palco derramando no chão da plateia
  const stepM = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.2, 0.55), sideMat); stepM.position.set(0, 0.1, STAGE.d / 2 + 0.27); scene.add(stepM);
  const stepEdge = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.03, 0.05), trim); stepEdge.position.set(0, 0.2, STAGE.d / 2 + 0.52); scene.add(stepEdge);
  const spillMat = new THREE.MeshBasicMaterial({ map: glow.t, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, color: 0xff2d95 });
  const spillMesh = new THREE.Mesh(new THREE.PlaneGeometry(15, 8), spillMat); spillMesh.rotation.x = -Math.PI / 2; spillMesh.position.set(0, 0.02, 5.2); scene.add(spillMesh);

  // ---------- telão gigante atrás dos personagens ----------
  const LQ = [[768, 482], [1024, 643], [1280, 804]][q] || [1024, 643];
  const led = canvasTex(LQ[0], LQ[1]);
  const wallMat = new THREE.MeshBasicMaterial({ map: led.t, toneMapped: false });
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(WALL_W, WALL_H), wallMat); wall.position.set(0, WALL_Y, WALL_Z); scene.add(wall);
  const frameMat = new THREE.MeshStandardMaterial({ color: 0x0d0f1d, metalness: 0.7, roughness: 0.4 });
  const frame = new THREE.Mesh(new THREE.BoxGeometry(WALL_W + 0.3, WALL_H + 0.3, 0.14), frameMat); frame.position.set(0, WALL_Y, WALL_Z - 0.09); scene.add(frame);
  safe("pixels do telão", () => {          // grade de pixels de LED por cima da imagem
    const mk = canvasTex(16, 16); mk.x.clearRect(0, 0, 16, 16); mk.x.fillStyle = "rgba(0,0,0,.6)"; mk.x.fillRect(0, 0, 16, 2.4); mk.x.fillRect(0, 0, 2.4, 16); mk.t.wrapS = mk.t.wrapT = THREE.RepeatWrapping; mk.t.repeat.set(WALL_W / 0.05, WALL_H / 0.05); mk.t.needsUpdate = true;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(WALL_W, WALL_H), new THREE.MeshBasicMaterial({ map: mk.t, transparent: true, depthWrite: false, toneMapped: false })); m.position.set(0, WALL_Y, WALL_Z + 0.012); scene.add(m);
  });
  const neon = new THREE.MeshBasicMaterial({ color: 0xff2d95 }), neon2 = new THREE.MeshBasicMaterial({ color: 0x35d6ff });
  for (const [w, h, px, py] of [[WALL_W + 0.5, 0.08, 0, WALL_H / 2 + 0.2], [WALL_W + 0.5, 0.08, 0, -WALL_H / 2 - 0.2], [0.08, WALL_H + 0.5, -WALL_W / 2 - 0.2, 0], [0.08, WALL_H + 0.5, WALL_W / 2 + 0.2, 0]]) {
    const n = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.08), neon); n.position.set(px, WALL_Y + py, WALL_Z + 0.05); scene.add(n);
  }
  // arcos de neon em volta do telão
  const arcs = safe("arcos", () => [[4.95, 0.07, neon2], [5.4, 0.045, neon]].map(([r, tube, mat]) => {
    const a = new THREE.Mesh(new THREE.TorusGeometry(r, tube, 8, 72, Math.PI), mat); a.position.set(0, WALL_Y - 0.9, WALL_Z - 0.2); scene.add(a); return a;
  })) || [];
  // faixas de LED com luzes correndo (acima/abaixo do telão e na frente do palco)
  const strip = canvasTex(512, 16), stripMat = new THREE.MeshBasicMaterial({ map: strip.t, toneMapped: false });
  safe("faixas de LED", () => {
    for (const [w, px, py, pz] of [[WALL_W + 0.5, 0, WALL_Y + WALL_H / 2 + 0.38, WALL_Z + 0.05], [WALL_W + 0.5, 0, WALL_Y - WALL_H / 2 - 0.38, WALL_Z + 0.05], [STAGE.w, 0, STAGE_Y + 0.02, STAGE.d / 2 + 0.065]]) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(w, 0.12), stripMat); m.position.set(px, py, pz); scene.add(m);
    }
  });
  const drawStrip = (t) => {
    const x = strip.x; x.fillStyle = "#04050c"; x.fillRect(0, 0, 512, 16);
    for (let i = 0; i < 32; i++) { const l = 18 + 55 * Math.max(0, Math.sin(i * 0.5 - t * 6)) + 22 * A.pulse; x.fillStyle = hsl(t * 40 + i * 11, 100, Math.min(75, l)); x.fillRect(i * 16 + 1, 2, 14, 12); }
    strip.t.needsUpdate = true;
  };
  // estrutura de palco: riser traseiro com barras de LED e monitores de chão
  safe("riser e monitores", () => {
    const riser = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.22, 0.9), sideMat); riser.position.set(0, STAGE_Y + 0.11, -2.55); scene.add(riser);
    const edge = new THREE.Mesh(new THREE.BoxGeometry(7.4, 0.03, 0.04), neon2); edge.position.set(0, STAGE_Y + 0.23, -2.1); scene.add(edge);
    for (const mx of [-2.7, 0, 2.7]) { const w = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.3, 0.5), sideMat); w.position.set(mx, STAGE_Y + 0.12, 2.75); w.rotation.x = -0.35; scene.add(w); const e = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.025, 0.03), neon); e.position.set(mx, STAGE_Y + 0.265, 2.55); scene.add(e); }
  });
  // estrelas ao fundo
  safe("estrelas", () => {
    const R = rng(5), n = 260, a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { a[i * 3] = (R() - 0.5) * 120; a[i * 3 + 1] = 6 + R() * 45; a[i * 3 + 2] = -28 - R() * 25; }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(a, 3));
    scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.22, transparent: true, opacity: 0.8, fog: false, depthWrite: false })));
  });
  // Brilhinhos no ar (bokeh)
  const R0 = rng(21), SP = 90, spArr = new Float32Array(SP * 3);
  for (let i = 0; i < SP; i++) { spArr[i * 3] = (R0() - 0.5) * 12; spArr[i * 3 + 1] = 0.8 + R0() * 8, spArr[i * 3 + 2] = -2.5 + R0() * 10; }
  const spG = new THREE.BufferGeometry(); spG.setAttribute("position", new THREE.BufferAttribute(spArr, 3));
  const sparkMat = new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.07, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, depthWrite: false });
  const sparkles = new THREE.Points(spG, sparkMat); scene.add(sparkles);
  // Torres laterais (equalizador)
  const side = canvasTex(128, 384);
  const towerMat = new THREE.MeshBasicMaterial({ map: side.t, toneMapped: false });
  for (const sx of [-1, 1]) {
    const tw = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 3.9), towerMat); tw.position.set(sx * 5.3, 2.4, -2.2); tw.rotation.y = -sx * 0.28; scene.add(tw);
    const fr = new THREE.Mesh(new THREE.BoxGeometry(1.4, 4.0, 0.1), frameMat); fr.position.set(sx * 5.3, 2.4, -2.27); fr.rotation.y = -sx * 0.28; scene.add(fr);
  }

  // Treliça + moving heads (com poça de luz no palco)
  const metal = new THREE.MeshStandardMaterial({ color: 0x1a1d2e, metalness: 0.8, roughness: 0.35 });
  for (const z of [-1.1, 0.7]) { const b = new THREE.Mesh(new THREE.BoxGeometry(10.4, 0.14, 0.14), metal); b.position.set(0, TRUSS_Y, z); scene.add(b); }
  for (const px of [-5.1, 5.1]) { const p = new THREE.Mesh(new THREE.BoxGeometry(0.16, TRUSS_Y, 0.16), metal); p.position.set(px, TRUSS_Y / 2, -0.2); scene.add(p); }
  const heads = [];
  const BEAM = 11, beamGeo = new THREE.ConeGeometry(1.1, BEAM, 20, 1, true); beamGeo.translate(0, -BEAM / 2, 0);
  const nHeads = q ? 8 : 5, headY = TRUSS_Y - 0.15;
  for (let i = 0; i < nHeads; i++) {
    const pivot = new THREE.Group(); pivot.position.set(-4.4 + (8.8 * i) / (nHeads - 1), headY, -0.2);
    pivot.add(new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.1, 0.36, 10), metal));
    const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    pivot.add(new THREE.Mesh(beamGeo, mat)); scene.add(pivot);
    const pm = new THREE.MeshBasicMaterial({ map: glow.t, color: 0xffffff, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false });
    const pool = safe("poça de luz", () => { const m = new THREE.Mesh(new THREE.CircleGeometry(1.2, 24), pm); m.rotation.x = -Math.PI / 2; m.visible = false; scene.add(m); return m; });
    heads.push({ pivot, mat, pm, pool, i });
  }
  const lasers = [];
  if (q >= 1) for (let i = 0; i < 8; i++) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.018, 14, 0.018).translate(0, -7, 0), new THREE.MeshBasicMaterial({ color: i % 2 ? 0x2cff9a : 0x35d6ff, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending, depthWrite: false }));
    m.position.set(-3.5 + i, headY - 0.2, -1.8); scene.add(m); lasers.push(m);
  }

  // Plateia (silhuetas escuras) com luzes de celular
  const R = rng(7), N = q ? 90 : 48;
  const bodies = new THREE.InstancedMesh(new THREE.CapsuleGeometry(0.2, 0.55, 2, 6), new THREE.MeshStandardMaterial({ color: 0x090b14, roughness: 0.9 }), N);
  const headsI = new THREE.InstancedMesh(new THREE.SphereGeometry(0.14, 8, 6), bodies.material, N);
  const crowd = [];
  for (let i = 0; i < N; i++) crowd.push({ x: (R() - 0.5) * 15, z: 5.6 + R() * 5.4, ph: R() * 6.28 });
  scene.add(bodies, headsI);
  const phones = new Float32Array(Math.floor(N * 0.4) * 3);
  crowd.slice(0, phones.length / 3).forEach((c, i) => { phones[i * 3] = c.x + 0.25; phones[i * 3 + 1] = 2.1; phones[i * 3 + 2] = c.z; });
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(phones, 3));
  const phoneMat = new THREE.PointsMaterial({ color: 0xcfe0ff, size: 0.16, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
  scene.add(new THREE.Points(pg, phoneMat));
  const dummy = new THREE.Object3D();

  // Névoa
  let haze = null;
  if (q >= 1) {
    const hp = new Float32Array(120 * 3); for (let i = 0; i < 120; i++) { hp[i * 3] = (R() - 0.5) * 16; hp[i * 3 + 1] = 0.5 + R() * 6; hp[i * 3 + 2] = -3 + R() * 11; }
    const hg = new THREE.BufferGeometry(); hg.setAttribute("position", new THREE.BufferAttribute(hp, 3));
    haze = new THREE.Points(hg, new THREE.PointsMaterial({ map: glow.t, color: 0x6677ff, size: 2.8, transparent: true, opacity: 0.07, depthWrite: false, blending: THREE.AdditiveBlending }));
    scene.add(haze);
  }
  const col = new THREE.Color();
  let slowT = 0;

  /** Reação a eventos da LIVE: gift (forte), join (média), like (leve). */
  function hype(kind, hue) { H.flash = Math.max(H.flash, kind === "gift" ? 1 : kind === "join" ? 0.5 : 0.22); H.hue = typeof hue === "number" ? hue : Math.random(); }

  function update(t, dt, a) {
    A.energy = a.energy; A.pulse = a.pulse; H.flash = Math.max(0, H.flash - dt * 1.4);
    const fl_ = H.flash;
    trim.color.setHSL((t * 0.1) % 1, 1, 0.55); neon.color.setHSL((t * 0.08 + 0.85) % 1, 1, 0.6); neon2.color.setHSL((t * 0.08 + 0.5) % 1, 1, 0.6);
    spillMat.color.setHSL((t * 0.05) % 1, 0.9, 0.5); spillMat.opacity = 0.35 + 0.35 * a.pulse + 0.3 * fl_;
    discMesh.rotation.z = t * 0.12; discMat.opacity = 0.55 + 0.45 * (0.4 * a.energy + a.pulse);
    sparkMat.opacity = 0.45 + 0.25 * Math.sin(t * 3); sparkles.rotation.y = t * 0.015;
    rimA.intensity = 1.0 + 0.7 * a.pulse + 1.6 * fl_; rimB.intensity = 1.0 + 0.7 * a.pulse + 1.6 * fl_;
    washes.forEach((l, i) => { l.intensity = (q ? 40 : 22) * (0.75 + 0.7 * a.pulse + 0.15 * Math.sin(t * 2 + i) + 1.1 * fl_); });
    wallMat.color.setScalar(1 + 0.06 * a.pulse + 0.4 * fl_);
    arcs.forEach((m, i) => { m.rotation.z = Math.sin(t * 0.3 + i) * 0.01; });
    for (const h of heads) {
      const rx = Math.sin(t * 0.7 + h.i * 0.8) * 0.55 + a.pulse * 0.08, rz = Math.cos(t * 0.5 + h.i * 1.3) * 0.7;
      h.pivot.rotation.x = rx; h.pivot.rotation.z = rz;
      h.mat.color.setHSL((t * 0.05 + h.i * 0.12 + H.hue * fl_) % 1, 1, 0.6);
      h.mat.opacity = 0.05 + 0.1 * (0.4 + a.energy) + 0.12 * a.pulse + 0.18 * fl_;
      if (h.pool) {
        const cz = Math.cos(rz), cx = Math.cos(rx), dist = (headY - STAGE_Y) / Math.max(0.3, cz * cx);
        const px = h.pivot.position.x + dist * Math.sin(rz), pz = h.pivot.position.z - dist * cz * Math.sin(rx), onStage = Math.abs(px) < STAGE.w / 2 && Math.abs(pz) < STAGE.d / 2;
        h.pool.position.set(px, onStage ? STAGE_Y + 0.025 : 0.03, pz); h.pool.visible = Number.isFinite(px + pz);
        h.pm.color.copy(h.mat.color); h.pm.opacity = 0.28 + 0.3 * a.pulse + 0.3 * fl_;
      }
    }
    lasers.forEach((m, i) => { m.rotation.z = Math.sin(t * 0.9 + i) * 0.9; m.rotation.x = Math.cos(t * 0.6 + i * 1.7) * 0.5; m.material.opacity = 0.25 + 0.5 * a.pulse + 0.3 * fl_; m.material.color.setHSL((t * 0.04 + i * 0.1) % 1, 1, 0.6); });
    const bob = 0.03 + 0.06 * a.energy;
    for (let i = 0; i < N; i++) {
      const c = crowd[i], y = Math.abs(Math.sin(t * 3 + c.ph)) * bob + a.pulse * 0.05 + fl_ * 0.06;
      dummy.position.set(c.x, 0.475 + y, c.z); dummy.rotation.set(0, 0, Math.sin(t + c.ph) * 0.04); dummy.updateMatrix(); bodies.setMatrixAt(i, dummy.matrix);
      dummy.position.set(c.x, 1.15 + y, c.z); dummy.updateMatrix(); headsI.setMatrixAt(i, dummy.matrix);
    }
    bodies.instanceMatrix.needsUpdate = true; headsI.instanceMatrix.needsUpdate = true;
    phoneMat.opacity = 0.55 + 0.35 * Math.sin(t * 7);
    if (haze) haze.rotation.y = t * 0.01;
    // texturas animadas pequenas (piso, faixas, torres): ~12 quadros por segundo
    if ((slowT += dt) > 0.08) {
      slowT = 0; drawFloor(t); drawStrip(t);
      const x = side.x; x.fillStyle = "#05060c"; x.fillRect(0, 0, 128, 384);
      for (let i = 0; i < 12; i++) {
        const v = a.hasAudio ? a.spectrum[i * 2] || 0 : 0.35 + 0.3 * Math.sin(t * 2.2 + i * 0.7);
        col.setHSL(((t * 0.05) + i * 0.04) % 1, 0.9, 0.55); x.fillStyle = `#${col.getHexString()}`;
        x.fillRect(8, 384 - (i + 1) * 31, Math.max(6, 112 * Math.min(1, v * 1.4)), 24);
      }
      side.t.needsUpdate = true;
    }
  }
  return { update, hype, led, drawLed: (s, t) => drawLed(led, { ...s, pulse: A.pulse, energy: A.energy, flash: H.flash }, t) };
}
